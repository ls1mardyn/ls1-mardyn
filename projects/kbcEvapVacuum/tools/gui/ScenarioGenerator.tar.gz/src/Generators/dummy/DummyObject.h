/*
 * DummyObject.h
 *
 * @Date: 06.07.2011
 * @Author: eckhardw
 */

#ifndef DUMMYOBJECT_H_
#define DUMMYOBJECT_H_

#include "Objects/Object.h"

class DummyObject: public Object {

private:
	Position _position;
	unsigned long _id;

public:
	DummyObject(double x0, double x1, double x2, unsigned long id);

	virtual ~DummyObject();

	virtual vtkSmartPointer<vtkActor> draw(int);

	/*
	 * Dummy implementation for function of base class
	 */
	virtual vtkSmartPointer<vtkActor> drawVectors() {
		std::cout <<"ERROR call of unsupported function! DummyObject::drawVectors(); No vectors to draw";
		exit(-1);
		return NULL;
	}
	/*
	 * Dummy implementation for function of base class
	 */
	virtual std::vector<std::string> getDrawableValues() const;
	/*
	 * Dummy implementation for function of base class
	 */
	virtual vtkSmartPointer<vtkActor> draw(string valueName);

};

#endif /* DUMMYOBJECT_H_ */
