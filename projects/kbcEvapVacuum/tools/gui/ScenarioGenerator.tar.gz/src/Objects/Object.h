/*
 * Object.h
 *
 *  Created on: Mar 25, 2011
 *      Author: kovacevt
 */

#ifndef OBJECT_H_
#define OBJECT_H_
#include <vector>
#include <string.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkPolyData.h>
#include <vtkSmartPointer.h>
#include <vtkSphereSource.h>
#include <vtkArrowSource.h>
#include <vtkInteractorStyleTrackballCamera.h>
#include <vtkInteractorStyleTrackball.h>
#include <vtkProperty.h>
#include <vtkVectorDot.h>
#include <vtkTransformPolyDataFilter.h>
#include <vtkProperty.h>
#include <vtkTransform.h>

using namespace std;
/**
 * Class Position
 * Implements the position with fields x,y,z
 */
class Position {
public:
		double x,y,z;
		Position(double xx = 0, double yy = 0, double zz = 0):
			x(xx),y(yy),z(zz){}
	};

/**
 * Class Vector
 * Implements the vector with components in directions x,y,z
 */
class Vector {
public:
	double x,y,z;
	Vector(double vx = 0, double vy = 0, double vz = 0):
		x(vx),y(vy),z(vz){}
};

/**
 * Interface Object imlements the object that is to be displayed and used in
 * the simulation
 */
class Object {


protected:
	static int _numObjects;
	/**
	 * Constructor
	 */
	Object(){}

	/**
	 * Draws a value at the given position. The minimum and maximum value are needed
	 * to deduce the range of values and choose a colour encoding for the given value.
	 *
	 * @param position the xyz-coordinates where the value should be drawn
	 * @param value the actual value
	 * @param minValue the minimal value which will be drawn
	 * @param maxValue the maximum value which will be drawn
	 *
	 * @return actor that acts on this object which is later added
	 * to the list of all actors
	 */
	vtkSmartPointer<vtkActor> drawValue(Position& position, double value,
			double minValue, double maxValue, bool color);

	vtkSmartPointer<vtkActor> drawVector(Position& position, Vector& v);

public:
	/**
	 * Desructor
	 */
	virtual ~Object(){}

	virtual vector<string> getDrawableValues() const = 0;

	virtual vtkSmartPointer<vtkActor> draw(string valueName) = 0;

	static void setNumObjects(int n) {
		_numObjects = n;
	}

private:
	float* convFloatToRGB(float ratio);
};

#endif /* OBJECT_H_ */
