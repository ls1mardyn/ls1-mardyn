/*
 * WriteOutput.cpp
 *
 *  Created on: May 15, 2011
 *      Author: kovacevt
 */

#include "IO/WriteOutput.h"
#include "Generators/Generator.h"
#include "Parameters/ParameterCollection.h"
#include "Tokenize.h"
#include <fstream>

void indent(int n, ofstream& output) {
	for (int i = 0; i < n; i++) {
		output << "\t";
	}
}

using namespace std;

WriteOutput::WriteOutput() {}

WriteOutput::~WriteOutput() {}


void WriteOutput::saveGeneratorConfiguration(Generator& generator, const std::string& filename) {
	ofstream output(filename.c_str());
	output<<"generator=" << generator.getName() << endl;

	vector<ParameterCollection*> parameters = generator.getParameters();
	for (size_t i = 0; i < parameters.size(); i++) {
#ifdef DEBUG
		std::cout << "Write parameterCollection name="<< parameters[i]->getNameId() << endl;
#endif
		saveParameterCollection(parameters[i], output, 0);
		ParameterCollection::deleteParameter(parameters[i]);
	}

	output.close();
}

void WriteOutput::loadGeneratorConfiguration(Generator& generator, const std::string& filename) {
	ifstream input(filename.c_str());
	string line;
	input >> line;

	string type = firstSubString("=", line);
	if (type != "generator") {
		std::cout << "Error: " << filename << " is not a generator config file!" << endl;
	}

	string name = remainingSubString("=", line);
	if (generator.getName() != name) {
		std::cout << "Error initializing " << generator.getName() << endl;
		std::cout << "Error: File " << filename << " is a configuration file for generator " << name << endl;
		return;
	}

	vector<ParameterCollection*> parameters = generator.getParameters();
	for (size_t i = 0; i < parameters.size(); i++) {
#ifdef DEBUG
		std::cout << "Load parameterCollection name="<< parameters[i]->getNameId() << endl;
#endif
		string name;
		input >> name;
		input >> line;
		if (name != parameters[i]->getNameId() || line != "{") {
			std::cout << "Error: Trying to initialize parameter collection " << parameters[i]->getNameId()
					  << " from an invalid or broken tag / file (read line:" << line << ")" << endl;
		}

		loadParameterCollection(parameters[i], &generator, input);
		ParameterCollection::deleteParameter(parameters[i]);
	}
}

void WriteOutput::saveParameterCollection(ParameterCollection* collection, const std::string& filename) {
	ofstream output(filename.c_str());
	saveParameterCollection(collection, output, 0);
	output.close();
}

void WriteOutput::loadParameterCollection(ParameterCollection* collection, Generator* generator, const std::string& filename) {
	ifstream input(filename.c_str());
	string line;
	getline(input, line);

	string name = firstSubString(" ", line);
	if (name != collection->getNameId() || line.at(line.size()-1) != '{') {
		std::cout << "Error: Trying to initialize parameter collection " << collection->getNameId()
				  << "from an invalid or broken tag / file (read line:" << line << ")" << endl;
	}

	loadParameterCollection(collection, generator, input);
	input.close();
}

void WriteOutput::saveParameterCollection(ParameterCollection* collection, ofstream& output, int recursionDepth) {
	int indentWidth = recursionDepth;
	indent(indentWidth, output);
	output << collection->getNameId() << " {" << endl;
	indentWidth++;

	list<Parameter*> parameters = collection->getParameters();
	// first write the parameters which require gui rebuild, because when reading
	// the parameters in first the parameter model has to be changed according to
	// the variable parameters, then we can fill them
	for (list<Parameter*>::iterator it = parameters.begin(); it != parameters.end(); it++) {
		if ((*it)->requiresGUIRebuild()) {
			indent(indentWidth, output);
			output << (*it)->getNameId() << "=" << (*it)->getStringValue() << endl;
		}
	}

	for (list<Parameter*>::iterator it = parameters.begin(); it != parameters.end(); it++) {
		if (! (*it)->requiresGUIRebuild()) {
			if ((*it)->getType() == Parameter::COMPOSITE) {
				saveParameterCollection(dynamic_cast<ParameterCollection*>(*it), output, indentWidth);
			} else {
				indent(indentWidth, output);
				output << (*it)->getNameId() << "=" << (*it)->getStringValue() << endl;
			}
		}
	}

	indentWidth--;
	indent(indentWidth, output);
	output << "}" << endl;
}

void WriteOutput::loadParameterCollection(ParameterCollection* collection, Generator* generator, ifstream& input) {
	string line;

	do {
		input >> line; // here operator>> is used intentionally
		               // (the read word will be one word containing "=" if we read a parameter,
		               // a "}" indicating the end of a parameter collection,
		               // or otherwise a name of a parameter collection followed by a {
#ifdef DEBUG
		cout << "WriteOutput::loadParameterCollection: read word: " << line << endl;
#endif
		if (line == "}") {
			// we are at the end of a parameter collection
//			lineRead >> lineToken;
//			std::cout << "Returning from loadParameterCollection(Collection=" << collection->getNameId() << ")" << endl;
//			std::cout << "Read last token=" << lineToken << " and now returning ..." << endl;
			return;
		}

		// firstSubString returns the full string "line" if no "=" is found,
		// thus we really have the name of the parameter or collection in "name"
		string name = firstSubString("=", line);
		string value = remainingSubString("=", line);

		Parameter* currentParameter = ParameterCollection::findParameter(collection, name);
		if (currentParameter == NULL) {
			std::cout << "Error: Parameter with name " << line << " not found in collection "
					  << collection->getNameId() << endl;
			return;
		}

		if (currentParameter->getType() == Parameter::COMPOSITE) {
			input >> line;
			if (line != "{") {
				std::cout << "Error: Parameter Collection " << currentParameter->getNameId()
						  << " has errornous or missing {" << endl;
				return;
			}
			loadParameterCollection(dynamic_cast<ParameterCollection*>(currentParameter), generator, input);
		} else {
			// we have a "simple" parameter"
			currentParameter->setStringValue(value);
			generator->setParameter(currentParameter);

			if (currentParameter->requiresGUIRebuild()) {
				// I guess this only works as long as a parameter changes the parameter
				// model of the current parameter collection, i.e. obeys the hierarchical
				// structure of the paramters...
				vector<ParameterCollection*> parameters = generator->getParameters();
				Parameter* newParameter = NULL;
				bool newParameterFound = false;
				for (int i = 0; i < parameters.size(); i++) {
					newParameter = ParameterCollection::findParameter(parameters[i], collection->getNameId());
					if (newParameter != NULL) {
						newParameterFound = true;
						loadParameterCollection(dynamic_cast<ParameterCollection*>(newParameter), generator, input);
					}
					ParameterCollection::deleteParameter(parameters[i]);
				}

				if (!newParameterFound) {
					std::cout << "Error: did not find ParameterCollection " << collection->getNameId()
							  << " after setting parameter " << currentParameter->getNameId() << " to " << value << endl;
				}
				return;
			}
		}
	} while (line != "}");
}

