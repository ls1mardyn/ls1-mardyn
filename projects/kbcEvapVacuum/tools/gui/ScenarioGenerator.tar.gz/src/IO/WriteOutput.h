/*
 * WriteOutput.h
 *
 *  Created on: May 15, 2011
 *      Author: kovacevt
 */

#ifndef WRITEOUTPUT_H_
#define WRITEOUTPUT_H_

#include <string>

class Generator;
class ParameterCollection;

class WriteOutput {

private:
	WriteOutput();
	virtual ~WriteOutput();

public:

	/**
	 * Save the configuration of a generator to a file.
	 */
	static void saveGeneratorConfiguration(Generator& generator, const std::string& filename);

	/**
	 * Load the configuration of a generator from a file.
	 */
	static void loadGeneratorConfiguration(Generator& generator, const std::string& filename);

	/**
	 * Write a ParameterCollection to a file.
	 */
	static void saveParameterCollection(ParameterCollection* collection, const std::string& filename);

	/**
	 * Read the values of a ParameterCollection from a file.
	 */
	static void loadParameterCollection(ParameterCollection* collection, Generator* generator, const std::string& filename);

private:
	/**
	 * Write a parameterCollection to a stream.
	 */
	static void saveParameterCollection(ParameterCollection* collection, std::ofstream& output, int recursionDepth);

	/**
	 * Read the values of a ParameterCollection from a stream.
	 */
	static void loadParameterCollection(ParameterCollection* collection, Generator* generator, std::ifstream& input);

};

#endif /* WRITEOUTPUT_H_ */
