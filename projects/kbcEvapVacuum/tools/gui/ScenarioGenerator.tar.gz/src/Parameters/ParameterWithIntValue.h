/*
 * ParameterWithValue.h
 *
 *  Created on: May 4, 2011
 *      Author: kovacevt
 */

#ifndef PARAMETERWITHINTVALUE_H_
#define PARAMETERWITHINTVALUE_H_

#include "Parameters/ParameterWithValue.h"

class ParameterWithIntValue: public ParameterWithValue {
private:
	int value;

public:
	/**
	 * Constructor
	 * @param id nameId
	 * @param n name
	 * @param d description
	 * @param b if it triggers gui rebuild
	 * @param v value
	 */
	ParameterWithIntValue(const std::string Id, const std::string name, const std::string description, WidgetType wt, const bool b, const int v);

	virtual ~ParameterWithIntValue();

	//getters
	int getValue() const {return value;}

	std::string getStringValue() const;

	//setters
	void setValue(const int v){value = v;}

	void setStringValue(const std::string& value);

	void print() const;
};

#endif /* PARAMETERWITHVALUE_H_ */
