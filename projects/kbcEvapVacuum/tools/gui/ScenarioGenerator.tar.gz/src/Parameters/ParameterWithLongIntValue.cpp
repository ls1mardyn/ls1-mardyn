/*
 * ParameterWithLongValue.cpp
 *
 *  Created on: Aug 14, 2012
 *      Author: eckhardw
 */

#include "Parameters/ParameterWithLongIntValue.h"
#include "Conversions.h"

ParameterWithLongIntValue::ParameterWithLongIntValue(const std::string id, const::string n, const std::string d, WidgetType wt, const bool b, const long int v)
: ParameterWithValue(id,n,d,wt,b, Parameter::INT){
	value = v;
}

ParameterWithLongIntValue::~ParameterWithLongIntValue() {

}

void ParameterWithLongIntValue::setStringValue(const std::string& text){
	istringstream myStream(text);
	myStream >> value;
}


void ParameterWithLongIntValue::print() const {
	std::cout << "ParameterWithIntValue " << name << " value="<< value << endl;
}

string ParameterWithLongIntValue::getStringValue() const {
	stringstream valueStream;
	valueStream << value;
	return valueStream.str();
}
