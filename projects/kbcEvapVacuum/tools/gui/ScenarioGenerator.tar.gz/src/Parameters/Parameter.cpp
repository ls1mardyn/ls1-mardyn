/*
 * Parameter.cpp
 *
 *  Created on: Mar 25, 2011
 *      Author: kovacevt
 */

#include "Parameter.h"


Parameter::Parameter(const std::string id, const std::string n, const std::string d, WidgetType wt, Type type)
:name(n), nameId(id), description(d), widgetType(wt), _type(type) {

}

Parameter::~Parameter() {
}

