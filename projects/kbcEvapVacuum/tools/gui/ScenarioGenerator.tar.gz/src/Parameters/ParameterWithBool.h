/*
 * ParameterWithBool.h
 *
 *  Created on: Jun 25, 2011
 *      Author: kovacevt
 */

#ifndef PARAMETERWITHBOOL_H_
#define PARAMETERWITHBOOL_H_

#include "Parameter.h"

class ParameterWithBool: public Parameter {
private:
	bool triggersRebuild;
	bool value;

public:
	ParameterWithBool(const std::string Id, const std::string name, const std::string description, WidgetType wt, bool rebuild, bool v);
	virtual ~ParameterWithBool();

	void setValue(bool v){
		value = v;
	}

	bool getValue() const {return value;}

	string getStringValue() const;

	void setStringValue(const std::string& value);

	virtual void print() const;

	virtual bool requiresGUIRebuild() const {return triggersRebuild;}

};

#endif /* PARAMETERWITHBOOL_H_ */
