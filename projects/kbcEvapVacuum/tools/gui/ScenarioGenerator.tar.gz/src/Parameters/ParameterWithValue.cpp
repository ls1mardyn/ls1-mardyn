/*
 * ParameterWithValue.cpp
 *
 *  Created on: May 4, 2011
 *      Author: kovacevt
 */

#include "Parameters/ParameterWithValue.h"


ParameterWithValue::ParameterWithValue(const std::string id, const std::string n, const std::string d, WidgetType wt, const bool b, Type type) :
Parameter(id,n,d,wt, type), triggersRebuild(b) {
}


ParameterWithValue::~ParameterWithValue() {
}
