/*
 * ParameterCollection.h
 *
 *	This class describes the collection of Parameters (Composite DP)
 *
 *  Created on: May 4, 2011
 *      Author: kovacevt
 */

#ifndef PARAMETERCOLLECTION_H_
#define PARAMETERCOLLECTION_H_

#include "Parameters/Parameter.h"
#include "IO/WriteOutput.h"
#include <list>

class Generator;

/**
 * A parameter collection represents a collection of parameters, i.e. it can
 * contain several Parameters with value or recursively other parameter collections.
 *
 * It is possible to load / and or store the values of a collection, if those options
 * are enabled.
 */
class ParameterCollection: public Parameter {

protected:
	list<Parameter*> parameters; // parameters in the collection

	bool _hasLoadOption;

	bool _hasStoreOption;

	bool _hasCancelOption;

	std::string _stringValue;

	bool _wasCancelled;

public:
	/**
	 * Constructor
	 * @param id nameId
	 * @param n name
	 * @param d description
	 * @param loadOption if true, a load menue is present.
	 * @param storeOption if true, a store menue is present.
	 */
	ParameterCollection(const std::string Id, const std::string name, const std::string description,
			WidgetType wt, bool loadOption = false, bool storeOption = false, bool hasCancelOption = false);

	/**
	 * Destructor
	 */
	virtual ~ParameterCollection();

	/**
	 * adds a Parameter to the collection
	 */
	void addParameter(Parameter* p);

	/**
	 * gets the parameters in the collection
	 */
	std::list<Parameter*> getParameters() const {return parameters;}

	virtual void print() const;

	virtual std::string getStringValue() const { return _stringValue; }

	void setStringValue(const std::string& value) { _stringValue = value; }

	bool hasLoadOption() const {
		return _hasLoadOption;
	}

	/**
	 * load the parameters of this ParameterCollection from file filename.
	 *
	 * @note This method provides a default implementation reading input from a
	 *       simple text file using key-value pairs. Overwrite this method to
	 *       use a more sophisticated load / store functionality!
	 */
	virtual void load(const std::string& filename, Generator* generator) {
		WriteOutput::loadParameterCollection(this, generator, filename);
	}

	bool hasStoreOption() const {
		return _hasStoreOption;
	}

	bool hasCancelOption() const {
	  return _hasCancelOption;
	}

	bool wasCancelled() const {
	  return _wasCancelled;
	}

	void setCancelled() {
	  _wasCancelled = true;
	}
	void setOK(){
	  _wasCancelled=false;
	}

	/**
	 * save the parameters of this ParamterCollection to file filename.
	 *
	 * @note This method provides a default implementation writing output to a
	 *       simple text file using key-value pairs. Overwrite this method to
	 *       use a more sophisticated load / store functionality!
	 */
	virtual void save(const std::string& filename) {
		WriteOutput::saveParameterCollection(this, filename);
	}


	/**
	 * delete a parameter (and recursively it's contained parameters if
	 * it is a ParameterCollection)
	 */
	static void deleteParameter(Parameter* parameter);

	/**
	 * find the parameter with the given nameID in the parameterCollection.
	 */
	static Parameter* findParameter(ParameterCollection* collection, const std::string& name);
};

#endif /* PARAMETERCOLLECTION_H_ */
