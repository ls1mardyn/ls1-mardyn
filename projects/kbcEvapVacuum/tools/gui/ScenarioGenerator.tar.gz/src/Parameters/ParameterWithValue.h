/*
 * ParameterWithValue.h
 *
 *  Created on: May 4, 2011
 *      Author: kovacevt
 */

#include "Parameters/Parameter.h"


#ifndef PARAMETERWITHVALUE_H_
#define PARAMETERWITHVALUE_H_

class ParameterWithValue: public Parameter {

protected:
	 // INT or DOUBLE, CHOICE for getting a dropbox
	bool triggersRebuild;

public:
	/**
	 * Constructor
	 * @param id nameId
	 * @param n name
	 * @param d description
	 * @param b if a change of this parameter triggers gui rebuild
	 */
	ParameterWithValue(const std::string id, const std::string n, const std::string d,  WidgetType wt, const bool b, Type type);

	/**
	 * Destructor
	 */
	virtual ~ParameterWithValue();

	// setters
	virtual bool requiresGUIRebuild() const {return triggersRebuild;}

	virtual void print() const = 0;

	virtual void setStringValue(const std::string& text) = 0;

	virtual string getStringValue() const = 0;
};

#endif /* PARAMETERWITHVALUE_H_ */
