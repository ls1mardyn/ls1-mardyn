/*
 * MainWindow.h
 *
 * @Date: 02.08.2011
 * @Author: eckhardw
 */

#ifndef MAINWINDOW_H_
#define MAINWINDOW_H_

#include "QObjects/QPanel.h"

#include <QtGui>
#include "QVTKWidget.h"
#include <vtkSmartPointer.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vector>

class ParameterCollection;
class QTextMessageField;
class ScenarioGeneratorApplication;

class MainWindow: public QMainWindow {
	Q_OBJECT

public:

	MainWindow(ScenarioGeneratorApplication* application);

	virtual ~MainWindow();

	/**
	 * Rebuild the tabbed panel, to be called after a new generator is set,
	 * because then the total structure of the tabs may change.
	 */
	void rebuildTabPanels();


	/**
	 * Rebuild all panels which visualize the collection, or children of it.
	 */
	void updateAllPanels();

	/**
	 * Rebuilds the panel belonging to the given collection, if there is any open panel.
	 */
	void updatePanelAndChildren(ParameterCollection* collection);


	void addOpenPanels(QPanel* panel) {
		openPanels.push_back(panel);

		// in this case we have additional open panels, so avoid switching the generator
		if (openPanels.size() > _currentGeneratorParameters.size()) {
			_generatorBox->setEnabled(false);
		}
	}

	void removeOpenPanels(QPanel* panel) {
		openPanels.remove(panel);

		if (openPanels.size() <= _currentGeneratorParameters.size()) {
			_generatorBox->setEnabled(true);
		}
	}


	std::ostream& getTextMessageStream() const;

public slots:

	void drawSelectedValue();

	void setCurrentGenerator(const QString& generator);

private:

	ScenarioGeneratorApplication* _application;

	QSplitter* _splitter;

	QTabWidget* _tabWidget;

	QComboBox* _drawableValueBox;

	vtkSmartPointer<vtkRenderWindow> _renderWindow;
	vtkSmartPointer<vtkRenderer> _renderer;

	QTextMessageField* _textEdit;
	//QTextEdit* _textEdit;
	std::vector<ParameterCollection*> _currentGeneratorParameters;

	list<QPanel*> openPanels;

	QComboBox* _generatorBox;
};

#endif /* MAINWINDOW_H_ */
