/*
 * WidgetFactory.cpp
 *
 *  Created on: Jun 9, 2011
 *      Author: kovacevt
 */

#include "WidgetFactory.h"

#include "Parameters/Parameter.h"
#include "Parameters/ParameterWithValue.h"
#include "Parameters/ParameterWithChoice.h"
#include "Parameters/ParameterCollection.h"
#include "Parameters/ParameterWithBool.h"
#include "QParCheckBox.h"
#include "QParSpinBox.h"
#include "QParButton.h"
#include "QParLineEdit.h"
#include "QParListWidget.h"
#include "QParComboBox.h"

#include <iostream>

WidgetFactory::WidgetFactory() {
}

WidgetFactory::~WidgetFactory() {
}

QWidget* WidgetFactory::createWidget(Parameter* p) {
	Parameter::WidgetType type = p->getWidgetType();
	QWidget* widget = NULL;

	switch (type) {
	case Parameter::LINE_EDIT: {
		ParameterWithValue* tmp = dynamic_cast<ParameterWithValue*> (p);
		if (tmp != NULL) {
			widget = new QParLineEdit(tmp);
		}
		break;
	}
	case Parameter::BUTTON: {
		ParameterCollection* tmp = dynamic_cast<ParameterCollection*> (p);
		if (tmp != NULL) {
			widget = new QParButton(tmp);
		}
		break;
	}

	case Parameter::LIST: {
		ParameterWithChoice* tmp = dynamic_cast<ParameterWithChoice*> (p);
		if (tmp != NULL) {
			widget = new QParListWidget(tmp);
		}
		break;
	}

	case Parameter::COMBOBOX: {
		ParameterWithChoice* tmp = dynamic_cast<ParameterWithChoice*> (p);
		if (tmp != NULL) {
			widget = new QParComboBox(tmp);
		}
		break;
	}

	case Parameter::CHECKBOX: {
		ParameterWithBool* tmp = dynamic_cast<ParameterWithBool*>(p);
		if (tmp != NULL) {
			widget = new QParCheckBox(tmp);
		}
		break;
	}

	case Parameter::SPINBOX: {
		ParameterWithIntValue* tmp = dynamic_cast<ParameterWithIntValue*> (p);
		if (tmp != NULL) {
			widget = new QParSpinBox(tmp);
		}
		break;
	}
	default: {
		std::cout << "Error: Unknown Widget Type! Parameter Name="<< p->getName() << endl;
		break;
	}
	}

	if (widget == NULL) {
		std::cout << "Error: unsupported WidgetType " << type << " for parameter type " << p->getType() << "!" << endl;
		std::cout << "Parameter Name="<< p->getName() << endl;
	}
	return widget;
}
