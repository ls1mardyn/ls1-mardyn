/*
 * DummyGenerator.cpp
 *
 * @Date: 28.05.2011
 * @Author: eckhardw
 */

#include "DummyGenerator.h"
#include "Parameters/ParameterWithIntValue.h"
#include "Parameters/ParameterWithDoubleValue.h"
#include "Parameters/ParameterWithBool.h"
#include "QObjects/ScenarioGenerator.h"
#include "DummyObject.h"

extern "C" {

  Generator* create_generator() {
    return new DummyGenerator();
  }

  void destruct_generator(Generator* generator) {
    delete generator;
  }
}


DummyGenerator::DummyGenerator() : Generator("DummyGenerator"){
  _numObjects = 5;
  _objectSpacing = 2.6;
  _dummyBoolValue = false;
}

DummyGenerator::~DummyGenerator() {
}


void DummyGenerator::setParameter(Parameter* p) {
  std::cout << "SetParameter for param" << p->getNameId() << endl;
  std::string id = p->getNameId();

  if (id == "numObjects") {
      std::cout << "Setting numObjects!" << std::endl;
      _numObjects = static_cast<ParameterWithIntValue*>(p)->getValue();
  }
  else if (id == "objectSpacing") {
      std::cout << "Setting objectSpacing!" << std::endl;
      _objectSpacing = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "dummyBoolValue") {
      std::cout << "Setting dummyBoolValue!" <<std::endl;
      _dummyBoolValue = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting dummyBoolValue: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }

  std::cout << "Parameter value is set!" << endl;
}


bool DummyGenerator::validateParameters() {
  bool isValid = true;

  if (_numObjects <= 0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
    		  << "Number of objects has to be greater 0!" << std::endl;
      isValid = false;
  }

  if (_objectSpacing < 0.0) {
	  ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
			  << "Object spacing has to be greater 0!" << std::endl;
      isValid = false;
  }
  return isValid;
}


vector<ParameterCollection*> DummyGenerator::getParameters() {
  vector<ParameterCollection*> parameters;
  ParameterCollection* tab = new ParameterCollection("DummyCollection", "DummyCollection",
      "DummyCollection", Parameter::BUTTON);
  parameters.push_back(tab);

  tab->addParameter(
      new ParameterWithIntValue("numObjects",
          "Number of Objects", "The number of objects which is created and displayed",
          Parameter::SPINBOX,  true, _numObjects));

  tab->addParameter(
      new ParameterWithDoubleValue("objectSpacing",
          "Object spacing", "The spacing between the objects", Parameter::LINE_EDIT,
          false, _objectSpacing));

  tab->addParameter(new ParameterWithBool("dummyBoolValue", "dummyBoolValue",
      "This is just a dummy Boolean Value" , Parameter::CHECKBOX, true, _dummyBoolValue));

  ParameterCollection* collection  = new ParameterCollection("Collection", "Collection",
      "Collection", Parameter::BUTTON);

  for (int i = 0; i < _numObjects; i++) {
      collection->addParameter(
          new ParameterWithDoubleValue("test",
              "test", "test", Parameter::LINE_EDIT,
              false, 3.14));
  }

  //tab->addParameter(collection);
  parameters.push_back(collection);

  return parameters;
}


// Just generate some dummy molecules...
void DummyGenerator::generatePreview() {
  int id = 1;
  for (int i = 0; i < _numObjects; i++) {
      ScenarioGeneratorApplication::getInstance()->addObject(
          new DummyObject(i * _objectSpacing, 0.0, 0.0, id));
      id++;
  }
}

void DummyGenerator::createSampleObject() const {
  ScenarioGeneratorApplication::getInstance()->addObject(
		  new DummyObject(1 * _objectSpacing, 0.0, 0.0, 1));
}
