/*
 * QParComboBox.cpp
 *
 * @Date: 12.09.2011
 * @Author: eckhardw
 */

#include "QParComboBox.h"
#include "Parameters/ParameterWithChoice.h"
#include "ScenarioGenerator.h"
#include "Generators/Generator.h"

QParComboBox::QParComboBox(ParameterWithChoice* const par) : _parameter(par) {
	int selectedIndex = 0;
	vector <string> choices = static_cast<ParameterWithChoice*> (_parameter)->getChoices();
	for (size_t i = 0; i < choices.size(); i++) {
		addItem(choices[i].c_str());
		if (choices[i] == _parameter->getStringValue()) {
			selectedIndex = i;
		}
	}
	setCurrentIndex(selectedIndex);

	connect(this,SIGNAL(currentIndexChanged (int)),SLOT(setNewChoice()));
}

QParComboBox::~QParComboBox() {
}

void QParComboBox::setNewChoice() {
	string name = currentText().toStdString();
	_parameter->setStringValue(name);
	ScenarioGeneratorApplication::getInstance()->getCurrentGenerator()->setParameter(
					_parameter);
	if (_parameter->requiresGUIRebuild()){
		ScenarioGeneratorApplication::getInstance()->getMainWindow()->updateAllPanels();
	}
}
