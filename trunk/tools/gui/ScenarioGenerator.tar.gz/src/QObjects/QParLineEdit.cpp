/*
 * QParLineEdit.cpp
 *
 *  Created on: May 11, 2011
 *      Author: kovacevt
 */

#include "QObjects/QParLineEdit.h"
#include "Parameters/ParameterWithValue.h"
#include "QObjects/ScenarioGenerator.h"
#include "Generators/Generator.h"
#include "QPanel.h"

QParLineEdit::QParLineEdit(ParameterWithValue* const par) : parameter(par) {
	this->setText(par->getStringValue().c_str());
	this->setToolTip(QString::fromStdString(parameter->getDescription()));
	connect(this, SIGNAL(editingFinished()), this, SLOT(setNewValue()));
}

QParLineEdit::~QParLineEdit() {
}

void QParLineEdit::setNewValue() {
	// workaround for Bug in QT: editingFinished() may be emitted several times
	// (https://bugreports.qt-project.org/browse/QTBUG-40)
	// so do the update only if old and new value are really different
	if (parameter->getStringValue().compare(this->text().toStdString()) != 0) {
		parameter->setStringValue(this->text().toStdString());
		ScenarioGeneratorApplication::getInstance()->getCurrentGenerator()->setParameter(
				parameter);
		if (parameter->requiresGUIRebuild()) {
			ScenarioGeneratorApplication::getInstance()->getMainWindow()->updateAllPanels();
		}
	}
}
