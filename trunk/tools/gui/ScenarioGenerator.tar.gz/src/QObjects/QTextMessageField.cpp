/*
 * QTextMessageField.cpp
 *
 * @Date: 09.08.2011
 * @Author: eckhardw
 */

#include "QTextMessageField.h"

QTextMessageField::QTextMessageField() : _textFieldStream(*this), _outStream(&_textFieldStream) {
	setReadOnly(true);
	setMaximumBlockCount(50);
}

QTextMessageField::~QTextMessageField() {
}
