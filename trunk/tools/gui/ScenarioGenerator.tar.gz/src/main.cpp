/*
 *  Created on: Mar 18, 2011
 *      Author: kovacevt
 */

#include "QObjects/ScenarioGenerator.h"
#include "Generators/Generator.h"
#include "QObjects/MainWindow.h"

#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <string>
#include <iostream>
#include <dlfcn.h>


using namespace std;

/**
 * search the names of all .so files in the directory dir and store them to files.
 */
void getdir(string dir, vector<string> &files);

/**
 * load the generators and return them together with the handles for the dlls.
 */
void loadGenerators(vector<pair<void*, Generator*> >& handles);

/**
 * destruct the generators and unload the dlls.
 */
void unloadGenerators(vector<pair<void*, Generator*> >& handles);


int main(int argc, char **argv) {
	QApplication app(argc, argv);
	ScenarioGeneratorApplication::getInstance()->showGui();

	vector<pair<void*, Generator*> > handles;
	loadGenerators(handles);

	for (size_t i = 0; i < handles.size(); i++) {
		ScenarioGeneratorApplication::getInstance()->addGenerator(handles[i].second);
		cout << "Added generator from lib: " << handles[i].second->getName() << endl;
	}

	int retVal = app.exec();

	unloadGenerators(handles);
	return retVal;
}


void loadGenerators(vector<pair<void*, Generator*> >& handles) {
	vector<string> filenames;
	getdir("./libs", filenames);
	for (size_t i = 0; i < filenames.size(); i++) {
		void* handle = dlopen(("./libs/" + filenames[i]).c_str(), RTLD_NOW);
		if (!handle) {
			cout << "Could not load library " << filenames[i] << ": " << dlerror() << endl;
			continue;
		}

		Generator* (*factory)();
		factory = (Generator* (*)()) dlsym(handle, "create_generator");
		if (const char* error = dlerror()) {
			cout << "Could not load factory function for " << filenames[i] << ":" << error << endl;
		}

		Generator* generator = factory();
		std::pair<void*,Generator*> pair = make_pair(handle, generator);
		handles.push_back(pair);
	}
}


void unloadGenerators(vector<pair<void*, Generator*> >& handles) {

	for (size_t i = 0; i < handles.size(); i++) {
		void* handle = handles[i].first;
		Generator* generator = handles[i].second;

		void (*destructor)(Generator*);
		destructor = (void (*)(Generator*)) dlsym(handle, "destruct_generator");
		if (const char* error = dlerror()) {
			cout << "Could not load destructor function for " << generator->getName() << ":" << error << endl;
		}

		destructor(generator);
		if (dlclose(handle)) {
			cout << "Error unloading library: " << dlerror() << endl;
		}
	}
}


void getdir(string dir, vector<string> &files) {
	DIR *dp;
	struct dirent *dirp;
	if ((dp = opendir(dir.c_str())) == NULL) {
		perror("getdir");
	}

	while ((dirp = readdir(dp)) != NULL) {
		string fileName(dirp->d_name);
		if (fileName.size() > 3 && fileName.substr(fileName.size()-3) == ".so") {
			files.push_back(fileName);
		}
	}
	closedir(dp);
}

