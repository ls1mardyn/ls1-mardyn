/*
 * ParameterWithDoubleValue.cpp
 *
 *  Created on: May 4, 2011
 *      Author: kovacevt
 */

#include "Parameters/ParameterWithDoubleValue.h"
#include <iostream>
#include <sstream>

ParameterWithDoubleValue::ParameterWithDoubleValue(const std::string id, const std::string n, const std::string d,
		 WidgetType wt, const bool b, const double v) : ParameterWithValue(id,n,d,wt,b, Parameter::DOUBLE){
	value = v;
}

ParameterWithDoubleValue::~ParameterWithDoubleValue() {
}


void ParameterWithDoubleValue::print() const {
	std::cout << "ParameterWithDoubleValue " << name << " value="<< value << endl;
}

string ParameterWithDoubleValue::getStringValue() const{
	stringstream valueStream;
	valueStream.precision(12);
	valueStream << value;
	return valueStream.str();
}

void ParameterWithDoubleValue::setStringValue(const std::string& text) {
	istringstream myStream(text);
	myStream >> value;
}
