/*
 * ParameterWithChoice.cpp
 *
 *  Created on: May 4, 2011
 *      Author: kovacevt
 */

#include "ParameterWithChoice.h"
#include <iostream>

ParameterWithChoice::ParameterWithChoice(const std::string id, const std::string n, const std::string d, WidgetType wt, const bool b,
		const vector<std::string> c, const std::string theC) : Parameter(id,n,d, wt, Parameter::CHOICE){
	triggersRebuild = b;
	choices = c;
	theChoice = theC;
}

ParameterWithChoice::~ParameterWithChoice() {
}

void ParameterWithChoice::print() const {
	std::cout << "ParameterWithChoice" << name << endl;
}
