/*
 * StandardRandomSpherePackingGenerator.h
 *
 *  Created on: Jul 10, 2011
 *      Author: tanlin
 */

#ifndef StandardRandomSpherePackingGenerator_H_
#define StandardRandomSpherePackingGenerator_H_
#include "Generators/Generator.h"
#include "algorithms/ls/RandomPacking.h"
#include "xml/threeD/SpherePrinter.h"
#include "vtk/Visualization.h"
class Parameter;
class StandardRandomSpherePackingGenerator:public Generator {
public:
	StandardRandomSpherePackingGenerator();
	virtual ~StandardRandomSpherePackingGenerator();

	/**
	 * Sets a new parameter and adds it to the list
	 */
	virtual	void setParameter(Parameter* p);

	/**
	 * GeneratesIn file included from Generators/randomSpherePacking/StandardStandardRandomSpherePackingGenerator.cpp:9:
Generators/randomSpherePacking/RandomSpherePackingObject.h: In member function ‘virtual vtkSmartPointer<vtkActor> RandomSpherePackingObject::drawVectors()’:
	 *  DrawableMolecules and saves them in the list
	 */
	virtual void generatePreview();
	/*
	   * load generator without instantiate it
	   */
	void createSampleObject() const;
	/**
	 * Validates if parameters are ok
	 */
	virtual bool validateParameters();

	/**
	 * Creates the parameters and returns them
	 */
	virtual vector<ParameterCollection*> getParameters();
	void generateConfiguration();
	void generateOutput(const std::string& directory);
private:
        int _eventspercycle;
        int _N;
        double _initialpf;
        double _maxpf;
        double _temp;
        double _maxpressure;
        double _growthrate;
        algorithms::ls::RandomPacking SpherePacking;
        bool _spheresP1;
        bool _spheresP2;
        bool _vtk;
        bool _mg;
};

#endif /* StandardStandardRandomSpherePackingGenerator_H_ */
