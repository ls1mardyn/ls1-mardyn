/*
 * RandomSpherePackingGenerator.h
 *
 *  Created on: Jul 10, 2011
 *      Author: tanlin
 */

#ifndef RandomSpherePackingGenerator_H_
#define RandomSpherePackingGenerator_H_
#include "Generators/Generator.h"
#include "algorithms/ls2/RandomPacking.h"
#include "xml/XMLPrinter.h"
#include "vtk/Visualization.h"
class Parameter;
class RandomSpherePackingGenerator:public Generator {
public:
	RandomSpherePackingGenerator();
	virtual ~RandomSpherePackingGenerator();

	/**
	 * Sets a new parameter and adds it to the list
	 */
	virtual	void setParameter(Parameter* p);

	/**
	 * GeneratesIn file included from Generators/randomSpherePacking/RandomSpherePackingGenerator.cpp:9:
Generators/randomSpherePacking/RandomSpherePackingObject.h: In member function ‘virtual vtkSmartPointer<vtkActor> RandomSpherePackingObject::drawVectors()’:
	 *  DrawableMolecules and saves them in the list
	 */
	virtual void generatePreview();
	/*
	   * load generator without instantiate it
	   */
	  const Object* getSampleObject() const;
	/**
	 * Validates if parameters are ok
	 */
	virtual bool validateParameters();

	/**
	 * Creates the parameters and returns them
	 */
	virtual vector<ParameterCollection*> getParameters();
	void generateConfiguration();
	void generateOutput(const std::string& directory);
private:
        int _eventspercycle;
        int _N;
        double _initialpf;
        double _maxpf;
        double _temp;
        double _maxpressure;
        double _various_radius;
        double _growthrate;
        algorithms::ls2::RandomPacking SpherePacking;
        bool _spheresP1;
        bool _spheresP2;
        bool _vtk;
};

#endif /* RandomSpherePackingGenerator_H_ */
