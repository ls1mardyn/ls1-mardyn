/*
 * ChannelGenerator.h
 *
 *  Created on: Dec 13, 2011
 *      Author: tanlin
 */

#ifndef CHANNELGENERATOR_H_
#define CHANNELGENERATOR_H_

#include "Generators/Generator.h"
#include "ChannelObject.h"
class Parameter;
class ChannelGenerator:public Generator {
public:
  ChannelGenerator();
  virtual ~ChannelGenerator();
  /**
   * Sets a new parameter and adds it to the list
   */
  virtual void setParameter(Parameter* p);

  /**
   * Generates DrawableMolecules and saves them in the list
   */
  virtual void generatePreview();
  /*
     * load generator without instantiate it
     */
  void createSampleObject() const;
  /**
   * Validates if parameters are ok
   */
  virtual bool validateParameters();

  /**
   * Creates the parameters and returns them
   */
  virtual vector<ParameterCollection*> getParameters();

  virtual void generateOutput(const std::string& directory);
  double getInitialOrientation();
  double getInitialLength();
  double getInitialWidth();
  double getInitialx();
  double getInitialy();
private:
  double _length;
  double _width;
  double _orientation_minimal;
  double _orientation_maximal;
  int _numObjects;
  std::vector<ChannelObject> _channels;
};
#endif /* CHANNELGENERATOR_H_ */
