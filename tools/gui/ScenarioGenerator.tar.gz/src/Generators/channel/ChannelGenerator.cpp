/*
 * ChannelGenerator.cpp
 *
 *  Created on: Dec 13, 2011
 *      Author: tanlin
 */

#include "ChannelGenerator.h"

#include "Parameters/ParameterWithIntValue.h"
#include "Parameters/ParameterWithDoubleValue.h"
#include "Parameters/ParameterWithBool.h"
#include "QObjects/ScenarioGenerator.h"
#include "ChannelObject.h"
#include "time.h"
#include <vector>
#include <string>
#include <iostream>
#include <cstdio>
#include "xml/twoD/ChannelPrinter.h"
extern "C" {

  Generator* create_generator() {
    return new ChannelGenerator();
  }

  void destruct_generator(Generator* generator) {
    delete generator;
  }
}


ChannelGenerator::ChannelGenerator() : Generator("ChannelGenerator"){
  _numObjects = 50;
  _length=0.5;
  _width=0.02;
  _orientation_maximal=10;
  _orientation_minimal=-40;
}

ChannelGenerator::~ChannelGenerator() {
}


void ChannelGenerator::setParameter(Parameter* p) {
  std::cout << "SetParameter for param" << p->getNameId() << endl;
  std::string id = p->getNameId();

  if (id == "numObjects") {
      std::cout << "Setting numObjects!" << std::endl;
      _numObjects = static_cast<ParameterWithIntValue*>(p)->getValue();
  }
  else if (id == "length") {
      std::cout << "Setting length!" << std::endl;
      _length = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "width") {
      std::cout << "Setting width!" << std::endl;
      _width = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "orientation_minimal") {
      std::cout << "Setting orientation_minimal!" <<std::endl;
      _orientation_minimal = static_cast<ParameterWithDoubleValue*> (p)->getValue();
      std::cout<<"Setting orientation_minimal: "<< static_cast<ParameterWithDoubleValue*>(p)->getValue()<<endl;
  }
  else if (id == "orientation_maximal") {
      std::cout << "Setting orientation_maximal!" <<std::endl;
      _orientation_maximal = static_cast<ParameterWithDoubleValue*> (p)->getValue();
      std::cout<<"Setting orientation_maximal: "<< static_cast<ParameterWithDoubleValue*>(p)->getValue()<<endl;
  }
  std::cout << "Parameter value is set!" << endl;
  std::cout << "Debug: #Channels in array: " <<_channels.size() <<endl;
}


bool ChannelGenerator::validateParameters() {
  bool isValid = true;

  if (_numObjects <= 0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                      << "Number of objects has to be greater 0!" << std::endl;
      isValid = false;
  }

  if (_length < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                              << "Object length has to be greater 0!" << std::endl;
      isValid = false;
  }
  return isValid;
}

void ChannelGenerator::generateOutput(const std::string& directory) {
  if(directory!=""){
      xml::twoD::ChannelPrinter output;
      std::stringstream fileNameWithPath;
      fileNameWithPath <<directory << "/p1-channels-" <<_numObjects <<".txt";
      //      std::string filename = directory + "/p1-channels-" +(std::string)_numObjects +"-" +(std::string)_channels.size() +".xml";
      output.printP1Channels(_channels,"1/3","1/27",fileNameWithPath.str());
      std::stringstream rotatedOutputfileNameWithPath;
      rotatedOutputfileNameWithPath <<directory << "/p1-channels-" <<_numObjects <<"-rotated.txt";
      output.rotateAndPrintP1Channels(_channels,"1/3","1/27",rotatedOutputfileNameWithPath.str());
  }
}


vector<ParameterCollection*> ChannelGenerator::getParameters() {
  vector<ParameterCollection*> parameters;
  ParameterCollection* tab = new ParameterCollection("ChannelCollection", "ChannelCollection",
      "ChannelCollection", Parameter::BUTTON);
  parameters.push_back(tab);

  tab->addParameter(
      new ParameterWithIntValue("numObjects",
          "Number of Objects", "The number of objects which is created and displayed",
          Parameter::LINE_EDIT,  false, _numObjects));

  tab->addParameter(
      new ParameterWithDoubleValue("length",
          "Object length", "The length of objects", Parameter::LINE_EDIT,
          false, _length));
  tab->addParameter(
      new ParameterWithDoubleValue("width",
          "Object width", "The width of objects", Parameter::LINE_EDIT,
          false, _width));
  tab->addParameter(
      new ParameterWithDoubleValue("orientation_minimal",
          "Object orientation_minimal", "The orientation_minimal of objects", Parameter::LINE_EDIT,
          false, _orientation_minimal));
  tab->addParameter(
      new ParameterWithDoubleValue("orientation_maximal",
          "Object orientation_maximal", "The orientation_maximal of objects", Parameter::LINE_EDIT,
          false, _orientation_maximal));
  return parameters;
}


// Just generate some dummy molecules...
void ChannelGenerator::generatePreview() {
  double x,y;
  int id = 1;
  double orientation,length,width;
  clock_t start,end;
  length=getInitialLength();
  width=getInitialWidth();
  srand((unsigned)time(NULL));
  _channels.clear();

  start=clock();
  for(int i=0;i<_numObjects;i++){
      x=getInitialx();
      y=getInitialy();
      orientation=getInitialOrientation();
      _channels.push_back(ChannelObject(x,y,orientation,length,width,id));
      ScenarioGeneratorApplication::getInstance()->addObject(
          new ChannelObject(x,y,orientation,length,width,id));
      id++;
  }
  end=clock();
  double time=(double)(end-start)/CLOCKS_PER_SEC;
  ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                         << "time to generate the channels is "<< time<<" s" << std::endl;
}

void ChannelGenerator::createSampleObject() const {
  ScenarioGeneratorApplication::getInstance()->addObject(
      new ChannelObject(0,0,0,0.2, 0.02, 1));
}
double ChannelGenerator::getInitialOrientation(){
  double orientation;
  if(_orientation_maximal-_orientation_minimal!=0){
      orientation=_orientation_minimal+(rand() % (int)(_orientation_maximal-_orientation_minimal));
  }
  else
    orientation=_orientation_minimal;
  return orientation;
}
double ChannelGenerator::getInitialLength(){
  double length=_length;
  return length;
}
double ChannelGenerator::getInitialWidth(){
  double width=_width;
  return width;
}
double ChannelGenerator::getInitialx(){
  double x=rand()/(double)(RAND_MAX)*1;
  return x;
}
double ChannelGenerator::getInitialy(){
  double y=rand()/(double)(RAND_MAX)*1;
  return y;
}
