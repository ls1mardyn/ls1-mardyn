/*
 * ChannelObject.cpp
 *
 *  Created on: Dec 13, 2011
 *      Author: tanlin
 */

#include "ChannelObject.h"
#include <vtkQuad.h>
#include <vtkUnstructuredGrid.h>
#include <vtkDataSetMapper.h>
#include <cmath>
ChannelObject::ChannelObject(double x, double y, double angle, double length,double width, unsigned long id) :
_position(x, y, angle), _length(length),_width(width),_id(id) {

}

ChannelObject::~ChannelObject() {
  // TODO Auto-generated destructor stub
}


vtkSmartPointer<vtkActor> ChannelObject::draw(int numMols) {
  return drawchannel( _position,_length,_width, true);
}

std::vector<std::string> ChannelObject::getDrawableValues()const{
  std::vector<std::string> v;
  v.push_back("Channel");
  v.push_back("Channel ID");
  return v;
}

vtkSmartPointer<vtkActor> ChannelObject::draw(string valueName) {
      return drawchannel( _position,_length,_width, true);
  }


vtkSmartPointer<vtkActor> ChannelObject::drawchannel(Position& position, double length,
    double width,bool color) {

  double initialx=position.x-length/2;
  double initialy=position.y-width/2;
  double xmove=position.x;
  double ymove=position.y;
  std::pair<double,double> firstpoint;
  firstpoint.first=initialx;
  firstpoint.second=initialy;
  firstpoint=rotation(firstpoint,position.z,xmove,ymove);
  std::pair<double,double> secondpoint;
  secondpoint.first=initialx+length;
  secondpoint.second=initialy;
  secondpoint=rotation(secondpoint,position.z,xmove,ymove);
  std::pair<double,double> thirdpoint;
  thirdpoint.first=initialx+length;
  thirdpoint.second=initialy+width;
  thirdpoint=rotation(thirdpoint,position.z,xmove,ymove);
  std::pair<double,double> fourthpoint;
  fourthpoint.first=initialx;
  fourthpoint.second=initialy+width;
  fourthpoint=rotation(fourthpoint,position.z,xmove,ymove);
  vtkSmartPointer<vtkPoints> points =
              vtkSmartPointer<vtkPoints>::New();
            points->SetNumberOfPoints(4);
            points->InsertPoint(0,firstpoint.first,firstpoint.second,0);
            points->InsertPoint(1,secondpoint.first,secondpoint.second,0);
            points->InsertPoint(2,thirdpoint.first,thirdpoint.second,0);
            points->InsertPoint(3,fourthpoint.first,fourthpoint.second,0);

            vtkSmartPointer<vtkQuad> Quad =
              vtkSmartPointer<vtkQuad>::New();
            Quad->GetPointIds()->SetId(0,0);
            Quad->GetPointIds()->SetId(1,1);
            Quad->GetPointIds()->SetId(2,2);
            Quad->GetPointIds()->SetId(3,3);

            vtkSmartPointer<vtkUnstructuredGrid> polyData =
              vtkSmartPointer<vtkUnstructuredGrid>::New();
            polyData->SetPoints(points);
            polyData->Allocate(1,1);
            polyData->InsertNextCell(Quad->GetCellType(),Quad->GetPointIds());

            vtkSmartPointer<vtkDataSetMapper> mapper =
              vtkSmartPointer<vtkDataSetMapper>::New();
            mapper->SetInput(polyData);
            vtkSmartPointer<vtkActor> actor =
              vtkSmartPointer<vtkActor>::New();
            actor->SetMapper(mapper);
            actor->GetProperty()->SetColor(1, 0, 0);
  return actor;
}

float* ChannelObject::convFloatToRGB(float ratio) {
  float* rgb = new float[3];
  //rgb.resize(3);
  if (ratio <= 0.25) {
      rgb[2] = 1;
      rgb[1] = 2 * ratio;
      rgb[0] = ratio;
  } else if (ratio <= 0.5) {
      rgb[2] = -2 * ratio + 1.5;
      rgb[1] = 2 * ratio;
      rgb[0] = ratio;
  } else if (ratio <= 0.75) {
      rgb[2] = 1 - ratio;
      rgb[1] = -2 * ratio + 2;
      rgb[0] = 2 * ratio - 0.5;
  } else if (ratio <= 1) {
      rgb[2] = 1 - ratio;
      rgb[1] = -2 * ratio + 2;
      rgb[0] = 1;
  }

  return rgb;
}
std::pair<double,double> ChannelObject::rotation(std::pair<double,double> point,double orientation,double xmove, double ymove){
    double x=point.first-xmove;
    double y=point.second-ymove;
    double _PI=3.14159265;
    double sint=sin(orientation*_PI/180);
    double cost=cos(orientation*_PI/180);
    std::pair<double,double> newpoint;
    newpoint.first=cost*x-sint*y+xmove;
    newpoint.second=sint*x+cost*y+ymove;
    return newpoint;
}
