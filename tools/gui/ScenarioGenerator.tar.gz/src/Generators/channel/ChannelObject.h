/*
 * ChannelObject.h
 *
 *  Created on: Dec 13, 2011
 *      Author: tanlin
 */

#ifndef CHANNELOBJECT_H_
#define CHANNELOBJECT_H_

#include "Objects/Object.h"
#include <iostream>

class ChannelObject: public Object {
public:

        ChannelObject(double x, double y, double angle, double length,double width, unsigned long id);
        virtual ~ChannelObject();
        virtual vtkSmartPointer<vtkActor> draw(int);
        vtkSmartPointer<vtkActor> drawchannel(Position& position, double length,
                                double width,bool color);

        virtual vtkSmartPointer<vtkActor> drawVectors() {
                std::cout <<"ERROR call of unsupported function! DummyObject::drawVectors(); No vectors to draw";
                exit(-1);
                return NULL;
        }
        virtual vtkSmartPointer<vtkActor> draw(string valueName);
        virtual std::vector<std::string> getDrawableValues() const;

        float* convFloatToRGB(float ratio);
        std::pair<double,double> rotation(std::pair<double,double> point,double orientation,double xmove,double ymove);

        Position _position;
        double _length;
        double _width;
        int _id;
};
#endif /* CHANNELOBJECT_H_ */
