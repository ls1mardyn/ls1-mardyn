/*
 * Generator.h
 *
 *  Created on: Mar 25, 2011
 *      Author: kovacevt
 */
#include <iostream>
#include <list>
#include <vector>
#include "Parameters/Parameter.h"
#include "Parameters/ParameterCollection.h"
#include "IO/WriteOutput.h"
#include "Objects/Object.h"

using namespace std;
class ScenarioGeneratorApplication;

#ifndef GENERATOR_H_
#define GENERATOR_H_

/**
 * Declaration of the factory functions. Every generator which should be loaded
 * from a library has to implement these functions. For more details, see the
 * - Program Library HOWTO
 * - C++ dlopen mini howto
 */
extern "C" {

	/**
	 * create a new instance of a generator.
	 */
	Generator* create_generator();

	/**
	 * delete an instance of a generator
	 */
	void destruct_generator(Generator* generator);
}

/**
 * Generator inteface
 */
class Generator {
protected:

	/**
	 * Constructor
	 */
	Generator(const std::string& name) {
		_name = name;
	}

	std::string _name;

public:

	/**
	 * Destructor
	 */
	virtual ~Generator() {}

	/**
	 * Returns the generator name
	 * @return name of the generator
	 */
	string getName(){ return _name;}

	/**
	 * load the parameters of this generator from file filename.
	 *
	 * @note This method provides a default implementation reading input from a
	 *       simple text file using key-value pairs. Overwrite this method to
	 *       use a more sophisticated load / store functionality!
	 */
	virtual void load(const std::string& filename) {
		WriteOutput::loadGeneratorConfiguration(*this, filename);
	}

	/**
	 * save the parameters of this generator to file filename.
	 *
	 * @note This method provides a default implementation writing output to a
	 *       simple text file using key-value pairs. Overwrite this method to
	 *       use a more sophisticated load / store functionality!
	 */
	virtual void save(const std::string& filename) {
		WriteOutput::saveGeneratorConfiguration(*this, filename);
	}

	/*********************************************************/
	/*** Interface methods to be implemented by subclasses ***/
	/*********************************************************/

	/**
	 * Creates parameters and puts them into the list of parameters.
	 * The caller is responsible for destructing the objects returned!
	 *
	 * Each collection contained the vector will be displayed in a seperate tab.
	 *
	 * @return generator parameters
	 */
	virtual vector<ParameterCollection*> getParameters() = 0;

	/**
	* Sets a new parameter and adds it to the list
	*/
	virtual	void setParameter(Parameter* p) = 0;

	/**
	 * Validates if parameters are ok
	 */
	virtual bool validateParameters() = 0;

	/**
	 * Generates Objects and saves them in the list
	 */
	virtual void generatePreview() = 0;

	/*
	 * Return an sample object of the type which will be drawn later on.
	 *
	 * @note the object has to be allocated with new(), and will be destroyed by the
	 *       gui later on.
	 */
	virtual const Object* getSampleObject() const = 0;

	/**
	 * Writes output file(s) to the selected directory.
	 */
	virtual void generateOutput(const std::string& directory) = 0;

};

#endif /* GENERATOR_H_ */
