/*
 * DummyObject.cpp
 *
 * @Date: 06.07.2011
 * @Author: eckhardw
 */

#include "DummyObject.h"

DummyObject::DummyObject(double x0, double x1, double x2, unsigned long id) :
	_position(x0, x1, x2), _id(id) {

}

DummyObject::~DummyObject() {
}

vtkSmartPointer<vtkActor> DummyObject::draw(int numMols) {
	return drawValue(_position, _id, 0, numMols, true);
}

std::vector<std::string> DummyObject::getDrawableValues() const {

	std::vector<std::string> v;
	v.push_back("Sphere"); // just black spheres
	v.push_back("Sphere ID"); // spheres with colors representing their ID
	return v;

}

vtkSmartPointer<vtkActor> DummyObject::draw(string valueName){
	if (valueName == "Sphere"){
		return drawValue(_position, _id, 0, _numObjects, false);
	} else if (valueName == "Sphere ID"){
		return drawValue(_position, _id, 0, _numObjects, true);
	}
}
