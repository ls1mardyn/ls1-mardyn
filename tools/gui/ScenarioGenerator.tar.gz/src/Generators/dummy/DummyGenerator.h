/*
 * DummyGenerator.h
 *
 * @Date: 28.05.2011
 * @Author: eckhardw
 */

#ifndef DUMMYGENERATOR_H_
#define DUMMYGENERATOR_H_

#include "Generators/Generator.h"

class Parameter;

class DummyGenerator : public Generator {
public:

  DummyGenerator();

  virtual ~DummyGenerator();

  /**
   * Sets a new parameter and adds it to the list
   */
  virtual	void setParameter(Parameter* p);

  /**
   * Generates DrawableMolecules and saves them in the list
   */
  virtual void generatePreview();
  /*
   * load generator without instantiate it
   */
  const Object* getSampleObject() const;

  /**
   * Validates if parameters are ok
   */
  virtual bool validateParameters();

  /**
   * Creates the parameters and returns them
   */
  virtual vector<ParameterCollection*> getParameters();

  void generateOutput(const std::string& directory) {}


private:
  int _numObjects;
  double _objectSpacing;
  bool _dummyBoolValue;
};

#endif /* DUMMYGENERATOR_H_ */
