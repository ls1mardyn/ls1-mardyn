/*
 * MixSpherePackingGenerator.h
 *
 *  Created on: Jul 10, 2011
 *      Author: tanlin
 */

#ifndef MixSpherePackingGenerator_H_
#define MixSpherePackingGenerator_H_
#include "Generators/Generator.h"
#include "algorithms/regularpacking/RegularPacking.h"
#include "algorithms/AbstractSpherePacking.h"
#include "xml/XMLPrinter.h"
#include "vtk/Visualization.h"

class Parameter;
class MixSpherePackingGenerator:public Generator {
public:
  MixSpherePackingGenerator();
  virtual ~MixSpherePackingGenerator();
  /**
   * Sets a new parameter and adds it to the list
   */
  virtual void setParameter(Parameter* p);

  /**
   * Generates DrawableMolecules and saves them in the list
   */
  virtual void generatePreview();
  /*
     * load generator without instantiate it
     */
  const Object* getSampleObject() const;
  /**
   * Validates if parameters are ok
   */
  virtual bool validateParameters();

  /**
   * Creates the parameters and returns them
   */
  virtual vector<ParameterCollection*> getParameters();

  void generateOutput(const std::string& directory);
private:
  double _distance;
  double _radius;
  double _radius2;
  double _density;
  double _density2;
  bool _spheresP1;
  bool _spheresP2;
  bool _vtk;
  algorithms::regularpacking::RegularPacking SpherePacking;
};

#endif /* MixSpherePackingGenerator_H_ */
