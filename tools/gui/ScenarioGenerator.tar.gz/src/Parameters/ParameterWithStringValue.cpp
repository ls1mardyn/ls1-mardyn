/*
 * ParameterWithStringValue.cpp
 *
 * @Date: 07.09.2011
 * @Author: eckhardw
 */

#include "ParameterWithStringValue.h"
#include <iostream>

ParameterWithStringValue::ParameterWithStringValue(const std::string id, const std::string n, const std::string d, WidgetType wt, const bool b, const std::string value)
: ParameterWithValue(id,n,d,wt,b, Parameter::STRING), _value(value) {
}

ParameterWithStringValue::~ParameterWithStringValue() {
}

void ParameterWithStringValue::setStringValue(const std::string& value) {
	_value = value;
}

string ParameterWithStringValue::getStringValue() const {
	return _value;
}

void ParameterWithStringValue::print() const {
	std::cout << "ParameterWithStringValue " << name << " value="<< _value << endl;
}
