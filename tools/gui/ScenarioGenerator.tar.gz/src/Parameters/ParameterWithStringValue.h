/*
 * ParameterWithStringValue.h
 *
 * @Date: 07.09.2011
 * @Author: eckhardw
 */

#ifndef PARAMETERWITHSTRINGVALUE_H_
#define PARAMETERWITHSTRINGVALUE_H_

#include "Parameters/ParameterWithValue.h"
#include <string>

class ParameterWithStringValue : public ParameterWithValue {

private:
	std::string _value;

public:

	/**
	 * Constructor
	 * @param id nameId
	 * @param n name
	 * @param d description
	 * @param b if it triggers gui rebuild
	 * @param v value
	 */
	ParameterWithStringValue(const std::string Id, const std::string name, const std::string description, WidgetType wt, const bool b, const std::string value);

	virtual ~ParameterWithStringValue();

	std::string getStringValue() const;

	void setStringValue(const std::string& value);

	void print() const;
};

#endif /* PARAMETERWITHSTRINGVALUE_H_ */
