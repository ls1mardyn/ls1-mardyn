/*
 * Parameter.h
 *
 *  Created on: Mar 25, 2011
 *      Author: kovacevt
 */
#include <string>

using namespace std;

#ifndef PARAMETER_H_
#define PARAMETER_H_

/**
 * Class Parameter depicts a parameter which can be used to generate objects
 */
class Parameter {

public:
	enum Type {
		INT, DOUBLE, CHOICE, COMPOSITE, BOOL, STRING
	};

	enum WidgetType {
		LINE_EDIT,BUTTON,LIST,CHECKBOX, SPINBOX, COMBOBOX
	};

protected:
	std::string name; // name of the parameter
	std::string nameId; // unique name ID of the parameter, has to be the same like the name of the value it is changing
	std::string description; // description to be displayed
	WidgetType widgetType;

	Type _type;
public:
	/**
	 * Constructor
	 */
	Parameter(const std::string id, const std::string name, const std::string description, WidgetType wt, Type type);

	/**
	 * Destructor
	 */
	virtual ~Parameter();


	//getters
	Type getType() const {
		return _type;
	}

	string getName() const {
		return name;
	}

	string getNameId() const {
		return nameId;
	}

	string getDescription() const {
		return description;
	}

	WidgetType getWidgetType() const {
		return widgetType;
	}

	/**
	 * Tells us if this parameter triggers GUI Rebuild
	 */
	virtual bool requiresGUIRebuild() const {
		return false;
	}

	virtual void print() const = 0;

	virtual std::string getStringValue() const = 0;

	virtual void setStringValue(const std::string& value) = 0;
};

#endif /* PARAMETER_H_ */
