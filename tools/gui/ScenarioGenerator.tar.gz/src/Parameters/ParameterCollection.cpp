/*
 * ParameterCollection.cpp
 *
 *  Created on: May 4, 2011
 *      Author: kovacevt
 */

/**
 * Parameter Collection (Composite DP) represents the composite of ParameterWithValues
 * Upon clicking the button showParsButton, it will create the GUI which contains Parameters
 * from the collection
 *   TODO: in ScenarioGeneratorApplication create a vector of buttons which are extracted from
 *  collections of parameters (for each such Parameter, the button puts itself into the vector),
 *  and then when a slot connecting to  SpecialButton::clicked() is called, check through the
 *  class SpecialButton's slot the name of the button that was clicked and corresponding pars
 */
#include "Parameters/ParameterCollection.h"
#include <iostream>

ParameterCollection::ParameterCollection(const std::string id, const std::string n, const std::string d,
		WidgetType wt, bool loadOption, bool storeOption) :
Parameter(id,n,d,wt, Parameter::COMPOSITE), _hasLoadOption(loadOption), _hasStoreOption(storeOption) , _stringValue("") {
}

ParameterCollection::~ParameterCollection() {

}

void ParameterCollection::addParameter(Parameter* p){
	parameters.push_back(p);
}


void ParameterCollection::print() const {
	std::cout << "ParameterCollection: " << endl;
	list<Parameter*>::const_iterator it= parameters.begin();
	while(it != parameters.end()) {
		(*it)->print();
		it++;
	}
}


void ParameterCollection::deleteParameter(Parameter* parameter) {
	if (parameter->getType() == Parameter::COMPOSITE) {
		list<Parameter*> parameters = static_cast<ParameterCollection*>(parameter)->getParameters();
		for (list<Parameter*>::iterator it = parameters.begin(); it != parameters.end(); it++) {
			deleteParameter(*it);
		}
	}

	delete parameter;
}

Parameter* ParameterCollection::findParameter(ParameterCollection* collection, const std::string& name) {

	if (collection->getNameId() == name) {
		return collection;
	}

	list<Parameter*> parameters = collection->getParameters();

	for (list<Parameter*>::iterator it = parameters.begin(); it != parameters.end(); it++) {
		if ((*it)->getNameId() == name) {
			return (*it);
		} else if ((*it)->getType() == Parameter::COMPOSITE) {
			Parameter* returnValue = findParameter(dynamic_cast<ParameterCollection*>(*it), name);
			if (returnValue != NULL) {
				return returnValue;
			}
		}
	}

	return NULL;
}
