/*
 * ParameterWithValue.cpp
 *
 *  Created on: May 4, 2011
 *      Author: kovacevt
 */

#include "Parameters/ParameterWithIntValue.h"
#include "Conversions.h"

ParameterWithIntValue::ParameterWithIntValue(const std::string id, const::string n, const std::string d, WidgetType wt, const bool b, const int v)
: ParameterWithValue(id,n,d,wt,b, Parameter::INT){
	value = v;
}

ParameterWithIntValue::~ParameterWithIntValue() {

}

void ParameterWithIntValue::setStringValue(const std::string& text){
	istringstream myStream(text);
	myStream >> value;
}


void ParameterWithIntValue::print() const {
	std::cout << "ParameterWithIntValue " << name << " value="<< value << endl;
}

string ParameterWithIntValue::getStringValue() const {
	stringstream valueStream;
	valueStream << value;
	return valueStream.str();
}
