/*
 * Conversions.h
 *
 *  Created on: May 28, 2011
 *      Author: kovacevt
 */

#ifndef CONVERSIONS_H_
#define CONVERSIONS_H_

#include <iostream>
#include <sstream>

//char* itoa(int,int);
int max(int,int);

/**
 * Convert a string to a given type T.
 */
template <typename T>
T convertFromString(const std::string& arg) {
	std::stringstream stream(arg);
	T retVal;
	stream >> retVal;
	return retVal;
}


/**
 * Convert a string to a given type T.
 */
template <typename T>
T convertFromChar(const char& arg) {
	std::stringstream stream;
	stream << arg;
	T retVal;
	stream >> retVal;
	return retVal;
}

/**
 * Convert a given type T to a string.
 */
template <typename T>
std::string convertToString(const T& arg) {
	std::stringstream stream;
	stream << arg;
	return stream.str();
}

#endif /* CONVERSIONS_H_ */
