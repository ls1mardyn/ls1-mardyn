/*
 * QTextMessageField.h
 *
 * @Date: 09.08.2011
 * @Author: eckhardw
 */

#ifndef QTEXTMESSAGEFIELD_H_
#define QTEXTMESSAGEFIELD_H_

#include <qplaintextedit.h>
 #include <QCoreApplication>

#include <iostream> // to be removed!

#include <ostream>
#include <streambuf>
//#include <bits/postypes.h>

// actually we shouldn't need this typedef here, it should be known already.
// copied from (bits/postypes.h)
//typedef ptrdiff_t	streamsize;

class QTextMessageField : public QPlainTextEdit {

private:

	class TextfieldStream : public std::streambuf{

	private:
		QTextMessageField& _textField;
		QTextCharFormat _format;

	public:
	    TextfieldStream(QTextMessageField& textField) : _textField(textField) {
	    	_format.setForeground(QBrush(Qt::blue));
	    }

	    ~TextfieldStream(){ }

	protected:
	    // actually we should use return type streamsize, which is a typedef for
	    // ptrdiff_t, however for some reason my compiler likes the typedef only
	    // every second time...

	    //virtual streamsize xsputn(const char *msg, streamsize count){
	    virtual ptrdiff_t xsputn(const char *msg, ptrdiff_t count){
	        std::string s(msg,count);
	        _textField.textCursor().insertText(s.c_str(), _format);
	        _textField.ensureCursorVisible();

	        // actually we should do that multithreaded...
	        QCoreApplication::processEvents();
	        return count;
	    }

	    int_type overflow(int_type c) {
	        if(!traits_type::eq_int_type(c, traits_type::eof())) {
	            char_type const t = traits_type::to_char_type(c);
	            this->xsputn(&t, 1);
	        }
	        return !traits_type::eof();
	    }

	    int sync() {
	        return 0;
	    }

	};


public:

	QTextMessageField();

	virtual ~QTextMessageField();

	std::ostream& getTextMessageStream() {
		return _outStream;
	}

private:

	TextfieldStream _textFieldStream;
	std::ostream _outStream;
};

#endif /* QTEXTMESSAGEFIELD_H_ */
