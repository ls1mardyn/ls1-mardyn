/*
 * WidgetFactory.cpp
 *
 *  Created on: Jun 9, 2011
 *      Author: kovacevt
 */

#include "WidgetFactory.h"

#include "Parameters/Parameter.h"
#include "Parameters/ParameterWithValue.h"
#include "Parameters/ParameterWithChoice.h"
#include "Parameters/ParameterCollection.h"
#include "Parameters/ParameterWithBool.h"
#include "QParCheckBox.h"
#include "QParSpinBox.h"
#include "QParButton.h"
#include "QParLineEdit.h"
#include "QParListWidget.h"
#include "QParComboBox.h"

#include <iostream>

WidgetFactory::WidgetFactory() {
}

WidgetFactory::~WidgetFactory() {
}

QWidget* WidgetFactory::createWidget(Parameter* p) {
	Parameter::WidgetType type = p->getWidgetType();

	switch (type) {
	case Parameter::LINE_EDIT:
		return new QParLineEdit(static_cast<ParameterWithValue*> (p));

	case Parameter::BUTTON: {
		return new QParButton(static_cast<ParameterCollection*> (p));
	}

	case Parameter::LIST: {
		QParListWidget* listOfChoices = new QParListWidget(static_cast<ParameterWithChoice*> (p));
		return listOfChoices;
	}

	case Parameter::COMBOBOX: {
		return new QParComboBox(static_cast<ParameterWithChoice*> (p));
	}

	case Parameter::CHECKBOX: {
		return new QParCheckBox(static_cast<ParameterWithBool*>(p));
	}

	case Parameter::SPINBOX: {
		return new QParSpinBox(static_cast<ParameterWithIntValue*> (p));
	}
	}
	std::cout << "Error: Unknown Widget Type! Parameter Name="<< p->getName() << endl;
	return NULL;
}
