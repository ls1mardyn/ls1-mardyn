/*
 * QParCheckBox.cpp
 *
 *  Created on: Jun 25, 2011
 *      Author: kovacevt
 */

#include "QParCheckBox.h"
#include <Parameters/ParameterWithBool.h>
#include <Qt>
#include "ScenarioGenerator.h"
#include "Generators/Generator.h"

QParCheckBox::QParCheckBox(ParameterWithBool* par):parameter(par){
	if (parameter->getValue() == true) {
		this->setCheckState(Qt::Checked);
	}
	else {
		this->setCheckState(Qt::Unchecked);
	}
	resize(25,25);
	this->setToolTip(QString::fromStdString(parameter->getDescription()));
	connect(this, SIGNAL(stateChanged(int)), this, SLOT(setNewValue()));
}

QParCheckBox::~QParCheckBox() {
}

void QParCheckBox::setNewValue(){
	Qt::CheckState state = this->checkState();
	if (state == Qt::Checked){
		parameter->setValue(true);
	} else if (state == Qt::Unchecked) {
		parameter->setValue(false);
	}

	ScenarioGeneratorApplication::getInstance()->getCurrentGenerator()->setParameter(
					parameter);
	if (parameter->requiresGUIRebuild()){
		ScenarioGeneratorApplication::getInstance()->getMainWindow()->updateAllPanels();
	}
}
