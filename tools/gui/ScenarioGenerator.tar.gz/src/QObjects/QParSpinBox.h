/*
 * QParSpinBox.h
 *
 *  Created on: Jun 25, 2011
 *      Author: kovacevt
 */
#include <qspinbox.h>
#include "Parameters/ParameterWithIntValue.h"

#ifndef QPARSPINBOX_H_
#define QPARSPINBOX_H_

class ScenarioGeneratorApplication;
class Generator;

class QParSpinBox: public QSpinBox {
	Q_OBJECT

private:
	int val;
	ParameterWithIntValue* parameter;

public:
	QParSpinBox(ParameterWithIntValue* par);
	virtual ~QParSpinBox();

public slots:
	void setNewValue();

};

#endif /* QPARSPINBOX_H_ */
