/*
 * ScenarioGeneratorApplication.h
 *
 *  Created on: Mar 25, 2011
 *      Author: kovacevt
 */

//singelton
#ifndef SCENARIOGENERATOR_H_
#define SCENARIOGENERATOR_H_

#include "Objects/Object.h"
#include "Parameters/Parameter.h"
#include "Parameters/ParameterCollection.h"
#include <list>
#include <vector>
#include <iostream>
#include <QObject>
#include "QObjects/QPanel.h"
#include <QtGui>
#include "QVTKWidget.h"
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkPolyData.h>
#include <vtkSmartPointer.h>
#include <vtkSphereSource.h>
#include <vtkInteractorStyleTrackballCamera.h>
#include <vtkInteractorStyleTrackball.h>
#include "WidgetFactory.h"

#include "QObjects/MainWindow.h"

using namespace std;

class Generator;
class WriteOutput;


/**
 * ScenarioGeneratorApplication is the model class. It creates and draws GUI. It is the Q_Object
 * class. Implements Singleton DP.
 */

class ScenarioGeneratorApplication: public QSplitter {
Q_OBJECT

private:

	Generator* currentGenerator; // generator used to genrate objects
	list<Generator*> generators; // all possible generators
	list<Object*> objects; // all objects

	MainWindow* _mainWindow;

	QString _lastWriteOutputPath;

	QString _lastLoadSaveConfigPath;

	/**
	 * Constructor - private (Singleton)
	 */
	ScenarioGeneratorApplication(QWidget* parent = 0);

	static ScenarioGeneratorApplication* instance; // instance
public:
	~ScenarioGeneratorApplication();
	/**
	 * Gets the instance
	 * @return Instance of the Singleton class ScenarioGeneratorApplication
	 */
	static ScenarioGeneratorApplication* getInstance();

	/**
	 * Builds GUI and displays objects. Should be called after all generators
	 * have been added.
	 */
	void showGui();

	MainWindow* getMainWindow() {
		return _mainWindow;
	}

	/**
	 * Adds an object to the list of objects
	 * @param Object m Object to add
	 */
	void addObject(Object* m) {
		objects.push_back(m);
	}

	/**
	 * Adds a generator to the list
	 * @param g generator to add
	 */
	void addGenerator(Generator* g) {
		generators.push_back(g);
		setCurrentGenerator(g);
	}

	/**
	 * sets generator to use for generating objects and deletes
	 * all previously created labels, buttons and line edits
	 * @param g Generator to set as current
	 */
	void setCurrentGenerator(Generator* g);


	/**
	 * Sets the current generator to the selected one
	 * rebuilds GUI
	 */
	void setCurrentGenerator(const std::string& generatorName);

	Generator* getCurrentGenerator() {
		return currentGenerator;
	}

	const list<Generator*>& getGenerators() {
		return generators;
	}

	const std::list<Object*>& getObjects();

	ostream& getTextMessageStream() const {
		return _mainWindow->getTextMessageStream();
	}

public slots:

	/**
	 * Upon clicking on the corresponding button, rebuilds the view of molecules
	 */
	void rebuildPreview();

	/*
	 * Stores current parameters
	 */
	void generatorStore();

	void writeOutput();

	void generatorLoad();


};

#endif /* SCENARIOGENERATOR_H_ */
