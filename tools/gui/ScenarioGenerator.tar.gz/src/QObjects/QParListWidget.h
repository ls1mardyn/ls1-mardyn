/*
 * QParListWidget.h
 *
 *  Created on: May 14, 2011
 *      Author: kovacevt
 */


#include <qlistwidget.h>

class ParameterWithChoice;
class ScenarioGeneratorApplication;

#ifndef QPARLISTWIDGET_H_
#define QPARLISTWIDGET_H_

class QParListWidget: public QListWidget {
	Q_OBJECT

private:
	ParameterWithChoice* _parameter;

public:
	QParListWidget(ParameterWithChoice* const par);

	virtual ~QParListWidget();

public slots:
	void setNewChoice();

};

#endif /* QPARLISTWIDGET_H_ */
