/*
 * QParButton.h
 *
 * This class represents a button upon clicking which Parameters
 * are to be displayed on a QWidget window
 * Used in ParameterCollectionButton
 *  Created on: May 8, 2011
 *      Author: kovacevt
 */

#include <qpushbutton.h>
#include "QPanel.h"

using namespace std;

class ParameterCollection;

#ifndef QPARBUTTON_H_
#define QPARBUTTON_H_

class QParButton: public QPushButton {
	Q_OBJECT

private:
	ParameterCollection* collectionParameter; // parameter who contains an instance of this class

public:
	/**
	 * Constructor
	 * @param parameter ParameterCollection that reacts on this button
	 */
	QParButton(ParameterCollection* const parameter);

	virtual ~QParButton();

public slots:

	/**
 	 * Reacts on clicking the button
 	 */
	QPanel* createDisplayPanel();

};

#endif /* QPARBUTTON_H_ */
