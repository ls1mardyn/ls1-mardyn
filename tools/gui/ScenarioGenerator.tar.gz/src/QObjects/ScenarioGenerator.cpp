/*
 * ScenarioGeneratorApplication.cpp
 *
 *  Created on: Mar 25, 2011
 *      Author: kovacevt
 */
#include "Generators/Generator.h"
#include "IO/WriteOutput.h"
#include "QObjects/ScenarioGenerator.h"
#include "WidgetFactory.h"

ScenarioGeneratorApplication* ScenarioGeneratorApplication::instance = NULL;

ScenarioGeneratorApplication::ScenarioGeneratorApplication(QWidget* parent) :
		QSplitter(parent), currentGenerator(NULL), _mainWindow(NULL) {
	objects.clear();
	_lastWriteOutputPath = QDir::currentPath();
	_lastLoadSaveConfigPath = QDir::currentPath();
}

ScenarioGeneratorApplication* ScenarioGeneratorApplication::getInstance() {
	if (!instance)
		instance = new ScenarioGeneratorApplication;
	return instance;
}

ScenarioGeneratorApplication::~ScenarioGeneratorApplication() { }

void ScenarioGeneratorApplication::showGui() {
	_mainWindow = new MainWindow(this);
	_mainWindow->show();
}


void ScenarioGeneratorApplication::setCurrentGenerator(Generator* g) {
	currentGenerator = g;

	list<Object*>::iterator itObjects;
	for (itObjects = objects.begin(); itObjects != objects.end(); itObjects++) {
		delete (*itObjects);
	}
	objects.clear();
	_mainWindow->rebuildTabPanels();
}


void ScenarioGeneratorApplication::rebuildPreview() {
	list<Object*>::iterator itObjects;
	for (itObjects = objects.begin(); itObjects != objects.end(); itObjects++) {
		delete (*itObjects);
	}
	objects.clear();

	_mainWindow->drawSelectedValue();
}

void ScenarioGeneratorApplication::setCurrentGenerator(const std::string & generatorName) {
	list<Generator*>::iterator itg;
	for (itg = generators.begin(); itg != generators.end(); itg++) {
		if ((*itg)->getName() == generatorName) {
			this->setCurrentGenerator(*itg);
		}
	}
}

void ScenarioGeneratorApplication::generatorStore() {
	QString fileName
			= QFileDialog::getSaveFileName(this, tr("Save File"), _lastLoadSaveConfigPath);
	if (fileName.toStdString() != "") {
		getTextMessageStream() << "storeParameters to file: " << fileName.toStdString() << endl;
		currentGenerator->save(fileName.toStdString());
		_lastLoadSaveConfigPath = fileName;
	}
}

void ScenarioGeneratorApplication::writeOutput() {
	if (!currentGenerator->validateParameters()) {
		getTextMessageStream() << endl;
		getTextMessageStream() << "ERROR validating input! No output generated..." << endl;
	} else {
		QString fileName
		= QFileDialog::getExistingDirectory(this, tr("Save File"), _lastWriteOutputPath);
		if (fileName.toStdString() != "") {
			getTextMessageStream() << "generate output to directory: " << fileName.toStdString() << endl;
			currentGenerator->generateOutput(fileName.toStdString());
			_lastWriteOutputPath = fileName;
		}
	}
}

void ScenarioGeneratorApplication::generatorLoad() {
	QString fileName
			= QFileDialog::getOpenFileName(this, tr("Load File"), _lastLoadSaveConfigPath);
	if (fileName.toStdString() != "") {
		currentGenerator->load(fileName.toStdString());
		_lastLoadSaveConfigPath = fileName;
		_mainWindow->updateAllPanels();
	}
}


const std::list<Object*>& ScenarioGeneratorApplication::getObjects() {
	if (!currentGenerator->validateParameters()) {
		getTextMessageStream() << endl;
		getTextMessageStream() << "ERROR validating input! No preview generated..." << endl;
	} else {
		if (objects.size() == 0) {
			getTextMessageStream() << "[ScenarioGenerator] << Generate Data..." << std::endl;
			currentGenerator->generatePreview();
			getTextMessageStream() << "[ScenarioGenerator] << ... DONE!" << std::endl;
		}
	}
	return objects;
}

