/*
 * QPanel.h
 *
 *  Created on: Jun 2, 2011
 *      Author: kovacevt
 */


#ifndef QPANEL_H_
#define QPANEL_H_

#include <QWidget>
#include <list>
#include <qmenubar.h>
#include <QLabel>
#include <qgridlayout.h>
#include <QVBoxLayout>
#include "Parameters/Parameter.h"
#include "Parameters/ParameterCollection.h"
#include <QScrollArea>
#include <QSlider>

using namespace std;

class ScenarioGeneratorApplication;
class WidgetFactory;
class QPanel: public QScrollArea {
	Q_OBJECT

	ParameterCollection*  collection;
	QWidget* wrapper;
	QGridLayout* layout;
	list<QWidget*> widgets;
	list<QLabel*> labels;
	QMenuBar* menuBar;

public:
	QPanel(ParameterCollection* const col);
	virtual ~QPanel();

	void setParameterCollection(ParameterCollection* coll){collection = coll; }

	void rebuild();

	void draw();

	string getName(){return collection->getNameId();}

	void closeEvent(QCloseEvent *event);

//	void showEvent(QShowEvent*);
//
//	void hideEvent ( QHideEvent * event );

private:
	void addToLayout();

	void createMenu();

private slots:
	void loadParameters();

	void storeParameters();
};

#endif /* QPANEL_H_ */
