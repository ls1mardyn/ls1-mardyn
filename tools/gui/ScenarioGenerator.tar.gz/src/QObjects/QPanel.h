/*
 * QPanel.h
 *
 *  Created on: Jun 2, 2011
 *      Author: kovacevt
 */


#ifndef QPANEL_H_
#define QPANEL_H_

#include <QWidget>
#include <list>
#include <qmenubar.h>
#include <qlabel.h>
#include <qgridlayout.h>
#include "Parameters/Parameter.h"
#include "Parameters/ParameterCollection.h"

using namespace std;

class ScenarioGeneratorApplication;
class WidgetFactory;

class QPanel: public QWidget {
	Q_OBJECT

	//list<Parameter*> parameters;
	ParameterCollection*  collection;
	QGridLayout* layout;
	list<QWidget*> widgets;
	list<QLabel*> labels;

	QMenuBar* menuBar;

public:
	QPanel(ParameterCollection* const col);
	virtual ~QPanel();

	void setParameterCollection(ParameterCollection* coll){collection = coll; }

	void rebuild();

	void draw();

	string getName(){return collection->getNameId();}

	void closeEvent(QCloseEvent *event);

//	void showEvent(QShowEvent*);
//
//	void hideEvent ( QHideEvent * event );

private:
	void addToLayout();

	void createMenu();

private slots:
	void loadParameters();

	void storeParameters();
};

#endif /* QPANEL_H_ */
