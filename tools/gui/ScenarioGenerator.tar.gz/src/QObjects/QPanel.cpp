/*
 * QPanel.cpp
 *
 *  Created on: Jun 2, 2011
 *      Author: kovacevt
 */

#include "QPanel.h"
#include "QObjects/ScenarioGenerator.h"
#include "Parameters/ParameterCollection.h"
#include "Parameters/ParameterWithIntValue.h"
#include "WidgetFactory.h"
#include <qfiledialog.h>

QPanel::QPanel(ParameterCollection* const col) :  collection(col) {
	menuBar = new QMenuBar(this);
	draw();
	ScenarioGeneratorApplication::getInstance()->getMainWindow()->addOpenPanels(this);
}

QPanel::~QPanel() {
	list<QLabel*>::iterator itl;
	list<QWidget*>::iterator itw;
	for (itl = labels.begin(); itl != labels.end(); itl++) {
		delete(*itl);
	}
	for (itw = widgets.begin(); itw != widgets.end(); itw++) {
		delete (*itw);
	}
	ScenarioGeneratorApplication::getInstance()->getMainWindow()->removeOpenPanels(this);
}

void QPanel::draw() {
	this->resize(300, 300);
	this->setVisible(true);
	layout = new QGridLayout;
	addToLayout();
	this->setLayout(layout);
}

void QPanel::addToLayout() {
	createMenu();
	layout->setMenuBar(menuBar);

	list<Parameter*> parameters = collection->getParameters();
	list<Parameter*>::iterator it;
	int i;
	for (it = parameters.begin(), i = 0; it != parameters.end(); it++, i++) {
		QLabel* label = new QLabel((*it)->getName().c_str());
		layout->addWidget(label, i, 0);
		labels.push_back(label);
		QWidget* widget = WidgetFactory::createWidget((*it));
		widgets.push_back(widget);
		layout->addWidget(widget, i, 1);
		widget->setVisible(true);
		widget->setEnabled(true);
	}
}

void QPanel::closeEvent(QCloseEvent* event) {
	ScenarioGeneratorApplication::getInstance()->getMainWindow()->removeOpenPanels(this);
	event->accept();
}


void QPanel::rebuild() {
	list<QLabel*>::iterator itl;
	list<QWidget*>::iterator itw;
	for (itl = labels.begin(); itl != labels.end(); itl++) {
		(*itl)->setVisible(false);
	}
	for (itw = widgets.begin(); itw != widgets.end(); itw++){
		(*itw)->setVisible(false);
	}

	menuBar->clear();
	addToLayout();
}


void QPanel::createMenu() {
	if (collection->hasLoadOption()) {
		QAction* loadAction = menuBar->addAction("&Load");
		loadAction->setToolTip(tr("Load parameter settings from file"));
		connect(loadAction, SIGNAL(triggered()), this, SLOT(loadParameters()));
	}

	if (collection->hasStoreOption()) {
		QAction* storeAction = menuBar->addAction("&Save");
		storeAction->setToolTip(tr("Save parameter settings to file"));
		connect(storeAction, SIGNAL(triggered()), this, SLOT(storeParameters()));
	}
}


void QPanel::loadParameters() {
	string fileName;
	QString directory = QDir::currentPath();
	fileName = QFileDialog::getOpenFileName(this, tr("Load File"), directory).toStdString();
	if (fileName != "") {
		ScenarioGeneratorApplication::getInstance()->getTextMessageStream() << "[QPanel] loadParameters from file: " << fileName << endl;
		collection->load(fileName, ScenarioGeneratorApplication::getInstance()->getCurrentGenerator());
		ScenarioGeneratorApplication::getInstance()->getMainWindow()->updateAllPanels();
	}
}

void QPanel::storeParameters() {
	string fileName;
	QString directory = QDir::currentPath();
	fileName = QFileDialog::getSaveFileName(this, tr("Save File"), directory).toStdString();
	if (fileName != "") {
		ScenarioGeneratorApplication::getInstance()->getTextMessageStream() << "[QPanel] storeParameters to file: " << fileName << endl;
		collection->save(fileName);
	}
}
