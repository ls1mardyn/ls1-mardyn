/*
 * QParLineEdit.cpp
 *
 *  Created on: May 11, 2011
 *      Author: kovacevt
 */

#include "QObjects/QParLineEdit.h"
#include "Parameters/ParameterWithValue.h"
#include "QObjects/ScenarioGenerator.h"
#include "Generators/Generator.h"
#include "QPanel.h"

QParLineEdit::QParLineEdit(ParameterWithValue* const par) : parameter(par) {
	this->setText(par->getStringValue().c_str());
	this->setToolTip(QString::fromStdString(parameter->getDescription()));
	connect(this, SIGNAL(editingFinished()), this, SLOT(setNewValue()));
}

QParLineEdit::~QParLineEdit() {
}

void QParLineEdit::setNewValue() {
	parameter->setStringValue(this->text().toStdString());
	ScenarioGeneratorApplication::getInstance()->getCurrentGenerator()->setParameter(
			parameter);
	if (parameter->requiresGUIRebuild()) {
		ScenarioGeneratorApplication::getInstance()->getMainWindow()->updateAllPanels();
	}
}
