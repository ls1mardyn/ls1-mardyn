/*
 * MainWindow.cpp
 *
 * @Date: 02.08.2011
 * @Author: eckhardw
 */

#include "MainWindow.h"
#include "QObjects/QPanel.h"
#include "QObjects/QTextMessageField.h"
#include "Generators/Generator.h"
#include "QObjects/ScenarioGenerator.h"

#include <vtkOrientationMarkerWidget.h>
#include <vtkAxesActor.h>
#include <vtkCaptionActor2D.h>
#include <vtkTextProperty.h>

MainWindow::MainWindow(ScenarioGeneratorApplication* application)
: _application(application), _splitter(NULL), _tabWidget(NULL), _drawableValueBox(NULL) {

	// MenuBar
	QMenu* generatorMenu = menuBar()->addMenu("Generator...");
	generatorMenu->addAction("Load", _application, SLOT(generatorLoad()));
	generatorMenu->addAction("Save", _application, SLOT(generatorStore()));

	// Toolbar
	QToolBar* toolBar = addToolBar("ToolBar!");
	_generatorBox = new QComboBox(toolBar);
	_generatorBox->setSizeAdjustPolicy(QComboBox::AdjustToContents);

	// Choice of generators
	_generatorBox->setObjectName(tr("Choose generator: "));
	toolBar->addWidget(_generatorBox);
	connect(_generatorBox, SIGNAL(currentIndexChanged(const QString&)), this,
			SLOT(setCurrentGenerator(const QString&)));

	// drawableValues
	_drawableValueBox = new QComboBox(this);
	_drawableValueBox->setSizeAdjustPolicy(QComboBox::AdjustToContents);
	connect(_drawableValueBox, SIGNAL(currentIndexChanged(int)), this,
			SLOT(drawSelectedValue()));
	toolBar->addWidget(_drawableValueBox);

	QPushButton* viewButton = new QPushButton(tr("&Generate preview"));
	QPushButton* writeOutputButton = new QPushButton(tr("&Write output"));
	toolBar->addWidget(writeOutputButton);
	toolBar->addWidget(viewButton);
	connect(viewButton, SIGNAL(clicked()), _application, SLOT(rebuildPreview()));
	connect(writeOutputButton, SIGNAL(clicked()), _application, SLOT(writeOutput()));

	QSplitter* splitter = new QSplitter();
	setCentralWidget(splitter);

	// VTK stuff
	QVTKWidget* vtkwindow = new QVTKWidget();
	vtkwindow->resize(350, 256);
	_renderWindow = vtkSmartPointer<vtkRenderWindow>::New();
	_renderer = vtkSmartPointer<vtkRenderer>::New();
	_renderWindow->AddRenderer(_renderer);
	vtkwindow->SetRenderWindow(_renderWindow);
	splitter->addWidget(vtkwindow);

	// textfield and tabs
	_tabWidget = new QTabWidget();

	_textEdit = new QTextMessageField();
	QVBoxLayout* layout = new QVBoxLayout();
	layout->addWidget(_tabWidget);
	layout->addWidget(_textEdit);
	_textEdit->setMaximumHeight(100);
	QWidget* rightWidget = new QWidget();
	rightWidget->setLayout(layout);
	splitter->addWidget(rightWidget);

	resize(800, 500);

	_textEdit->getTextMessageStream() << "MainWindow successfully constructed!" << endl;
}

MainWindow::~MainWindow() {
}

void MainWindow::rebuildTabPanels() {
	_drawableValueBox->setEnabled(false);
	_drawableValueBox->clear();

	_application->getCurrentGenerator()->createSampleObject();
	const Object* sampleObject = _application->getObjects().front();
	const vector<string> drawables = sampleObject->getDrawableValues();
	vector<string>::const_iterator itdv;
	for (itdv = drawables.begin(); itdv != drawables.end(); itdv++) {
		_drawableValueBox->addItem((*itdv).c_str());
	}

	_generatorBox->setEnabled(false);
	_generatorBox->clear();
	const list<Generator*>& generators = _application->getGenerators();
	list<Generator*>::const_iterator itGenerators;
	int index = 0;
	for (itGenerators = generators.begin(); itGenerators != generators.end(); itGenerators++) {
		_generatorBox->addItem((*itGenerators)->getName().c_str());
		if (*itGenerators == _application->getCurrentGenerator()) {
			//std::cout << "BuildPanels: adding generator " << (*itGenerators)->getName() << endl;
			_generatorBox->setCurrentIndex(index);
		}
		index++;
	}
	_generatorBox->setEnabled(true);

	while (_tabWidget->count() > 0) {
		delete _tabWidget->currentWidget();
	}

	std::vector<ParameterCollection*> oldGeneratorParameters = _currentGeneratorParameters;
	_currentGeneratorParameters = _application->getCurrentGenerator()->getParameters();
	for (size_t i = 0; i < _currentGeneratorParameters.size(); i++ ) {
		QPanel* parameterPanel = new QPanel(_currentGeneratorParameters[i]);
		QString tabName(_currentGeneratorParameters[i]->getName().c_str());
		_tabWidget->addTab(parameterPanel, tabName);
	}

	for (size_t i = 0; i < oldGeneratorParameters.size(); i++ ) {
		ParameterCollection::deleteParameter(oldGeneratorParameters[i]);
	}

	_drawableValueBox->setEnabled(true);
	_textEdit->clear();
}



void MainWindow::updateAllPanels() {
	std::vector<ParameterCollection*> oldGeneratorParameters = _currentGeneratorParameters;
	_currentGeneratorParameters = _application->getCurrentGenerator()->getParameters();
	for (size_t i = 0; i < _currentGeneratorParameters.size(); i++ ) {
		updatePanelAndChildren(_currentGeneratorParameters[i]);
	}

	for (size_t i = 0; i < oldGeneratorParameters.size(); i++ ) {
		ParameterCollection::deleteParameter(oldGeneratorParameters[i]);
	}
}

void MainWindow::updatePanelAndChildren(ParameterCollection* collection) {
	list<QPanel*>::iterator it;

	// update the panel for the parameter collection
	for (it = openPanels.begin(); it != openPanels.end(); it++) {
		//std::cout << "compare panel: " << (*it)->getName() << endl;
		//std::cout << "with collection: " << collection->getNameId() << std::endl;
		if ((*it)->getName() == collection->getNameId()) {
			(*it)->setParameterCollection(collection);
			(*it)->rebuild();
		}
	}

	// update the panels for the children of the parameter collection
	list<Parameter*> parameters = collection->getParameters();

	list<Parameter*>::iterator it2;
 	for (it2 = parameters.begin(); it2 != parameters.end(); it2++) {
		if ((*it2)->getType() == Parameter::COMPOSITE) {
			updatePanelAndChildren(
					dynamic_cast<ParameterCollection*> (*it2));
		}
	}
}


void MainWindow::drawSelectedValue() {

	if (!_drawableValueBox->isEnabled()) {
		return;
	}

	string value = _drawableValueBox->currentText().toStdString();
	_renderer->RemoveAllViewProps();

	list<Object*>::const_iterator itObjects;
	const std::list<Object*>& objects = _application->getObjects();

	Object::setNumObjects(objects.size());
	std::vector<vtkSmartPointer<vtkActor> > actors;
	for (itObjects = objects.begin(); itObjects != objects.end(); itObjects++) {
		vtkSmartPointer<vtkActor> actor = (*itObjects)->draw(value);
		actors.push_back(actor);
	}

	// Add the actors to the scene
	unsigned int j;
	for (j = 0; j < actors.size(); j++) {
		_renderer->AddActor(actors[j]);
	}

	if (j > 0) {
		vtkSmartPointer<vtkAxesActor> axes =
				vtkSmartPointer<vtkAxesActor>::New();
		vtkSmartPointer<vtkTextProperty> axesLabel = vtkSmartPointer<
				vtkTextProperty>::New();
		axesLabel->SetColor(0, 0, 0);
		axes->GetXAxisCaptionActor2D()->SetCaptionTextProperty(axesLabel);
		axes->GetYAxisCaptionActor2D()->SetCaptionTextProperty(axesLabel);
		axes->GetZAxisCaptionActor2D()->SetCaptionTextProperty(axesLabel);
		_renderer->AddActor(axes);
	}
	_renderer->SetBackground(2, 1, 1); // Background color white
	_renderer->ResetCamera();
	_textEdit->getTextMessageStream() << " ... rendering ...";
	_renderWindow->Render();
	_textEdit->getTextMessageStream() << " ... DONE!" << endl;
}



std::ostream& MainWindow::getTextMessageStream() const {
	return _textEdit->getTextMessageStream();
}

void MainWindow::setCurrentGenerator(const QString& generator) {
	if (_generatorBox->isEnabled()) {
		_application->setCurrentGenerator(generator.toStdString());
	}
}
