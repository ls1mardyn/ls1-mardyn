/*
 * OKCancelButton.h
 *
 *  Created on: Nov 18, 2011
 *      Author: tanlin
 */

#ifndef OKCANCELBUTTON_H_
#define OKCANCELBUTTON_H_

#include <qpushbutton.h>
#include "QPanel.h"

class OKCancelButton : public QPushButton {
          Q_OBJECT

  private:
          ParameterCollection* collectionParameter; // parameter who contains an instance of this class
          bool _isCancelButton;
  public:
          /**
           * Constructor
           * @param parameter ParameterCollection that reacts on this button
           * @param if
           */
          OKCancelButton(ParameterCollection* const parameter, bool isCancelButton);

          virtual ~OKCancelButton();

  public slots:

         void notifyGenerator();

};

#endif /* OKCANCELBUTTON_H_ */
