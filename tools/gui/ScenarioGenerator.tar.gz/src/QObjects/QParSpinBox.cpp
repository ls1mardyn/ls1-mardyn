/*
 * QParSpinBox.cpp
 *
 *  Created on: Jun 25, 2011
 *      Author: kovacevt
 */

#include "QParSpinBox.h"
#include "ScenarioGenerator.h"
#include "Generators/Generator.h"

QParSpinBox::QParSpinBox(ParameterWithIntValue* par):parameter(par) {
	 setValue(parameter->getValue());
	 val = parameter->getValue();
	 this->setToolTip(QString::fromStdString(parameter->getDescription()));
	 connect(this, SIGNAL(valueChanged(int)), this, SLOT(setNewValue()));
}

QParSpinBox::~QParSpinBox() {
}

void QParSpinBox::setNewValue() {
	val = this->value();
	std::cout << "QParSpinBox value is " << val << endl;
	parameter->setValue(val);
	ScenarioGeneratorApplication::getInstance()->getCurrentGenerator()->setParameter(
					parameter);
	if (parameter->requiresGUIRebuild()){
		ScenarioGeneratorApplication::getInstance()->getMainWindow()->updateAllPanels();
	}
}
