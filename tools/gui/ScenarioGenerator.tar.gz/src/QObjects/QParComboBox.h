/*
 * QParComboBox.h
 *
 * @Date: 12.09.2011
 * @Author: eckhardw
 */

#ifndef QPARCOMBOBOX_H_
#define QPARCOMBOBOX_H_

#include "qcombobox.h"

class ParameterWithChoice;

class QParComboBox : public QComboBox {
	Q_OBJECT

private:
	ParameterWithChoice* _parameter;

public:

	QParComboBox(ParameterWithChoice* const par);

	virtual ~QParComboBox();

public slots:
	void setNewChoice();
};

#endif /* QPARCOMBOBOX_H_ */
