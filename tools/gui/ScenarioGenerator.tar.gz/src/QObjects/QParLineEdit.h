/*
 * QParLineEdit.h
 *
 *  Created on: May 11, 2011
 *      Author: kovacevt
 */

#include <qlineedit.h>
#include <string>

using namespace std;

class ParameterWithValue;

#ifndef QPARLINEEDIT_H_
#define QPARLINEEDIT_H_

class QParLineEdit: public QLineEdit {
	Q_OBJECT
private:
	ParameterWithValue* parameter;

public:
	QParLineEdit(ParameterWithValue* const par);
	virtual ~QParLineEdit();

public slots:
	void setNewValue();

};

#endif /* QPARLINEEDIT_H_ */
