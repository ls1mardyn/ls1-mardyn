/*
 * WidgetFactory.h, FACTORY DP
 *
 *  Created on: Jun 9, 2011
 *      Author: kovacevt
 */



#ifndef WIDGETFACTORY_H_
#define WIDGETFACTORY_H_

class QWidget;
class Parameter;


class WidgetFactory {
public:
	WidgetFactory();
	virtual ~WidgetFactory();

	/**
	 * Creates the widget according to the Widget type that the parameter has
	 */
	static QWidget* createWidget(Parameter* p);
};

#endif /* WIDGETFACTORY_H_ */
