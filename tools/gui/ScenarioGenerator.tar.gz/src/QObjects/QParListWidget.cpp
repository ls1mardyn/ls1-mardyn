/*
 * QParListWidget.cpp
 *
 *  Created on: May 14, 2011
 *      Author: kovacevt
 */

#include "QObjects/QParListWidget.h"
#include "Parameters/ParameterWithChoice.h"
#include "QObjects/ScenarioGenerator.h"
#include "Generators/Generator.h"

QParListWidget::QParListWidget(ParameterWithChoice* const par): _parameter(par) {
	vector <string> choices = static_cast<ParameterWithChoice*> (_parameter)->getChoices();
	for (size_t i = 0; i < choices.size(); i++) {
		QListWidgetItem* item = new QListWidgetItem(choices[i].c_str());
		addItem(item);
	}

	connect(this,SIGNAL(itemClicked (QListWidgetItem*)),SLOT(setNewChoice()));
}

QParListWidget::~QParListWidget() {
	// TODO Auto-generated destructor stub
}

void QParListWidget::setNewChoice(){
	QList<QListWidgetItem *> selected = this->selectedItems();
	string name = (*selected.begin())->text().toStdString();
	_parameter->setStringValue(name);
	ScenarioGeneratorApplication::getInstance()->getCurrentGenerator()->setParameter(
					_parameter);
	if (_parameter->requiresGUIRebuild()){
		ScenarioGeneratorApplication::getInstance()->getMainWindow()->updateAllPanels();
	}
}
