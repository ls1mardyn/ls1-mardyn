#include <stdlib.h>

#define STB_INCLUDE_IMPLEMENTATION
#define STB_INCLUDE_LINE_NONE
#include <string>
#include <fstream>

int main(int argc, char **argv)
{
	if(argc<3)
	{
		printf("Usage: %s MAIN_FILE INCLUDE_PATH\n", argv[0]);
		return EXIT_FAILURE;
	}
	char Error[256];

	std::ifstream inFile(argv[1]);
	std::string contents((std::istreambuf_iterator<char>(inFile)), std::istreambuf_iterator<char>());

	const char *Amalgamated = contents.c_str();
	if(!Amalgamated)
	{
		printf("%s", Error);
		return EXIT_FAILURE;
	}
	printf("%s",Amalgamated);
	return EXIT_SUCCESS;
}
