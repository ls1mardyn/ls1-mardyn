/**
 * \file
 * \brief VectorizedCellProcessor.h
 * \author Johannes Heckl, Wolfgang Eckhardt, Uwe Ehmann, Steffen Seckler
 */

#ifndef VECTORIZEDCELLPROCESSOR_H_
#define VECTORIZEDCELLPROCESSOR_H_

#include "CellProcessor.h"
#include "utils/AlignedArray.h"
#include <iostream>
#include <vector>
#include <cmath>
#include "vectorization/SIMD_TYPES.h"
#include "vectorization/SIMD_VectorizedCellProcessorHelpers.h"
#include "WrapOpenMP.h"

#include "molecules/MoleculeForwardDeclaration.h"
class Component;
class Domain;
class Comp2Param;
class CellDataSoA;

/**
 * \brief Vectorized calculation of the force.
 * \author Johannes Heckl
 */
class VectorizedCellProcessor : public CellProcessor {
	friend class VCP1CLJWRTest;
public:
	typedef std::vector<Component> ComponentList;

	VectorizedCellProcessor& operator=(const VectorizedCellProcessor&) = delete;

	/**
	 * \brief Construct and set up the internal parameter table.
	 * \details Components and parameters should be finalized before this call.
	 */
	VectorizedCellProcessor(Domain & domain, double cutoffRadius, double LJcutoffRadius);

	~VectorizedCellProcessor();

	/**
	 * \brief Reset macroscopic values to 0.0.
	 */
	void initTraversal();
	/**
	 * \brief Load the CellDataSoA for cell.
	 */
	void preprocessCell(ParticleCell& /*cell*/) {}
	/**
	 * \brief Calculate forces between pairs of Molecules in cell1 and cell2.
	 */
	void processCellPair(ParticleCell& cell1, ParticleCell& cell2);

	double processSingleMolecule(Molecule* /*m1*/, ParticleCell& /*cell2*/) {
		return 0.0;
	}

	/**
	 * \brief Calculate forces between pairs of Molecules in cell.
	 */
	void processCell(ParticleCell& cell);
	/**
	 * \brief Free the LennardJonesSoA for cell.
	 */
	void postprocessCell(ParticleCell& /*cell*/) {}
	/**
	 * \brief Store macroscopic values in the Domain.
	 */
	void endTraversal();
private:
	/**
	 * \brief a vector of Molecule pointers.
	 */
	typedef std::vector<Molecule *> MoleculeList;
	/**
	 * \brief The Domain where macroscopic values will be stored.
	 */
	Domain & _domain;

	/**
	 * \brief The squared cutoff radius.
	 */
	//const double _cutoffRadiusSquare;

	/**
	 * \brief The squared LJ cutoff radius.
	 */
	//const double _LJcutoffRadiusSquare;

	/**
	 * \brief Parameter for the reaction field method (see description in Domain.h and Comp2Param.cpp).
	 */
	const double _epsRFInvrc3;

	/**
	 * \brief One LJ center enumeration start index for each component.
	 * \details All the LJ centers of all components are enumerated.<br>
	 * Comp1 gets indices 0 through n1 - 1, Comp2 n1 through n2 - 1 and so on.<br>
	 * This is necessary for finding the respective parameters for each interaction<br>
	 * between two centers.
	 */

	/**
	 * \brief Epsilon and sigma for pairs of LJcenters.
	 * \details Each DoubleArray contains parameters for one center combined with all centers.<br>
	 * Each set of parameters is a pair (epsilon*24.0, sigma^2).
	 */
	std::vector<AlignedArray<vcp_real_calc> > _eps_sig;
	/**
	 * \brief Shift for pairs of LJcenters.
	 * \details Each DoubleArray contains the LJ shift*6.0 for one center combined<br>
	 * with all centers.
	 */
	std::vector<AlignedArray<vcp_real_calc> > _shift6;
	/**
	 * \brief Sum of all LJ potentials.
	 * \details Multiplied by 6.0 for performance reasons.
	 */
	double _upot6lj;

	/**
	 * \brief Sum of all Xpole potentials.
	 */
	double _upotXpoles;

	/**
	 * \brief The virial.
	 */
	double _virial;

	/**
	 * \brief MyRF contribution of all pairs
	 */
	double _myRF;

	struct VLJCPThreadData {
	public:
		VLJCPThreadData(): _ljc_dist_lookup(nullptr), _charges_dist_lookup(nullptr), _dipoles_dist_lookup(nullptr), _quadrupoles_dist_lookup(nullptr){
			_upot6ljV.resize(_numVectorElements);
			_upotXpolesV.resize(_numVectorElements);
			_virialV.resize(_numVectorElements);
			_myRFV.resize(_numVectorElements);

			for (size_t j = 0; j < _numVectorElements; ++j) {
				_upot6ljV[j] = 0.0;
				_upotXpolesV[j] = 0.0;
				_virialV[j] = 0.0;
				_myRFV[j] = 0.0;
			}
		}

		/**
		 * \brief array, that stores the dist_lookup.
		 * For all vectorization methods, that utilize masking, this stores masks.
		 * To utilize the gather operations of the KNC architecture, the dist_lookup is able to store the indices of the required particles.
		 */
		AlignedArray<vcp_lookupOrMask_single> _centers_dist_lookup;

		/**
		 * \brief pointer to the starting point of the dist_lookup of the lennard jones particles.
		 */
		vcp_lookupOrMask_single* _ljc_dist_lookup;

		/**
		 * \brief pointer to the starting point of the dist_lookup of the charge particles.
		 */
		vcp_lookupOrMask_single* _charges_dist_lookup;

		/**
		 * \brief pointer to the starting point of the dist_lookup of the dipole particles.
		 */
		vcp_lookupOrMask_single* _dipoles_dist_lookup;

		/**
		 * \brief pointer to the starting point of the dist_lookup of the quadrupole particles.
		 */
		vcp_lookupOrMask_single* _quadrupoles_dist_lookup;

		AlignedArray<vcp_real_calc> _upot6ljV, _upotXpolesV, _virialV, _myRFV;
	};

	std::vector<VLJCPThreadData *> _threadData;

	static const size_t _numVectorElements = VCP_VEC_SIZE;
	size_t _numThreads;

	template<bool calculateMacroscopic>
	inline void _loopBodyLJ(
			const RealCalcVec& m1_r_x, const RealCalcVec& m1_r_y, const RealCalcVec& m1_r_z,
			const RealCalcVec& r1_x, const RealCalcVec& r1_y, const RealCalcVec& r1_z,
			const RealCalcVec& m2_r_x, const RealCalcVec& m2_r_y, const RealCalcVec& m2_r_z,
			const RealCalcVec& r2_x, const RealCalcVec& r2_y, const RealCalcVec& r2_z,
			RealCalcVec& f_x, RealCalcVec& f_y, RealCalcVec& f_z,
			RealCalcVec& V_x, RealCalcVec& V_y, RealCalcVec& V_z,
			RealCalcVec& sum_upot6lj, RealCalcVec& sum_virial,
			const MaskVec& forceMask,
			const RealCalcVec& eps_24, const RealCalcVec& sig2,
			const RealCalcVec& shift6);

	template<bool calculateMacroscopic>
	inline void _loopBodyCharge(
		const RealCalcVec& m1_r_x, const RealCalcVec& m1_r_y, const RealCalcVec& m1_r_z,
		const RealCalcVec& r1_x, const RealCalcVec& r1_y, const RealCalcVec& r1_z,
		const RealCalcVec& qii,
		const RealCalcVec& m2_r_x, const RealCalcVec& m2_r_y, const RealCalcVec& m2_r_z,
		const RealCalcVec& r2_x, const RealCalcVec& r2_y, const RealCalcVec& r2_z,
		const RealCalcVec& qjj,
		RealCalcVec& f_x, RealCalcVec& f_y, RealCalcVec& f_z,
		RealCalcVec& V_x, RealCalcVec& V_y, RealCalcVec& V_z,
		RealCalcVec& sum_upotXpoles, RealCalcVec& sum_virial,
		const MaskVec& forceMask);

	template<bool calculateMacroscopic>
	inline void _loopBodyChargeDipole(
		const RealCalcVec& m1_r_x, const RealCalcVec& m1_r_y, const RealCalcVec& m1_r_z,
		const RealCalcVec& r1_x, const RealCalcVec& r1_y, const RealCalcVec& r1_z,
		const RealCalcVec& q,
		const RealCalcVec& m2_r_x, const RealCalcVec& m2_r_y, const RealCalcVec& m2_r_z,
		const RealCalcVec& r2_x, const RealCalcVec& r2_y, const RealCalcVec& r2_z,
		const RealCalcVec& e_x, const RealCalcVec& e_y, const RealCalcVec& e_z,
		const RealCalcVec& p,
		RealCalcVec& f_x, RealCalcVec& f_y, RealCalcVec& f_z,
		RealCalcVec& V_x, RealCalcVec& V_y, RealCalcVec& V_z,
		RealCalcVec& M_x, RealCalcVec& M_y, RealCalcVec& M_z,
		RealCalcVec& sum_upotXpoles, RealCalcVec& sum_virial,
		const MaskVec& forceMask);

	template<bool calculateMacroscopic>
	inline void _loopBodyDipole(
		const RealCalcVec& m1_r_x, const RealCalcVec& m1_r_y, const RealCalcVec& m1_r_z,
		const RealCalcVec& r1_x, const RealCalcVec& r1_y, const RealCalcVec& r1_z,
		const RealCalcVec& eii_x, const RealCalcVec& eii_y, const RealCalcVec& eii_z,
		const RealCalcVec& pii,
		const RealCalcVec& m2_r_x, const RealCalcVec& m2_r_y, const RealCalcVec& m2_r_z,
		const RealCalcVec& r2_x, const RealCalcVec& r2_y, const RealCalcVec& r2_z,
		const RealCalcVec& ejj_x, const RealCalcVec& ejj_y, const RealCalcVec& ejj_z,
		const RealCalcVec& pjj,
		RealCalcVec& f_x, RealCalcVec& f_y, RealCalcVec& f_z,
		RealCalcVec& V_x, RealCalcVec& V_y, RealCalcVec& V_z,
		RealCalcVec& M1_x, RealCalcVec& M1_y, RealCalcVec& M1_z,
		RealCalcVec& M2_x, RealCalcVec& M2_y, RealCalcVec& M2_z,
		RealCalcVec& sum_upotXpoles, RealCalcVec& sum_virial, RealCalcVec& sum_myRF,
		const MaskVec& forceMask,
		const RealCalcVec& epsRFInvrc3);

	template<bool calculateMacroscopic>
	inline void _loopBodyChargeQuadrupole(
		const RealCalcVec& m1_r_x, const RealCalcVec& m1_r_y, const RealCalcVec& m1_r_z,
		const RealCalcVec& r1_x, const RealCalcVec& r1_y, const RealCalcVec& r1_z,
		const RealCalcVec& q,
		const RealCalcVec& m2_r_x, const RealCalcVec& m2_r_y, const RealCalcVec& m2_r_z,
		const RealCalcVec& r2_x, const RealCalcVec& r2_y, const RealCalcVec& r2_z,
		const RealCalcVec& ejj_x, const RealCalcVec& ejj_y, const RealCalcVec& ejj_z,
		const RealCalcVec& m,
		RealCalcVec& f_x, RealCalcVec& f_y, RealCalcVec& f_z,
		RealCalcVec& V_x, RealCalcVec& V_y, RealCalcVec& V_z,
		RealCalcVec& M_x, RealCalcVec& M_y, RealCalcVec& M_z,
		RealCalcVec& sum_upotXpoles, RealCalcVec& sum_virial,
		const MaskVec& forceMask);

	template<bool calculateMacroscopic>
	inline void _loopBodyDipoleQuadrupole(
		const RealCalcVec& m1_r_x, const RealCalcVec& m1_r_y, const RealCalcVec& m1_r_z,
		const RealCalcVec& r1_x, const RealCalcVec& r1_y, const RealCalcVec& r1_z,
		const RealCalcVec& eii_x, const RealCalcVec& eii_y, const RealCalcVec& eii_z,
		const RealCalcVec& p,
		const RealCalcVec& m2_r_x, const RealCalcVec& m2_r_y, const RealCalcVec& m2_r_z,
		const RealCalcVec& r2_x, const RealCalcVec& r2_y, const RealCalcVec& r2_z,
		const RealCalcVec& ejj_x, const RealCalcVec& ejj_y, const RealCalcVec& ejj_z,
		const RealCalcVec& m,
		RealCalcVec& f_x, RealCalcVec& f_y, RealCalcVec& f_z,
		RealCalcVec& V_x, RealCalcVec& V_y, RealCalcVec& V_z,
		RealCalcVec& M1_x, RealCalcVec& M1_y, RealCalcVec& M1_z,
		RealCalcVec& M2_x, RealCalcVec& M2_y, RealCalcVec& M2_z,
		RealCalcVec& sum_upotXpoles, RealCalcVec& sum_virial,
		const MaskVec& forceMask);

	template<bool calculateMacroscopic>
	inline void _loopBodyQuadrupole(
		const RealCalcVec& m1_r_x, const RealCalcVec& m1_r_y, const RealCalcVec& m1_r_z,
		const RealCalcVec& r1_x, const RealCalcVec& r1_y, const RealCalcVec& r1_z,
		const RealCalcVec& eii_x, const RealCalcVec& eii_y, const RealCalcVec& eii_z,
		const RealCalcVec& mii,
		const RealCalcVec& m2_r_x, const RealCalcVec& m2_r_y, const RealCalcVec& m2_r_z,
		const RealCalcVec& r2_x, const RealCalcVec& r2_y, const RealCalcVec& r2_z,
		const RealCalcVec& ejj_x, const RealCalcVec& ejj_y, const RealCalcVec& ejj_z,
		const RealCalcVec& mjj,
		RealCalcVec& f_x, RealCalcVec& f_y, RealCalcVec& f_z,
		RealCalcVec& V_x, RealCalcVec& V_y, RealCalcVec& V_z,
		RealCalcVec& Mii_x, RealCalcVec& Mii_y, RealCalcVec& Mii_z,
		RealCalcVec& Mjj_x, RealCalcVec& Mjj_y, RealCalcVec& Mjj_z,
		RealCalcVec& sum_upotXpoles, RealCalcVec& sum_virial,
		const MaskVec& forceMask);

	/**
	 * \brief Force calculation with abstraction of cell pairs.
	 * \details The differences between single cell and cell pair calculation<br>
	 * have been moved into two policy class templates.<br>
	 * <br>
	 * The ForcePolicy class must provide the following methods:<br>
	 * <br>
	 * static size_t InitJ(size_t i);<br>
	 * Returns the value which j is to be initialized as in the inner loop<br>
	 * depending on the vectorization method.<br>
	 * <br>
	 * If the code is to be vectorized:<br>
	 * static DoubleVec GetForceMask(DoubleVec m_r2, DoubleVec rc2);<br>
	 * Returns the mask indicating which pairs to calculate in the vectorized code.<br>
	 * <br>
	 * The boolean CalculateMacroscopic should specify, whether macroscopic values are to be calculated or not.
	 * <br>
	 * The class MaskGatherChooser is a class, that specifies the used loading,storing and masking routines.
	 */
	template<class ForcePolicy, bool CalculateMacroscopic, class MaskGatherChooser>
	void _calculatePairs(CellDataSoA & soa1, CellDataSoA & soa2);

}; /* end of class VectorizedCellProcessor */

#endif /* VECTORIZEDCELLPROCESSOR_H_ */
