/*
 * MemoryProfilerTest.cpp
 *
 *  Created on: May 9, 2017
 *      Author: seckler
 */

#include "MemoryProfilerTest.h"

TEST_SUITE_REGISTRATION(MemoryProfilerTest);

void MemoryProfilerTest::testMemProfiler(){

}
