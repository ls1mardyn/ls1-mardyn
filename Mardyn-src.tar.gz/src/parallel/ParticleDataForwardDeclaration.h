/*
 * ParticleDataForwardDeclaration.h
 *
 *  Created on: 21 Apr 2017
 *      Author: seckler
 */

#pragma once

#ifndef MARDYN_WR
	class ParticleDataFull;
	typedef ParticleDataFull ParticleData;
#else
	class ParticleDataWR;
	typedef ParticleDataWR ParticleData;
#endif


