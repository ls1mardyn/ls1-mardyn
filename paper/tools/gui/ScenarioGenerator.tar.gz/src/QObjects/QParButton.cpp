/*
 * QParButton.cpp
 *
 *  Created on: May 8, 2011
 *      Author: kovacevt
 */

#include "QObjects/QParButton.h"

#include <QWidget>
#include "Parameters/ParameterCollection.h"
#include <string>

QParButton::QParButton(ParameterCollection* const parameter): collectionParameter(parameter){
	this->setText(collectionParameter->getName().c_str());
	this->setToolTip(QString::fromStdString(parameter->getDescription()));
	connect(this, SIGNAL(clicked()), this, SLOT(createDisplayPanel()));;
}

QParButton::~QParButton() {
}


QPanel* QParButton::createDisplayPanel(){
	QPanel* panel = new QPanel(collectionParameter);
	return panel;
}
