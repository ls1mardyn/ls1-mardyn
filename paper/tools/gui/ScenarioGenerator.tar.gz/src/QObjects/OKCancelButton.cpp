/*
 * OKCancelButton.cpp
 *
 *  Created on: Nov 18, 2011
 *      Author: tanlin
 */

#include "OKCancelButton.h"
#include "ScenarioGenerator.h"
#include "Generators/Generator.h"

OKCancelButton::OKCancelButton(ParameterCollection* const parameter, bool isCancelButton): collectionParameter(parameter), _isCancelButton(isCancelButton) {
    if (isCancelButton) {
        this->setText("Cancel");
    } else {
        this->setText("OK");
    }
    this->setToolTip(QString::fromStdString(parameter->getDescription()));
    connect(this, SIGNAL(clicked()), this, SLOT(notifyGenerator()));
}

OKCancelButton::~OKCancelButton()
{
  // TODO Auto-generated destructor stub
}

void OKCancelButton::notifyGenerator() {
    if (_isCancelButton) {
        collectionParameter->setCancelled();
    }
    else{
        collectionParameter->setOK();
    }
    ScenarioGeneratorApplication::getInstance()->getCurrentGenerator()->setParameter(collectionParameter);
}
