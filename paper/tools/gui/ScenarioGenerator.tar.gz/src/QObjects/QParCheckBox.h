/*
 * QParCheckBox.h
 *
 *  Created on: Jun 25, 2011
 *      Author: kovacevt
 */
#include <qcheckbox.h>

#ifndef QPARCHECKBOX_H_
#define QPARCHECKBOX_H_

class ParameterWithBool;

class QParCheckBox: public QCheckBox {
	Q_OBJECT

private:
	ParameterWithBool* parameter;

public:
	QParCheckBox(ParameterWithBool* par);
	virtual ~QParCheckBox();
	virtual void resizeEvent(QResizeEvent* ){resize(25,25);}

public slots:
	void setNewValue();
};

#endif /* QPARCHECKBOX_H_ */
