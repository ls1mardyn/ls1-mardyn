/*
 * Object.cpp
 *
 *  Created on: Mar 25, 2011
 *      Author: kovacevt
 */

#include "Objects/Object.h"

int Object::_numObjects = 0;

vtkSmartPointer<vtkActor> Object::drawValue(Position& position, double value,
			double minValue, double maxValue, bool color) {

	vtkSmartPointer<vtkSphereSource> sphereSource = vtkSmartPointer<
			vtkSphereSource>::New();
	//sphereSource->SetCenter(getPosition().x,
	//getPosition().y, getPosition().z);
	sphereSource->SetCenter(position.x, position.y, position.z);
	sphereSource->SetRadius(0.3);

	vtkSmartPointer<vtkPolyDataMapper> mapper = vtkSmartPointer<
			vtkPolyDataMapper>::New();

	mapper->SetInput(sphereSource->GetOutput());

	vtkSmartPointer<vtkActor> actor = vtkSmartPointer<vtkActor>::New();

	actor->SetMapper(mapper);

	// project the value from its original range to the interval [0;1]
	float* ptr;
	if (color){
		ptr = convFloatToRGB((value - minValue)*1.0 / (maxValue - minValue));
	}
	else {
		ptr = new float[3];
		ptr[0] = ptr[1] = ptr[2] = 0;
	}
	//cout<<"myid"<<id()*1.0/numMols<<"col"<<ptr[0]<<ptr[1]<<ptr[2]<<" ";
	actor->GetProperty()->SetColor(ptr[0],  ptr[1],  ptr[2]);
	return actor;
}


vtkSmartPointer<vtkActor> Object::drawVector(Position& position, Vector& v) {

	vtkSmartPointer<vtkArrowSource> arrow =
			vtkSmartPointer<vtkArrowSource>::New();
	vtkSmartPointer<vtkTransform> transform =
			vtkSmartPointer<vtkTransform>::New();

	double length = sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
	double angleY = atan2(v.y, v.x) * 180.0 / 3.14;
	double angleZ = atan2(v.z, v.x) * 180.0 / 3.14;
	//cout<<"drawing for v"<<_v[0]<<" "<<_v[1]<< " "<<_v[2];
	transform->Translate(position.x, position.y, position.z);
	transform->RotateWXYZ(angleY, 0, 0, 1);
	transform->RotateWXYZ(angleZ, 0, 1, 0);
	if (v.x < 0) {
		transform->RotateWXYZ(180, 0, 1, 0);
		cout << "in";
	}
	transform->Scale(length, 1, 1);
	vtkSmartPointer<vtkTransformPolyDataFilter> transformPD = vtkSmartPointer<
			vtkTransformPolyDataFilter>::New();
	transformPD->SetTransform(transform);
	transformPD->SetInputConnection(arrow->GetOutputPort());
	vtkSmartPointer<vtkPolyDataMapper> mapper2 = vtkSmartPointer<
			vtkPolyDataMapper>::New();
	vtkSmartPointer<vtkActor> actor2 = vtkSmartPointer<vtkActor>::New();
	mapper2->SetInputConnection(arrow->GetOutputPort());
	actor2->SetUserMatrix(transform->GetMatrix());
	actor2->SetMapper(mapper2);

	return actor2;
}


float* Object::convFloatToRGB(float ratio) {
	float* rgb = new float[3];
	//rgb.resize(3);
	if (ratio <= 0.25) {
		rgb[2] = 1;
		rgb[1] = 2 * ratio;
		rgb[0] = ratio;
	} else if (ratio <= 0.5) {
		rgb[2] = -2 * ratio + 1.5;
		rgb[1] = 2 * ratio;
		rgb[0] = ratio;
	} else if (ratio <= 0.75) {
		rgb[2] = 1 - ratio;
		rgb[1] = -2 * ratio + 2;
		rgb[0] = 2 * ratio - 0.5;
	} else if (ratio <= 1) {
		rgb[2] = 1 - ratio;
		rgb[1] = -2 * ratio + 2;
		rgb[0] = 1;
	}

	return rgb;
}
