/*
 * PeanoGenerator.cpp
 *
 *  Created on: Nov 10, 2011
 *      Author: tanlin
 */

#include "PeanoGenerator.h"
#include "PeanoObject.h"
#include "QObjects/ScenarioGenerator.h"
#include "Parameters/ParameterWithDoubleValue.h"
#include "Parameters/ParameterWithIntValue.h"
#include "Parameters/ParameterWithBool.h"
#include "Parameters/ParameterWithStringValue.h"
#include "Parameters/ParameterWithChoice.h"
#include "time.h"
#include <vector>
#include <string>
#include <iostream>
#include <cstdio>

extern "C" {

  Generator* create_generator() {
    return new PeanoGenerator();
  }

  void destruct_generator(Generator* generator) {
    delete generator;
  }
}
PeanoGenerator::PeanoGenerator()  : Generator("PeanoGenerator"){
  _distance = 0.0;
  _radius = 0.1;
  _spheresP1=false;
  _spheresP2=false;
  _vtk=false;
  _mg=false;
  _sizes=0;
  _sizelogFilters=0;
//  _plotter_name="null";
}

PeanoGenerator::~PeanoGenerator() {
  // TODO Auto-generated destructor stub
}


void PeanoGenerator::setParameter(Parameter* p) {
  std::cout << "SetParameter for param" << p->getNameId() << endl;
  std::string id = p->getNameId();
  std::string s,n;
  char t[256];


  if (id == "spheresP1") {
      std::cout << "Setting output spheresP1!" <<std::endl;
      _spheresP1 = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output spheresP1: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "spheresP2") {
      std::cout << "Setting output spheresP2!" <<std::endl;
      _spheresP2 = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output spheresP2: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "vtk") {
      std::cout << "Setting output vtk!" <<std::endl;
      _vtk = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output vtk: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "MG") {
      std::cout << "Setting output MG!" <<std::endl;
      _mg = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output MG: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }

  else {
      //ploter
      for(int k=0;k<plotterList;k++){
          if(id == (nodeNames[3]+plotterNames[k])) {
              std::cout << "Setting "+nodeNames[3]+" "+plotterNames[k]+" " <<std::endl;
              plotterInformation[k] = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting "+nodeNames[3]+" "+plotterNames[k]+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
      }
      //fluid
      for(int k=0;k<fluidList;k++){
          if(id == (nodeNames[2]+fluidNames[k])) {
              std::cout << "Setting "+nodeNames[2]+" "+fluidNames[k]+" " <<std::endl;
              fluidInformation[k] = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting "+nodeNames[2]+" "+fluidNames[k]+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
      }
      //ode
      for(int k=0;k<odeList;k++){
          if(id == (nodeNames[1]+odeNames[k])) {
              std::cout << "Setting "+nodeNames[1]+" "+odeNames[k]+" " <<std::endl;
              odeInformation[k] = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting "+nodeNames[1]+" "+odeNames[k]+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
      }
      //solver
      for(int k=0;k<solverList;k++){
          if(id == (nodeNames[0]+solverNames[k])) {
              std::cout << "Setting "+nodeNames[0]+" "+solverNames[k]+" " <<std::endl;
              solverInformation[k] = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting "+nodeNames[0]+" "+solverNames[k]+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
      }
      //domain
      for(int k=0;k<domainList;k++){
          if(id == (nodeNames[4]+domainNames[k])) {
              std::cout << "Setting "+nodeNames[4]+" "+domainNames[k]+" " <<std::endl;
              domainInformation[k] = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting "+nodeNames[4]+" "+domainNames[k]+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
      }
      //stack
      for(int k=0;k<stackList;k++){
          if(id == (nodeNames[5]+stackNames[k])) {
              std::cout << "Setting "+nodeNames[5]+" "+stackNames[k]+" " <<std::endl;
              stackInformation[k] = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting "+nodeNames[5]+" "+stackNames[k]+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
      }
      //experiment-name
      if(id == (nodeNames[6])) {
          std::cout << "Setting "+nodeNames[6]+" " <<std::endl;
          experiment_name = static_cast<ParameterWithStringValue*> (p)->getStringValue();
          std::cout<<"Setting "+nodeNames[6]+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
      }
      //geometry
//      if(id=="numGeometry"){
//          std::cout << "Setting numGeometry" <<std::endl;
//          std::stringstream sx(static_cast<ParameterWithStringValue*> (p)->getStringValue());
//          sx>>_sizes;
//          std::cout<<"Setting numGeometry "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
//      }//to do add Logfilter
      for(int k=0;k<_sizes;k++){
          std::sprintf(t,"%d",k+1);
                          s=t;
          if(id==("GeometryName"+s)){
              std::cout << "Setting GeometryName "+s+" " <<std::endl;
              geometrys[k].name = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting GeometryName "+s+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
          if(id==("geometry-base-number"+s)){
              std::cout << "Setting geometry-base-number "+s+" " <<std::endl;
              geometrys[k].geometry_base_number = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting geometry-base-number "+s+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
          if(id==("invert"+s)){
              std::cout << "Setting invert "+s+" " <<std::endl;
              geometrys[k].invert = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting invert "+s+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
          if(id==("radius"+s)){
              std::cout << "Setting radius "+s+" " <<std::endl;
              geometrys[k].r = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting radius "+s+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
          for (int m=0;m<Peano_Dimension;m++){
              std::sprintf(t,"%d",m);
              n=t;
              if(id==("minimal_meshsize"+s+" "+n)){
                  std::cout << "Setting minimal_meshsize "+s+" "+n <<std::endl;
                  geometrys[k].minimal_meshsize[m] = static_cast<ParameterWithStringValue*> (p)->getStringValue();
                  std::cout<<"Setting radius "+s+" "+n+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
              }
              if(id==("maximal_meshsize"+s+" "+n)){
                  std::cout << "Setting maximal_meshsize "+s+" "+n <<std::endl;
                  geometrys[k].maximal_meshsize[m] = static_cast<ParameterWithStringValue*> (p)->getStringValue();
                  std::cout<<"Setting maximal_meshsize "+s+" "+n+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
              }
              if(id==("offset"+s+" "+n)){
                  std::cout << "Setting offset "+s+" "+n <<std::endl;
                  geometrys[k].offset[m] = static_cast<ParameterWithStringValue*> (p)->getStringValue();
                  std::cout<<"Setting offset "+s+" "+n+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
              }
              if(id==("bounding_box"+s+" "+n)){
                  std::cout << "Setting bounding_box "+s+" "+n <<std::endl;
                  geometrys[k].bounding_box[m] = static_cast<ParameterWithStringValue*> (p)->getStringValue();
                  std::cout<<"Setting bounding_box "+s+" "+n+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
              }
          }

      }
      //add Sphere
      if(id==("newradius")){
          std::cout << "Setting newradius " <<std::endl;
          newSphere.r = static_cast<ParameterWithStringValue*> (p)->getStringValue();
          std::cout<<"Setting newradius "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
      }
      for (int m=0;m<Peano_Dimension;m++){
          std::sprintf(t,"%d",m);
          n=t;
          if(id==("newoffset"+n)){
              std::cout << "Setting newoffset "+n <<std::endl;
              newSphere.offset[m] = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting newoffset "+n+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
//          delete Sphere
          if(id==("oldoffset"+n)){
              std::cout << "Setting oldoffset "+n <<std::endl;
              oldSphere.offset[m] = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting oldoffset "+n+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
      }
      if(id==("AddSphere")){
          if(!(static_cast<ParameterCollection*>(p)->wasCancelled())){
              if(!(newSphere.r=="")&&!(newSphere.offset[0]=="")&&!(newSphere.offset[1]=="")&&!(newSphere.offset[2]=="")){

                  QDomElement root=_doc.documentElement();
                  QDomNodeList nodeList=root.elementsByTagName(QString("geometry"));
                  if(nodeList.count()>0)
                    {
                      QDomElement refchild =nodeList.at(nodeList.count()-1).toElement();;
                      QDomElement child =_doc.createElement(QString("geometry"));
                      QDomAttr name=_doc.createAttribute(QString("name"));
                      QDomAttr geometry_base_number=_doc.createAttribute(QString("geometry-base-number"));
                      QDomAttr invert=_doc.createAttribute(QString("invert"));

                      QDomAttr minimal_meshsize1=_doc.createAttribute(QString("h0"));
                      QDomAttr minimal_meshsize2=_doc.createAttribute(QString("h1"));
                      QDomAttr minimal_meshsize3=_doc.createAttribute(QString("h2"));
                      QDomAttr maximal_meshsize1=_doc.createAttribute(QString("h0"));
                      QDomAttr maximal_meshsize2=_doc.createAttribute(QString("h1"));
                      QDomAttr maximal_meshsize3=_doc.createAttribute(QString("h2"));
                      QDomAttr offset1=_doc.createAttribute(QString("x0"));
                      QDomAttr offset2=_doc.createAttribute(QString("x1"));
                      QDomAttr offset3=_doc.createAttribute(QString("x2"));

                      QDomElement minimal_meshsize =_doc.createElement(QString("minimal-meshsize"));
                      QDomElement maximal_meshsize =_doc.createElement(QString("maximal-meshsize"));
                      QDomElement offset =_doc.createElement(QString("offset"));

                      const char* newname=newSphere.name.c_str();
                      name.setValue(QString(newname));
                      const char* newinvert=newSphere.invert.c_str();
                      geometry_base_number.setValue(QString(newinvert));
                      const char* newgeometry_base_number=newSphere.geometry_base_number.c_str();
                      invert.setValue(QString(newgeometry_base_number));

                      const char* newminimal_meshsize1=newSphere.minimal_meshsize[0].c_str();
                      minimal_meshsize1.setValue(QString(newminimal_meshsize1));
                      const char* newminimal_meshsize2=newSphere.minimal_meshsize[1].c_str();
                      minimal_meshsize2.setValue(QString(newminimal_meshsize2));
                      const char* newminimal_meshsize3=newSphere.minimal_meshsize[2].c_str();
                      minimal_meshsize3.setValue(QString(newminimal_meshsize3));
                      minimal_meshsize.setAttributeNode(minimal_meshsize1);
                      minimal_meshsize.setAttributeNode(minimal_meshsize2);
                      minimal_meshsize.setAttributeNode(minimal_meshsize3);

                      const char* newmaximal_meshsize1=newSphere.maximal_meshsize[0].c_str();
                      maximal_meshsize1.setValue(QString(newmaximal_meshsize1));
                      const char* newmaximal_meshsize2=newSphere.maximal_meshsize[1].c_str();
                      maximal_meshsize2.setValue(QString(newmaximal_meshsize2));
                      const char* newmaximal_meshsize3=newSphere.maximal_meshsize[2].c_str();
                      maximal_meshsize3.setValue(QString(newmaximal_meshsize3));
                      maximal_meshsize.setAttributeNode(maximal_meshsize1);
                      maximal_meshsize.setAttributeNode(maximal_meshsize2);
                      maximal_meshsize.setAttributeNode(maximal_meshsize3);

                      const char* newoffset1=newSphere.offset[0].c_str();
                      offset1.setValue(QString(newoffset1));
                      const char* newoffset2=newSphere.offset[1].c_str();
                      offset2.setValue(QString(newoffset2));
                      const char* newoffset3=newSphere.offset[2].c_str();
                      offset3.setValue(QString(newoffset3));
                      offset.setAttributeNode(offset1);
                      offset.setAttributeNode(offset2);
                      offset.setAttributeNode(offset3);

                      child.setAttributeNode(name);
                      child.setAttributeNode(geometry_base_number);
                      child.setAttributeNode(invert);

                      child.appendChild(minimal_meshsize);
                      child.appendChild(maximal_meshsize);
                      child.appendChild(offset);

                      QDomElement el=nodeList.at(0).toElement();
                      QDomElement parent=el.parentNode().toElement();
                      parent.insertAfter(child,refchild);
                      geometrys.push_back(newSphere);
                      _sizes=geometrys.size();
                      std::cout<<"add new Sphere "<< static_cast<ParameterCollection*>(p)->getStringValue()<<endl;
                    }
              }
              else{
                  ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                                                 << "can't create Sphere with empty "<< std::endl;
              }
          }
          else{
              newSphere.r ="";
              newSphere.offset[0] ="";
              newSphere.offset[1] ="";
              newSphere.offset[2] ="";
              std::cout<<"Canel add new filter "<< static_cast<ParameterCollection*>(p)->wasCancelled()<<endl;
          }
      }
      if(id==("RemoveSphere")){
          if(!(static_cast<ParameterCollection*>(p)->wasCancelled())){
              std::cout<<"try to delete sphere"<<endl;
              if(!(oldSphere.offset[0]=="")||!(oldSphere.offset[1]=="")||!(oldSphere.offset[2]=="")){
                  std::cout<<"set sphere offset"<<endl;
                  QDomElement root=_doc.documentElement();
                  QDomNodeList nodeList=root.elementsByTagName(QString("geometry"));
                  QDomElement oldchild;
                  int k;
                  int number;
                  if(nodeList.count()>0)
                    {
                      for(k=0;k<nodeList.count();k++){
                          QDomElement candiate=nodeList.at(k).toElement();
                          QDomNodeList childList=candiate.elementsByTagName(QString("offset"));
                          if(childList.count()>0){
                              QDomNamedNodeMap attributes =childList.at(0).toElement().attributes();
                              number=0;
                              for(int j=0;j<attributes.count();j++){
                                  QDomNode attribute=attributes.item(j);
                                  const char* oldOffset=oldSphere.offset[j].c_str();
                                  if(attribute.toAttr().value()==QString(oldOffset)){
                                      number++;
                                  }
                              }
                              if(number==3){
                                  oldchild=candiate;
                                  break;
                              }
                          }
                      }
                      if(k==nodeList.count()){
                          std::cout<<"no Sphere exist"<<endl;
                      }
                      else{
                          QDomElement el=nodeList.at(0).toElement();
                          QDomElement parent=el.parentNode().toElement();
                          parent.removeChild(oldchild);
                          geometrys.erase(geometrys.begin()+k);
                          _sizes=geometrys.size();
                          std::cout<<"delete Sphere "<< static_cast<ParameterCollection*>(p)->getStringValue()<<endl;
                      }
                    }
              }
              else{
                  ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                                                 << "can't delete Sphere with empty "<< std::endl;
              }
          }
          else{
              oldSphere.offset[0] ="";
              oldSphere.offset[1] ="";
              oldSphere.offset[2] ="";
              std::cout<<"Cancel delete Sphere "<< static_cast<ParameterCollection*>(p)->wasCancelled()<<endl;
          }

      }
      //Logfilter
      if(id=="numLogFilter"){
          std::cout << "Setting numLogFilter" <<std::endl;
          std::stringstream sx(static_cast<ParameterWithStringValue*> (p)->getStringValue());
          sx>>_sizelogFilters;
          std::cout<<"Setting numLogFilter "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
      }//to do add Logfilter
      for(int k=0;k<_sizelogFilters;k++){
          std::sprintf(t,"%d",k+1);
                          s=t;
          if(id==("component"+s)){
              std::cout << "Setting component "+s+" " <<std::endl;
              logFilters[k].component = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting component "+s+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
          if(id==("target"+s)){
              std::cout << "Setting target "+s+" " <<std::endl;
              logFilters[k].target = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting target "+s+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
          if(id==("rank"+s)){
              std::cout << "Setting rank "+s+" " <<std::endl;
              logFilters[k].rank = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting rank "+s+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }
          if(id==("_switch"+s)){
              std::cout << "Setting _switch "+s+" " <<std::endl;
              logFilters[k]._switch = static_cast<ParameterWithStringValue*> (p)->getStringValue();
              std::cout<<"Setting _switch "+s+" "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
          }

      }
      //add logfiter
      if(id==("newTarget")){
          std::cout << "Setting newTarget " <<std::endl;
          newLogFilter.target = static_cast<ParameterWithStringValue*> (p)->getStringValue();
          std::cout<<"Setting newTarget "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
      }
      if(id==("newComponent")){
          std::cout << "Setting newComponent " <<std::endl;
          newLogFilter.component = static_cast<ParameterWithStringValue*> (p)->getStringValue();
          std::cout<<"Setting newComponent "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
      }
      if(id==("newSwitch")){
          std::cout << "Setting newSwitch " <<std::endl;
          newLogFilter._switch = static_cast<ParameterWithStringValue*> (p)->getStringValue();
          std::cout<<"Setting newSwitch "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
      }
      if(id==("newRank")){
          std::cout << "Setting newRank " <<std::endl;
          newLogFilter.rank = static_cast<ParameterWithStringValue*> (p)->getStringValue();
          std::cout<<"Setting newRank "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
      }
      if(id==("AddLogFilter")){
          if(!(static_cast<ParameterCollection*>(p)->wasCancelled())){
              if(!(newLogFilter._switch=="")&&!(newLogFilter.component=="")&&!(newLogFilter.target=="")){

              QDomElement root=_doc.documentElement();
              QDomNodeList nodeList=root.elementsByTagName(QString("log-filter"));
              if(nodeList.count()>0)
                {
                  QDomElement refchild =nodeList.at(nodeList.count()-1).toElement();;
                  QDomElement child =_doc.createElement(QString("log-filter"));
                  QDomAttr target=_doc.createAttribute(QString("target"));
                  QDomAttr component=_doc.createAttribute(QString("component"));
                  QDomAttr _switch=_doc.createAttribute(QString("switch"));
                  QDomAttr rank=_doc.createAttribute(QString("rank"));

                  const char* newtarget=newLogFilter.target.c_str();
                  target.setValue(QString(newtarget));
                  const char* newcomponent=newLogFilter.component.c_str();
                  component.setValue(QString(newcomponent));
                  const char* newswitch=newLogFilter._switch.c_str();
                  _switch.setValue(QString(newswitch));
                  const char* newrank=newLogFilter.rank.c_str();
                  rank.setValue(QString(newrank));

                  child.setAttributeNode(target);
                  child.setAttributeNode(component);
                  child.setAttributeNode(_switch);
                  if(!(newLogFilter.rank==""))
                    child.setAttributeNode(rank);
                  QDomElement el=nodeList.at(0).toElement();
                  QDomElement parent=el.parentNode().toElement();
                  parent.insertAfter(child,refchild);
                  logFilters.push_back(newLogFilter);
                  _sizelogFilters=logFilters.size();
                  std::cout<<"add new filter "<< static_cast<ParameterCollection*>(p)->getStringValue()<<endl;
                }
              }
              else{
                  ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                                       << "can't create LogFilter with empty "<< std::endl;
              }
          }
          else{
              newLogFilter.rank ="";
              newLogFilter.target ="";
              newLogFilter.component ="";
              newLogFilter._switch ="";
              std::cout<<"Canel add new filter "<< static_cast<ParameterCollection*>(p)->wasCancelled()<<endl;
          }
      }
      //delete Filter
      if(id==("oldTarget")){
          std::cout << "Setting oldTarget " <<std::endl;
          oldLogFilter.target = static_cast<ParameterWithStringValue*> (p)->getStringValue();
          std::cout<<"Setting oldTarget "<< static_cast<ParameterWithStringValue*>(p)->getStringValue()<<endl;
      }
      if(id==("RemoveLogFilter")){
          if(!(static_cast<ParameterCollection*>(p)->wasCancelled())){
              if(!(oldLogFilter.target=="")){
                  QDomElement root=_doc.documentElement();
                  QDomNodeList nodeList=root.elementsByTagName(QString("log-filter"));
                  QDomElement oldchild;
                  int k;
                  bool jump=false;
                  if(nodeList.count()>0)
                    {
                      for(k=0;k<nodeList.count();k++){
                          QDomElement candiate=nodeList.at(k).toElement();
                          QDomNamedNodeMap attributes =candiate.attributes();
                          for(int j=0;j<attributes.count();j++){
                              QDomNode attribute=attributes.item(j);
                              const char* oldtarget=oldLogFilter.target.c_str();
                              if(attribute.toAttr().value()==QString(oldtarget)){
                                  oldchild=candiate;
                                  jump=true;
                                  break;
                              }
                          }
                          if(jump)
                            break;
                      }
                      if(k==nodeList.count()){
                          std::cout<<"no filter exist"<<endl;
                      }
                      else{
                          QDomElement el=nodeList.at(0).toElement();
                          QDomElement parent=el.parentNode().toElement();
                          parent.removeChild(oldchild);
                          logFilters.erase(logFilters.begin()+k);
                          _sizelogFilters=logFilters.size();
                          std::cout<<"delete filter "<< static_cast<ParameterCollection*>(p)->getStringValue()<<endl;
                      }
                    }
              }
              else{
                  ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                                       << "can't delete LogFilter with empty "<< std::endl;
              }
          }
          else{
              newLogFilter.target ="";
              std::cout<<"Cancel delete filter "<< static_cast<ParameterCollection*>(p)->wasCancelled()<<endl;
          }

      }
  }

  std::cout << "Parameter value is set!" << endl;
}

bool PeanoGenerator::validateParameters() {
  bool isValid = true;

  return isValid;
}

vector<ParameterCollection*> PeanoGenerator::getParameters() {
  vector<ParameterCollection*> parameters;
//  ParameterCollection* tab = new ParameterCollection("PeanoCollection", "PeanoCollection",
//      "PeanoCollection", Parameter::BUTTON);
//  parameters.push_back(tab);
    std::string node;
    for(int i=0;i<nodeNumber;i++){
        node =nodeNames[i];
        ParameterCollection*  node_name = new ParameterCollection(node, node,
            node, Parameter::BUTTON);
        parameters.push_back(node_name);
        //LogFilter
        if(node==nodeNames[8]){
            ParameterWithIntValue* LogFilterSize = new ParameterWithIntValue("numLogFilter",
                "Number of LogFilter", "The number of LogFilter ",
                Parameter::LINE_EDIT,  true, _sizelogFilters);
            ParameterCollection* LogFilter  = new ParameterCollection("LogFilter", "LogFilter",
                "LogFilter", Parameter::BUTTON);

            ParameterCollection* AddLogFilter  = new ParameterCollection("AddLogFilter", "AddLogFilter",
                "AddLogFilter", Parameter::BUTTON, false, false, true);
            ParameterCollection* RemoveLogFilter  = new ParameterCollection("RemoveLogFilter", "RemoveLogFilter",
                "RemoveLogFilter", Parameter::BUTTON,false,false,true);
            std::string s;
            char t[256];
            for(int k=0;k<(int)logFilters.size();k++){
                std::sprintf(t,"%d",k+1);
                s=t;
                ParameterCollection* Detail  = new ParameterCollection("LogFilterDetail"+s, "LogFilter "+s+" Detail ",
                                                  "LogFilterDetail", Parameter::BUTTON);
                LogFilter->addParameter(new ParameterWithStringValue("component"+s,
                    "component"+s, "The component of LogFilter ",
                    Parameter::LINE_EDIT,  false, logFilters[k].component));
                Detail->addParameter(new ParameterWithStringValue("target"+s,
                                    "target", "The name of target ",
                                    Parameter::LINE_EDIT,  false, logFilters[k].target));
                Detail->addParameter(new ParameterWithStringValue("_switch"+s,
                    "_switch", "The _switch property of LogFilter ",
                    Parameter::LINE_EDIT,  false, logFilters[k]._switch));
                if(!(logFilters[k].rank=="")){
                    Detail->addParameter(new ParameterWithStringValue("rank"+s,
                    "rank", "The rank property of LogFilter ",
                    Parameter::LINE_EDIT,  false, logFilters[k].rank));
                }
                LogFilter->addParameter(Detail);
            }
            //Add One LogFilter need the component, target, swith and rank if necessary
            AddLogFilter->addParameter(new ParameterWithStringValue("newTarget",
                "target", "The name of target ",
                Parameter::LINE_EDIT,  false, newLogFilter.target));
            AddLogFilter->addParameter(new ParameterWithStringValue("newComponent",
                "component", "The name of component ",
                Parameter::LINE_EDIT,  false, newLogFilter.component));
            AddLogFilter->addParameter(new ParameterWithStringValue("newSwitch",
                "switch", "The name of switch ",
                Parameter::LINE_EDIT,  false, newLogFilter._switch));
            AddLogFilter->addParameter(new ParameterWithStringValue("newRank",
                "rank", "The name of rank ",
                Parameter::LINE_EDIT,  false, newLogFilter.rank));
            //Remove one LogFilter just need target
            RemoveLogFilter->addParameter(new ParameterWithStringValue("oldTarget",
                            "target", "The name of target ",
                            Parameter::LINE_EDIT,  false, oldLogFilter.target));
            node_name->addParameter(LogFilterSize);
            node_name->addParameter(LogFilter);
            node_name->addParameter(AddLogFilter);
            node_name->addParameter(RemoveLogFilter);

        }
        //Geometry
        if(node==nodeNames[7]){

            ParameterWithIntValue* GeometrySize = new ParameterWithIntValue("numGeometry",
                                "Number of Geometry", "The number of Geometry ",
                                Parameter::LINE_EDIT,  true, _sizes);
            ParameterCollection* Geometry  = new ParameterCollection("Geometry", "Geometry",
                  "Geometry", Parameter::BUTTON);
            ParameterCollection* AddSphere  = new ParameterCollection("AddSphere", "AddSphere",
                "AddSphere", Parameter::BUTTON, false, false, true);
            ParameterCollection* RemoveSphere  = new ParameterCollection("RemoveSphere", "RemoveSphere",
                "RemoveSphere", Parameter::BUTTON,false,false,true);
            std::string s;
            char t[256];
            std::string n;
            for(int k=0;k<_sizes;k++){
                std::sprintf(t,"%d",k+1);
                s=t;
                Geometry->addParameter(new ParameterWithStringValue("GeometryName"+s,
                              "Name", "The name of Geometry ",
                              Parameter::LINE_EDIT,  false, geometrys[k].name));
                Geometry->addParameter(new ParameterWithStringValue("geometry-base-number"+s,
                    "geometry-base-number", "The geometry-base-number of Geometry ",
                    Parameter::LINE_EDIT,  false, geometrys[k].geometry_base_number));
                Geometry->addParameter(new ParameterWithStringValue("invert"+s,
                    "invert", "The invert property of Geometry ",
                    Parameter::LINE_EDIT,  false, geometrys[k].invert));
                ParameterCollection* Detail  = new ParameterCollection("GeometryDetail"+s, "Geometry "+s+" Detail ",
                                  "GeometryDetail", Parameter::BUTTON);
//Common property for Geometry
                for(int m=0;m<Peano_Dimension;m++){
                    std::sprintf(t,"%d",m);
                    n=t;
                Detail->addParameter(new ParameterWithStringValue("minimal_meshsize"+s+" "+n,
                                    "minimal-meshsize"+n, "The minimal-meshsize of Geometry ",
                                    Parameter::LINE_EDIT,  false, geometrys[k].minimal_meshsize[m]));
                }
                for(int m=0;m<Peano_Dimension;m++){
                    std::sprintf(t,"%d",m);
                    n=t;
                Detail->addParameter(new ParameterWithStringValue("maximal_meshsize"+s+" "+n,
                                    "maximal-meshsize"+n, "The maximal-meshsize of Geometry ",
                                    Parameter::LINE_EDIT,  false, geometrys[k].maximal_meshsize[m]));
                }
                for(int m=0;m<Peano_Dimension;m++){
                    std::sprintf(t,"%d",m);
                    n=t;
                Detail->addParameter(new ParameterWithStringValue("offset"+s+" "+n,
                                    "offset"+n, "The offset of Geometry ",
                                    Parameter::LINE_EDIT,  false, geometrys[k].offset[m]));
                }
//Special property for each kind of  Geometry
                if(geometrys[k].name=="sphere"){
                    Detail->addParameter(new ParameterWithStringValue("radius"+s,
                                        "radius", "The radius of Geometry ",
                                        Parameter::LINE_EDIT,  false, geometrys[k].r));
                }
                if(geometrys[k].name=="hexahedron"){
                    for(int m=0;m<Peano_Dimension;m++){
                        std::sprintf(t,"%d",m);
                        n=t;
                    Detail->addParameter(new ParameterWithStringValue("bounding_box"+s+" "+n,
                                        "bounding_box"+n, "The bounding_box of Geometry ",
                                        Parameter::LINE_EDIT,  false, geometrys[k].bounding_box[m]));
                    }
                }
                Geometry->addParameter(Detail);
            }
//add One sphere need radius and offset
            AddSphere->addParameter(new ParameterWithStringValue("newradius",
                "radius", "The radius of sphere ",
                Parameter::LINE_EDIT,  false, newSphere.r));
            for(int m=0;m<Peano_Dimension;m++){
                std::sprintf(t,"%d",m);
                n=t;
                AddSphere->addParameter(new ParameterWithStringValue("newoffset"+n,
                    "offset"+n, "The offset of sphere ",
                    Parameter::LINE_EDIT,  false, newSphere.offset[m]));
            }
//Remove one sphere just need offset
            for(int m=0;m<Peano_Dimension;m++){
                std::sprintf(t,"%d",m);
                n=t;
                RemoveSphere->addParameter(new ParameterWithStringValue("oldoffset"+n,
                    "offset"+n, "The offset of sphere ",
                    Parameter::LINE_EDIT,  false, oldSphere.offset[m]));
            }
            node_name->addParameter(GeometrySize);
            node_name->addParameter(Geometry);
            node_name->addParameter(AddSphere);
            node_name->addParameter(RemoveSphere);
        }
        //experiment-name
        if(node==nodeNames[6]){
                node_name->addParameter(new ParameterWithStringValue(nodeNames[6], nodeNames[6],
                    nodeNames[6] , Parameter::LINE_EDIT, false, experiment_name));
        }
        //stack
        if(node==nodeNames[5]){
            for (int k=0;k<stackList;k++){
                node_name->addParameter(new ParameterWithStringValue(nodeNames[5]+stackNames[k], stackNames[k],
                    nodeNames[5]+stackNames[k] , Parameter::LINE_EDIT, false, stackInformation[k]));
            }
        }
        //domain
        if(node==nodeNames[4]){
            for (int k=0;k<domainList;k++){
                node_name->addParameter(new ParameterWithStringValue(nodeNames[4]+domainNames[k], domainNames[k],
                    nodeNames[4]+domainNames[k] , Parameter::LINE_EDIT, false, domainInformation[k]));
            }
        }
        //plotter
        if(node==nodeNames[3]){
            for (int k=0;k<plotterList;k++){
                node_name->addParameter(new ParameterWithStringValue(nodeNames[3]+plotterNames[k], plotterNames[k],
                    nodeNames[3]+plotterNames[k] , Parameter::LINE_EDIT, false, plotterInformation[k]));
            }
        }
        //fluid
        if(node==nodeNames[2]){
            for (int k=0;k<fluidList;k++){
                node_name->addParameter(new ParameterWithStringValue(nodeNames[2]+fluidNames[k], fluidNames[k],
                    nodeNames[2]+fluidNames[k] , Parameter::LINE_EDIT, false, fluidInformation[k]));
            }
        }
        //ode
        if(node==nodeNames[1]){
            for (int k=0;k<odeList;k++){
                node_name->addParameter(new ParameterWithStringValue(nodeNames[1]+odeNames[k], odeNames[k],
                    nodeNames[1]+odeNames[k] , Parameter::LINE_EDIT, false, odeInformation[k]));
            }
        }
        //solver
        if(node==nodeNames[0]){
            for (int k=0;k<solverList;k++){
                node_name->addParameter(new ParameterWithStringValue(nodeNames[0]+solverNames[k], solverNames[k],
                    nodeNames[0]+solverNames[k] , Parameter::LINE_EDIT, false, solverInformation[k]));
            }
        }
    }



    //OutPut
    ParameterCollection* output  = new ParameterCollection("Output", "Output",
        "Output", Parameter::BUTTON);
    output->addParameter(new ParameterWithBool("spheresP1", "spheresP1",
        "Output the spheresP1" , Parameter::CHECKBOX, false, false));
    output->addParameter(new ParameterWithBool("spheresP2", "spheresP2",
        "Output the spheresP2" , Parameter::CHECKBOX, false, false));
    output->addParameter(new ParameterWithBool("vtk", "vtk",
        "Output the vtk" , Parameter::CHECKBOX, false, false));
    output->addParameter(new ParameterWithBool("MG", "MG",
        "Output the MG_let file" , Parameter::CHECKBOX, false, false));
    parameters.push_back(output);
  return parameters;
}

void PeanoGenerator::generatePreview() {
  if(validateParameters()){
      int id=0;
      double x,y,z,r;
      for (int i = 0; i < (int)geometrys.size(); i++) {
          if(geometrys[i].name=="sphere"){
              std::stringstream sx(geometrys[i].offset[0]);
              sx>>x;
              std::stringstream sy(geometrys[i].offset[1]);
              sy>>y;
              std::stringstream sz(geometrys[i].offset[2]);
              sz>>z;
              std::stringstream sr(geometrys[i].r);
              sr>>r;
          ScenarioGeneratorApplication::getInstance()->addObject(
              new PeanoObject(
                  x,
                  y,
                  z,
                  r,id));
          id++;
          }
      }
  }
}

void PeanoGenerator::generateOutput(const std::string& directory){
  if(directory!=""){
      xml::threeD::SpherePrinter output;
      if(_spheresP1){
          string spheresP1 = directory + "/spheresP1.xml";
          output.printP1Spherepack(SpherePacking,"1/3","1/27",spheresP1);
      }
      if(_spheresP2){
          string spheresP2 = directory + "/spheresP2.xml";
          output.printP2Spherepack(SpherePacking,spheresP2);
      }
      if(_vtk){
          string spherevtk = directory + "/sphere_poly.vtp";
          string domain = directory + "/domain.vtp";
          vtk:: Visualization vtk(&SpherePacking);
          vtk.generateSphere(spherevtk,domain);
      }
      if(_mg){
          string MG = directory + "/MG-Let.txt";
          output.printMGSpherepack(SpherePacking,MG);
      }
  }
}

void PeanoGenerator::createSampleObject() const {
  ScenarioGeneratorApplication::getInstance()->addObject(
      new PeanoObject(0,0,0,0.2,1));
}

void PeanoGenerator::load(const std::string& filename){
  const char * configuration=filename.c_str();
  QFile file (configuration);
  if (!file.open(QIODevice::ReadOnly))
    ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                     << "can't open configuration "<< filename<< std::endl;
  if (!_doc.setContent(&file)){
      file.close();
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                           << "can't read configuration into ScenarioGenerator "<<  std::endl;
  }
  file.close();
  initialConfiguration();
}

void PeanoGenerator::save(const std::string& filename){
  writeConfiguration();
  const char * configuration=filename.c_str();
  QFile output (configuration);
  if( !output.open( QIODevice::WriteOnly ) )
    ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                     << "can't write configuration "<< filename<< std::endl;
  QTextStream out(&output);
  out << _doc.toString();
  output.close();
}

void PeanoGenerator::initialConfiguration(){

   QDomElement root=_doc.documentElement();
   //plotter
   const char *name3 = nodeNames[3].c_str();
   QDomNodeList nodeList=root.elementsByTagName(QString(name3));
   geometrys.clear();
   logFilters.clear();
   if(nodeList.count()>0)
     {
       QDomElement el=nodeList.at(0).toElement();
       QDomNamedNodeMap attributes= el.attributes();
       for(int i=0;i<attributes.count();i++){
           QDomNode attribute =attributes.item(i);
           for(int k=0;k<plotterList;k++){
               const char *name = plotterNames[k].c_str();
           if(attribute.toAttr().name()==QString(name))
             plotterInformation[k]=attribute.toAttr().value().toStdString();
           }
       }
     }
   //fluid
   const char *name2 = nodeNames[2].c_str();
   nodeList=root.elementsByTagName(QString(name2));
   if(nodeList.count()>0)
     {
       QDomElement el=nodeList.at(0).toElement();
       QDomNamedNodeMap attributes= el.attributes();
       for(int i=0;i<attributes.count();i++){
           QDomNode attribute =attributes.item(i);
           for(int k=0;k<fluidList;k++){
               const char *name = fluidNames[k].c_str();
           if(attribute.toAttr().name()==QString(name))
             fluidInformation[k]=attribute.toAttr().value().toStdString();
           }
       }
     }
   //ode
   const char *name1= nodeNames[1].c_str();
   nodeList=root.elementsByTagName(QString(name1));
   if(nodeList.count()>0)
     {
       QDomElement el=nodeList.at(0).toElement();
       QDomNamedNodeMap attributes= el.attributes();
       for(int i=0;i<attributes.count();i++){
           QDomNode attribute =attributes.item(i);
           for(int k=0;k<odeList;k++){
               const char *name = odeNames[k].c_str();
               if(attribute.toAttr().name()==QString(name))
                 odeInformation[k]=attribute.toAttr().value().toStdString();
           }
       }
     }
   //solver
   const char *name0 = nodeNames[0].c_str();
   nodeList=root.elementsByTagName(QString(name0));
   if(nodeList.count()>0)
     {
       QDomElement el=nodeList.at(0).toElement();
       QDomNamedNodeMap attributes= el.attributes();
       for(int i=0;i<attributes.count();i++){
           QDomNode attribute =attributes.item(i);
           for(int k=0;k<solverList;k++){
               const char *name = solverNames[k].c_str();
               if(attribute.toAttr().name()==QString(name))
                 solverInformation[k]=attribute.toAttr().value().toStdString();
           }
       }
     }
   //domain
   const char *name4 = nodeNames[4].c_str();
      nodeList=root.elementsByTagName(QString(name4));
      if(nodeList.count()>0)
        {
          QDomElement el=nodeList.at(0).toElement();
          QDomNamedNodeMap attributes= el.attributes();
          for(int i=0;i<attributes.count();i++){
              QDomNode attribute =attributes.item(i);
              for(int k=0;k<domainList;k++){
                  const char *name = domainNames[k].c_str();
                  if(attribute.toAttr().name()==QString(name))
                    domainInformation[k]=attribute.toAttr().value().toStdString();
              }
          }
        }
   //stack
   const char *name5 = nodeNames[5].c_str();
      nodeList=root.elementsByTagName(QString(name5));
      if(nodeList.count()>0)
        {
          QDomElement el=nodeList.at(0).toElement();
          QDomNamedNodeMap attributes= el.attributes();
          for(int i=0;i<attributes.count();i++){
              QDomNode attribute =attributes.item(i);
              for(int k=0;k<stackList;k++){
                  const char *name = stackNames[k].c_str();
                  if(attribute.toAttr().name()==QString(name))
                    stackInformation[k]=attribute.toAttr().value().toStdString();
              }
          }
        }
   //experiment-name
      const char *name6 = nodeNames[6].c_str();
      nodeList=root.elementsByTagName(QString(name6));
      if(nodeList.count()>0)
        {
          QDomElement el=nodeList.at(0).toElement();
          experiment_name=el.text().toStdString();
        }
   //Geometry
      const char *name7 = nodeNames[7].c_str();
      nodeList=root.elementsByTagName(QString(name7));
      if(nodeList.count()>0)
        {
          for(int k=0;k<nodeList.count();k++){
              QDomElement el=nodeList.at(k).toElement();
              QDomNamedNodeMap attributes= el.attributes();
              Geometry geometry;
              for(int i=0;i<attributes.count();i++){
                  QDomNode attribute =attributes.item(i);
                  if(attribute.toAttr().name()==QString("name")){
                      geometry.name=attribute.toAttr().value().toStdString();
                  }
                  if(attribute.toAttr().name()==QString("invert")){
                      geometry.invert=attribute.toAttr().value().toStdString();
                  }
                  if(attribute.toAttr().name()==QString("geometry-base-number")){
                      geometry.geometry_base_number=attribute.toAttr().value().toStdString();
                  }
              }
              QDomNodeList list=el.childNodes();
              for(int j=0;j<list.count();j++){
                  QDomNode node =list.at(j);
                  QDomElement element=node.toElement();
                  if(element.tagName()==QString("radius")){
                      QDomNamedNodeMap attributesChild= element.attributes();
                      for(int m=0;m<attributesChild.count();m++){
                          QDomNode attributeChild =attributesChild.item(m);
                          if(attributeChild.toAttr().name()==QString("r")){
                            geometry.r=attributeChild.toAttr().value().toStdString();
                          }
                      }
                  }
                  if(element.tagName()==QString("minimal-meshsize")){
                      QDomNamedNodeMap attributesChild= element.attributes();
                      for(int m=0;m<attributesChild.count();m++){
                          QDomNode attributeChild =attributesChild.item(m);
                          if(attributeChild.toAttr().name()==QString("h0")){
                            geometry.minimal_meshsize[0]=attributeChild.toAttr().value().toStdString();
                          }
                          if(attributeChild.toAttr().name()==QString("h1")){
                            geometry.minimal_meshsize[1]=attributeChild.toAttr().value().toStdString();
                          }
                          if(attributeChild.toAttr().name()==QString("h2")){
                            geometry.minimal_meshsize[2]=attributeChild.toAttr().value().toStdString();
                          }
                      }
                  }
                  if(element.tagName()==QString("maximal-meshsize")){
                      QDomNamedNodeMap attributesChild= element.attributes();
                      for(int m=0;m<attributesChild.count();m++){
                          QDomNode attributeChild =attributesChild.item(m);
                          if(attributeChild.toAttr().name()==QString("h0")){
                              geometry.maximal_meshsize[0]=attributeChild.toAttr().value().toStdString();
                          }
                          if(attributeChild.toAttr().name()==QString("h1")){
                              geometry.maximal_meshsize[1]=attributeChild.toAttr().value().toStdString();
                          }
                          if(attributeChild.toAttr().name()==QString("h2")){
                              geometry.maximal_meshsize[2]=attributeChild.toAttr().value().toStdString();
                          }
                      }
                  }
                  if(element.tagName()==QString("offset")){
                      QDomNamedNodeMap attributesChild= element.attributes();
                      for(int m=0;m<attributesChild.count();m++){
                          QDomNode attributeChild =attributesChild.item(m);
                          if(attributeChild.toAttr().name()==QString("x0")){
                              geometry.offset[0]=attributeChild.toAttr().value().toStdString();
                          }
                          if(attributeChild.toAttr().name()==QString("x1")){
                              geometry.offset[1]=attributeChild.toAttr().value().toStdString();
                          }
                          if(attributeChild.toAttr().name()==QString("x2")){
                              geometry.offset[2]=attributeChild.toAttr().value().toStdString();
                          }
                      }
                  }
                  if(element.tagName()==QString("bounding-box")){
                      QDomNamedNodeMap attributesChild= element.attributes();
                      for(int m=0;m<attributesChild.count();m++){
                          QDomNode attributeChild =attributesChild.item(m);
                          if(attributeChild.toAttr().name()==QString("h0")){
                              geometry.bounding_box[0]=attributeChild.toAttr().value().toStdString();
                          }
                          if(attributeChild.toAttr().name()==QString("h1")){
                              geometry.bounding_box[1]=attributeChild.toAttr().value().toStdString();
                          }
                          if(attributeChild.toAttr().name()==QString("h2")){
                              geometry.bounding_box[2]=attributeChild.toAttr().value().toStdString();
                          }
                      }
                  }
              }
              geometrys.push_back(geometry);
              if(geometry.name=="sphere"){
                  newSphere=geometry;
              }
          }
        }
      _sizes=geometrys.size();
      //logFilter
      const char *name8 = nodeNames[8].c_str();
      nodeList=root.elementsByTagName(QString(name8));
      if(nodeList.count()>0)
        {
          for(int k=0;k<nodeList.count();k++){
              QDomElement el=nodeList.at(k).toElement();
              QDomNamedNodeMap attributes= el.attributes();
              LogFilter logFilter;
              for(int i=0;i<attributes.count();i++){
                  QDomNode attribute =attributes.item(i);
                  if(attribute.toAttr().name()==QString("target")){
                      logFilter.target=attribute.toAttr().value().toStdString();
                  }
                  if(attribute.toAttr().name()==QString("component")){
                      logFilter.component=attribute.toAttr().value().toStdString();
                  }
                  if(attribute.toAttr().name()==QString("switch")){
                      logFilter._switch=attribute.toAttr().value().toStdString();
                  }
                  if(attribute.toAttr().name()==QString("rank")){
                      logFilter.rank=attribute.toAttr().value().toStdString();
                  }
              }
              logFilters.push_back(logFilter);
          }
        }
      _sizelogFilters=logFilters.size();
  ScenarioGeneratorApplication::getInstance()->getMainWindow()->updateAllPanels();
}

void PeanoGenerator::writeConfiguration(){
  QDomElement root=_doc.documentElement();
  //plotter
  const char *name3 = nodeNames[3].c_str();
  QDomNodeList nodeList=root.elementsByTagName(QString(name3));
  if(nodeList.count()>0)
    {
      QDomElement el=nodeList.at(0).toElement();
      for(int k=0;k<plotterList;k++){
      const char *value = plotterInformation[k].c_str();
      const char *name = plotterNames[k].c_str();
      el.setAttribute(QString(name),QString(value));
      }
    }
  //fluid
  const char*name2 = nodeNames[2].c_str();
  nodeList=root.elementsByTagName(QString(name2));
  if(nodeList.count()>0)
    {
      QDomElement el=nodeList.at(0).toElement();
      for(int k=0;k<fluidList;k++){
      const char *value = fluidInformation[k].c_str();
      const char *name = fluidNames[k].c_str();
      el.setAttribute(QString(name),QString(value));
      }
    }
  //ode
  const char*name1 = nodeNames[1].c_str();
  nodeList=root.elementsByTagName(QString(name1));
  if(nodeList.count()>0)
    {
      QDomElement el=nodeList.at(0).toElement();
      for(int k=0;k<odeList;k++){
      const char *value = odeInformation[k].c_str();
      const char *name = odeNames[k].c_str();
      el.setAttribute(QString(name),QString(value));
      }
    }
  //solver
  const char*name0 = nodeNames[0].c_str();
  nodeList=root.elementsByTagName(QString(name0));
  if(nodeList.count()>0)
    {
      QDomElement el=nodeList.at(0).toElement();
      for(int k=0;k<solverList;k++){
      const char *value = solverInformation[k].c_str();
      const char *name = solverNames[k].c_str();
      el.setAttribute(QString(name),QString(value));
      }
    }
  //domain
  const char*name4 = nodeNames[4].c_str();
  nodeList=root.elementsByTagName(QString(name4));
  if(nodeList.count()>0)
    {
      QDomElement el=nodeList.at(0).toElement();
      for(int k=0;k<domainList;k++){
      const char *value = domainInformation[k].c_str();
      const char *name = domainNames[k].c_str();
      el.setAttribute(QString(name),QString(value));
      }
    }
  //stack
  const char*name5 = nodeNames[5].c_str();
  nodeList=root.elementsByTagName(QString(name5));
  if(nodeList.count()>0)
    {
      QDomElement el=nodeList.at(0).toElement();
      for(int k=0;k<stackList;k++){
      const char *value = stackInformation[k].c_str();
      const char *name = stackNames[k].c_str();
      el.setAttribute(QString(name),QString(value));
      }
    }
  //experiment_name
  const char*name6 = nodeNames[6].c_str();
  nodeList=root.elementsByTagName(QString(name6));
  const char *value = experiment_name.c_str();
  if(nodeList.count()>0)
    {
      QDomElement el=nodeList.at(0).toElement();
      QDomNode oldnode= el.firstChild();
      el.firstChild().setNodeValue(QString(value));
      QDomNode newnode= el.firstChild();
      el.replaceChild(newnode,oldnode);
    }
  //Geometry
  const char *name7 = nodeNames[7].c_str();
    nodeList=root.elementsByTagName(QString(name7));
    if(nodeList.count()>0)
      {
        for(int k=0;k<nodeList.count();k++){
            QDomElement el=nodeList.at(k).toElement();
            QDomNamedNodeMap attributes= el.attributes();
            for(int i=0;i<attributes.count();i++){
                QDomNode attribute =attributes.item(i);
                if(attribute.toAttr().name()==QString("name")){
                    const char *value = geometrys.at(k).name.c_str();
                    el.setAttribute(QString("name"),QString(value));
                }
                if(attribute.toAttr().name()==QString("geometry-base-number")){
                    const char *value = geometrys.at(k).geometry_base_number.c_str();
                    el.setAttribute(QString("geometry-base-number"),QString(value));
                }
                if(attribute.toAttr().name()==QString("invert")){
                    const char *value = geometrys.at(k).invert.c_str();
                    el.setAttribute(QString("invert"),QString(value));
                }
            }
            QDomNodeList list=el.childNodes();
            for(int j=0;j<list.count();j++){
                QDomNode node =list.at(j);
                QDomElement element=node.toElement();
                if(element.tagName()==QString("offset")){
                    QDomNamedNodeMap attributesChild= element.attributes();
                    for(int m=0;m<attributesChild.count();m++){
                        QDomNode attributeChild =attributesChild.item(m);
                        if(attributeChild.toAttr().name()==QString("x0")){
                            const char *value = geometrys.at(k).offset[0].c_str();
                            element.setAttribute(QString("x0"),QString(value));
                        }
                        if(attributeChild.toAttr().name()==QString("x1")){
                            const char *value = geometrys.at(k).offset[1].c_str();
                            element.setAttribute(QString("x1"),QString(value));
                        }
                        if(attributeChild.toAttr().name()==QString("x2")){
                            const char *value = geometrys.at(k).offset[2].c_str();
                            element.setAttribute(QString("x2"),QString(value));
                        }
                    }
                }
                if(element.tagName()==QString("minimal-meshsize")){
                    QDomNamedNodeMap attributesChild= element.attributes();
                    for(int m=0;m<attributesChild.count();m++){
                        QDomNode attributeChild =attributesChild.item(m);
                        if(attributeChild.toAttr().name()==QString("h0")){
                            const char *value = geometrys.at(k).minimal_meshsize[0].c_str();
                            element.setAttribute(QString("h0"),QString(value));
                        }
                        if(attributeChild.toAttr().name()==QString("h1")){
                            const char *value = geometrys.at(k).minimal_meshsize[1].c_str();
                            element.setAttribute(QString("h1"),QString(value));
                        }
                        if(attributeChild.toAttr().name()==QString("h2")){
                            const char *value = geometrys.at(k).minimal_meshsize[2].c_str();
                            element.setAttribute(QString("h2"),QString(value));
                        }
                    }
                }
                if(element.tagName()==QString("maximal-meshsize")){
                    QDomNamedNodeMap attributesChild= element.attributes();
                    for(int m=0;m<attributesChild.count();m++){
                        QDomNode attributeChild =attributesChild.item(m);
                        if(attributeChild.toAttr().name()==QString("h0")){
                            const char *value = geometrys.at(k).maximal_meshsize[0].c_str();
                            element.setAttribute(QString("h0"),QString(value));
                        }
                        if(attributeChild.toAttr().name()==QString("h1")){
                            const char *value = geometrys.at(k).maximal_meshsize[1].c_str();
                            element.setAttribute(QString("h1"),QString(value));
                        }
                        if(attributeChild.toAttr().name()==QString("h2")){
                            const char *value = geometrys.at(k).maximal_meshsize[2].c_str();
                            element.setAttribute(QString("h2"),QString(value));
                        }
                    }
                }
                if(element.tagName()==QString("bounding-box")){
                    QDomNamedNodeMap attributesChild= element.attributes();
                    for(int m=0;m<attributesChild.count();m++){
                        QDomNode attributeChild =attributesChild.item(m);
                        if(attributeChild.toAttr().name()==QString("h0")){
                            const char *value = geometrys.at(k).bounding_box[0].c_str();
                            element.setAttribute(QString("h0"),QString(value));
                        }
                        if(attributeChild.toAttr().name()==QString("h1")){
                            const char *value = geometrys.at(k).bounding_box[1].c_str();
                            element.setAttribute(QString("h1"),QString(value));
                        }
                        if(attributeChild.toAttr().name()==QString("h2")){
                            const char *value = geometrys.at(k).bounding_box[2].c_str();
                            element.setAttribute(QString("h2"),QString(value));
                        }
                    }
                }
            }
        }
      }
  //logFilter
  const char *name8 = nodeNames[8].c_str();
  nodeList=root.elementsByTagName(QString(name8));
  if(nodeList.count()>0)
    {
      for(int k=0;k<nodeList.count();k++){
          QDomElement el=nodeList.at(k).toElement();
          QDomNamedNodeMap attributes= el.attributes();
          for(int i=0;i<attributes.count();i++){
              QDomNode attribute =attributes.item(i);
              if(attribute.toAttr().name()==QString("target")){
                  const char *value = logFilters.at(k).target.c_str();
                  el.setAttribute(QString("target"),QString(value));
              }
              if(attribute.toAttr().name()==QString("component")){
                  const char *value = logFilters.at(k).component.c_str();
                  el.setAttribute(QString("component"),QString(value));
              }
              if(attribute.toAttr().name()==QString("switch")){
                  const char *value = logFilters.at(k)._switch.c_str();
                  el.setAttribute(QString("switch"),QString(value));
              }
              if(attribute.toAttr().name()==QString("rank")){
                  const char *value = logFilters.at(k).rank.c_str();
                  el.setAttribute(QString("rank"),QString(value));
              }
          }
      }
    }
}
