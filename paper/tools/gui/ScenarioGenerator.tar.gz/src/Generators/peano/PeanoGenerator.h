/*
 * PeanoGenerator.h
 *
 *  Created on: Nov 10, 2011
 *      Author: tanlin
 */

#ifndef PEANOGENERATOR_H_
#define PEANOGENERATOR_H_

#include "Generators/Generator.h"
#include "algorithms/regularpacking/RegularPacking.h"
#include "algorithms/AbstractSpherePacking.h"
#include "xml/threeD/SpherePrinter.h"
#include "vtk/Visualization.h"
#include <QtCore>
#include <QCoreApplication>
#include <QtXml>
#define nodeNumber 9
#define plotterList 7
#define fluidList 19
#define odeList 5
#define solverList 7
#define domainList 6
#define stackList 2
#define typeList 2
#define geometryList 8
#define filterList 4
#define Peano_Dimension 3
typedef struct{
  std::string name;
  std::string geometry_base_number;
  std::string invert;
  std::string r;
  std::string minimal_meshsize [3];
  std::string maximal_meshsize [3];
  std::string offset [3];
  std::string bounding_box[3];
}Geometry;
typedef struct{
  std::string target;
  std::string component;
  std::string _switch;
  std::string rank;
}LogFilter;
//enum type{geometrySphere,geometryHexahedron,geometryBox}

class Parameter;
class PeanoGenerator:public Generator {
public:
  PeanoGenerator();
  virtual ~PeanoGenerator();
  /**
   * Sets a new parameter and adds it to the list
   */
  virtual void setParameter(Parameter* p);

  /**
   * Generates DrawableMolecules and saves them in the list
   */
  virtual void generatePreview();
  /*
     * load generator without instantiate it
     */
  void createSampleObject() const;
  /**
   * Validates if parameters are ok
   */
  virtual bool validateParameters();

  /**
   * Creates the parameters and returns them
   */
  virtual vector<ParameterCollection*> getParameters();
  virtual void load(const std::string& filename);
  virtual void save(const std::string& filename);
  void generateOutput(const std::string& directory);
//  void getChild(std::vector <QDomElement> &Nodes,QDomElement &e);
//  void getAttribute(QDomElement &e);
  void initialConfiguration();
  void writeConfiguration();
private:
//  std::vector <QDomElement> Nodes;
  static std::string nodeNames [nodeNumber];
  double _distance;
  double _radius;
  bool _spheresP1;
  bool _spheresP2;
  bool _vtk;
  bool _mg;
  QDomDocument _doc;
  algorithms::regularpacking::RegularPacking SpherePacking;
  //attributes relate to plotter
  std::string plotterInformation[plotterList];
  static std::string plotterNames [plotterList];
  //attributes relate to fluid
  std::string fluidInformation[fluidList];
  static std::string fluidNames [fluidList];
  //attributes relate to ode
  std::string odeInformation[odeList];
  static std::string odeNames [odeList];
  //attributes relate to solver
  std::string solverInformation[solverList];
  static std::string solverNames [solverList];
  //attributes relate to domain
  std::string domainInformation[domainList];
  static std::string domainNames [domainList];
  //attributes relate to stack
  std::string stackInformation[stackList];
  static std::string stackNames [stackList];
  //attributes relate to experiment-name
  std::string experiment_name;
  //attributes relate to geometry
  std::vector<Geometry> geometrys;
//  static std::string geometryNames [geometryList];
  int _sizes;
  static std::string typeNames [typeList];
  Geometry newSphere;
  Geometry oldSphere;
  //attributes relate to logFilter
  std::vector<LogFilter> logFilters;
  LogFilter newLogFilter;
  LogFilter oldLogFilter;
  int _sizelogFilters;
//  static std::string logfilterNames [filterList];
};
std::string PeanoGenerator::nodeNames [nodeNumber]={"solver","ode","fluid","plotter","domain","stack","experiment-name","geometry","log-filter"};

std::string PeanoGenerator::plotterNames [plotterList]={"name","path","filename",
    "use-standard-file-name-extension","use-binary-format","plot-leaves-only","plot-vertex-type"};

std::string PeanoGenerator::fluidNames [fluidList]={"name","velocity-mean-value",
    "initiate-velocity-everywhere","velocity-profile","inlet-pressure","outlet-pressure","inlet-dimension-x0",
    "inlet-dimension-x1","inlet-dimension-x2","inlet-offset-x0","inlet-offset-x1","inlet-offset-x2",
    "characteristic-length","Re","eta","rho","adjustment-factor","use-divergence-correction","element-type"};

std::string PeanoGenerator::odeNames [odeList]={"solver","start-time","end-time",
    "number-of-time-steps","print-delta"};

std::string PeanoGenerator::solverNames [solverList]={"name","type","max-iterations",
    "preconditioner","relative-tolerance","absolute-tolerance","divergence-tolerance"};

std::string PeanoGenerator::domainNames [domainList]={"x0","x1","x2",
    "h0","h1","h2"};

std::string PeanoGenerator::stackNames [stackList]={"block-size","name"};
std::string PeanoGenerator::typeNames [typeList]={"sphere","hexahedron"};
//std::string PeanoGenerator::logfilterNames [filterList]={"target","component","switch","rank"};
#endif /* PEANOGENERATOR_H_ */
