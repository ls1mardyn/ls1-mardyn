/*
 * StandardRandomSpherePackingGenerator.cpp
 *
 *  Created on: Jul 10, 2011
 *      Author: tanlin
 */

#include "StandardRandomSpherePackingGenerator.h"
#include "StandardRandomSpherePackingObject.h"
#include "QObjects/ScenarioGenerator.h"
#include "Parameters/ParameterWithDoubleValue.h"
#include "Parameters/ParameterWithIntValue.h"
#include "Parameters/ParameterWithBool.h"
#include "time.h"
extern "C" {

  Generator* create_generator() {
    return new StandardRandomSpherePackingGenerator();
  }

  void destruct_generator(Generator* generator) {
    delete generator;
  }
}
StandardRandomSpherePackingGenerator::StandardRandomSpherePackingGenerator()  : Generator("StandardRandomSpherePackingGenerator"){
  _eventspercycle=40;
  _N=20;
  _initialpf=0.001;
  _maxpf = 0.8;
  _temp = 0.2;
  _maxpressure =100;
  _growthrate = 0.01;
  _spheresP1=false;
  _spheresP2=false;
  _vtk=false;
  _mg=false;
}

StandardRandomSpherePackingGenerator::~StandardRandomSpherePackingGenerator() {
  // TODO Auto-generated destructor stub
}


void StandardRandomSpherePackingGenerator::setParameter(Parameter* p) {
  std::cout << "SetParameter for param" << p->getNameId() << endl;
  std::string id = p->getNameId();

  if (id == "eventspercycle") {
      std::cout << "Setting eventspercycle!" << std::endl;
      _eventspercycle = static_cast<ParameterWithIntValue*>(p)->getValue();
  }
  else if (id == "N") {
      std::cout << "Setting N!" << std::endl;
      _N = static_cast<ParameterWithIntValue*>(p)->getValue();
  }
  else if (id == "initialpf") {
      std::cout << "Setting initialpf!" << std::endl;
      _initialpf = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "maxpf") {
      std::cout << "Setting maxpf!" << std::endl;
      _maxpf = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "temp") {
      std::cout << "Setting temp!" << std::endl;
      _temp = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "maxpressure") {
      std::cout << "Setting maxpressure!" << std::endl;
      _maxpressure = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "growthrate") {
      std::cout << "Setting growthrate!" << std::endl;
      _growthrate = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "spheresP1") {
      std::cout << "Setting output spheresP1!" <<std::endl;
      _spheresP1 = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output spheresP1: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "spheresP2") {
      std::cout << "Setting output spheresP2!" <<std::endl;
      _spheresP2 = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output spheresP2: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "vtk") {
      std::cout << "Setting output vtk!" <<std::endl;
      _vtk = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output vtk: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "MG") {
      std::cout << "Setting output MG!" <<std::endl;
      _mg = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output MG: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  std::cout << "Parameter value is set!" << endl;
}

bool StandardRandomSpherePackingGenerator::validateParameters() {
  bool isValid = true;

  if (_eventspercycle < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "_eventspercycle has to be greater 0!" << std::endl;
      isValid = false;
  }
  if (_N < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "_N has to be greater 0!" << std::endl;
      isValid = false;
  }

  if (_initialpf < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "initialpf has to be greater 0!" << std::endl;
      isValid = false;
  }
  if (_maxpf < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "maxpf has to be greater 0!" << std::endl;
      isValid = false;
  }
  if (_temp < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  <<"temp has to be greater 0!" << std::endl;
      isValid = false;
  }
  if (_maxpressure < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "maxpressure has to be greater 0!"<< std::endl;
      isValid = false;
  }
  if (_growthrate < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "growthrate has to be greater 0!" << std::endl;
      isValid = false;
  }
  return isValid;
}

vector<ParameterCollection*> StandardRandomSpherePackingGenerator::getParameters() {
  vector<ParameterCollection*> parameters;
  ParameterCollection* tab = new ParameterCollection("RandomSpherePackingCollection", "RandomSpherePackingCollection",
      "RandomSpherePackingCollection", Parameter::BUTTON);
  parameters.push_back(tab);
  tab->addParameter(
      new ParameterWithIntValue("eventspercycle",
          "magnitude of eventspercycle", "events per sphere per cycle ",
          Parameter::LINE_EDIT,  false, _eventspercycle));

  tab->addParameter(
      new ParameterWithIntValue("N",
          "magnitude of N", "N spheres ",
          Parameter::LINE_EDIT,  false, _N));

  tab->addParameter(
      new ParameterWithDoubleValue("initialpf",
          "magnitude of initialpf", "initial packing fraction", Parameter::LINE_EDIT,
          false, _initialpf));

  tab->addParameter(
      new ParameterWithDoubleValue("maxpf",
          "magnitude of maxpf", "max pressure", Parameter::LINE_EDIT,
          false, _maxpf));

  tab->addParameter(
      new ParameterWithDoubleValue("temp",
          "magnitude of temp", "initial temper  use 0 for zero velocities", Parameter::LINE_EDIT,
          false, _temp));

  tab->addParameter(
      new ParameterWithDoubleValue("maxpressure",
          "magnitude of maxpressure", "max pressure", Parameter::LINE_EDIT,
          false, _maxpressure));

  tab->addParameter(
      new ParameterWithDoubleValue("growthrate",
          "magnitude of growthrate", "initial growth rate", Parameter::LINE_EDIT,
          false, _growthrate));
  ParameterCollection* output  = new ParameterCollection("Output", "Output",
        "Output", Parameter::BUTTON);
    output->addParameter(new ParameterWithBool("spheresP1", "spheresP1",
        "Output the spheresP1" , Parameter::CHECKBOX, false, false));
    output->addParameter(new ParameterWithBool("spheresP2", "spheresP2",
        "Output the spheresP2" , Parameter::CHECKBOX, false, false));
    output->addParameter(new ParameterWithBool("vtk", "vtk",
        "Output the vtk" , Parameter::CHECKBOX, false, false));
    output->addParameter(new ParameterWithBool("MG", "MG",
            "Output the MG_let file" , Parameter::CHECKBOX, false, false));
    parameters.push_back(output);
  return parameters;
}

void StandardRandomSpherePackingGenerator::generatePreview() {

  if(validateParameters()){
      generateConfiguration();
      SpherePacking=algorithms::ls::RandomPacking("Configuration");
      SpherePacking.setNumberOfSpheres(_N);
      clock_t start,end;
      start=clock();
      SpherePacking.generate();
      end=clock();;
      double time=(double)(end-start)/CLOCKS_PER_SEC;
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                        << "time to generate the spheres are "<< time<<" s" << std::endl;
      double numObjects=SpherePacking._spheres.size();
      double x,y,z,r;
      int id=0;
      for (int i = 0; i < numObjects; i++) {
          x=SpherePacking._spheres[i].getPositionX();
          y=SpherePacking._spheres[i].getPositionY();
          z=SpherePacking._spheres[i].getPositionZ();
          r=SpherePacking._spheres[i].getRadius();
          ScenarioGeneratorApplication::getInstance()->addObject(
              new StandardRandomSpherePackingObject(x, y, z, r,id));
          id++;
      }
  }
}
void StandardRandomSpherePackingGenerator::generateConfiguration() {
  std::ofstream output("Configuration");
  output << "int eventspercycle = "<< _eventspercycle << std::endl;
  output << "int N = "<< _N << std::endl;
  output << "double initialpf = "<< _initialpf << std::endl;
  output << "double maxpf = "<< _maxpf << std::endl;
  output << "double temp = "<< _temp << std::endl;
  output << "double growthrate = "<< _growthrate << std::endl;
  output << "double maxpressure = "<< _maxpressure << std::endl;
  output << "char* readfile = "<<"new" << std::endl;
  output << "char* writefile = "<< "write.txt" << std::endl;
  output << "char* datafile = "<< "stats.txt" << std::endl;
  output.close();
}

void StandardRandomSpherePackingGenerator::generateOutput(const std::string& directory){
  if(directory!=""){
      xml::threeD::SpherePrinter output;
      if(_spheresP1){
          string spheresP1 = directory + "/spheresP1.xml";
          output.printP1Spherepack(SpherePacking,"1/3","1/27",spheresP1);
      }
      if(_spheresP2){
          string spheresP2 = directory + "/spheresP2.xml";
          output.printP2Spherepack(SpherePacking,spheresP2);
      }
      if(_vtk){
          string spherevtk = directory + "/sphere_poly.vtp";
          string domain = directory + "/domain.vtp";
          vtk:: Visualization vtk(&SpherePacking);
          vtk.generateSphere(spherevtk,domain);
      }
      if(_mg){
          string MG = directory + "/MG-Let.txt";
          output.printMGSpherepack(SpherePacking,MG);
      }
  }
}
void StandardRandomSpherePackingGenerator::createSampleObject() const {
  ScenarioGeneratorApplication::getInstance()->addObject(
      new StandardRandomSpherePackingObject(0,0,0,0.2,1));
}
