/*
 * RandomSpherePackingGenerator.cpp
 *
 *  Created on: Jul 10, 2011
 *      Author: tanlin
 */

#include "RandomSpherePackingGenerator.h"
#include "RandomSpherePackingObject.h"
#include "QObjects/ScenarioGenerator.h"
#include "Parameters/ParameterWithDoubleValue.h"
#include "Parameters/ParameterWithIntValue.h"
#include "Parameters/ParameterWithBool.h"
#include "algorithms/NormalDistribution.h"
#include <vector>
#include <cstdlib>
#include <ctime>
extern "C" {

  Generator* create_generator() {
    return new RandomSpherePackingGenerator();
  }

  void destruct_generator(Generator* generator) {
    delete generator;
  }
}
RandomSpherePackingGenerator::RandomSpherePackingGenerator()  : Generator("RandomSpherePackingGenerator"){
  _eventspercycle=40;
  _N=6;
  _initialpf=0.001;
  _maxpf = 0.8;
  _temp = 0.2;
  _maxpressure =100;
  _various_radius =0.5;
  _growthrate = 0.01;
  _spheresP1=false;
  _spheresP2=false;
  _vtk=false;
  _mg=false;
  _ghost=false;
  _gaussianDIstribution=false;
}

RandomSpherePackingGenerator::~RandomSpherePackingGenerator() {
  // TODO Auto-generated destructor stub
}


void RandomSpherePackingGenerator::setParameter(Parameter* p) {
  std::cout << "SetParameter for param" << p->getNameId() << endl;
  std::string id = p->getNameId();

  if (id == "eventspercycle") {
      std::cout << "Setting eventspercycle!" << std::endl;
      _eventspercycle = static_cast<ParameterWithIntValue*>(p)->getValue();
  }
  else if (id == "N") {
      std::cout << "Setting N!" << std::endl;
      _N = static_cast<ParameterWithIntValue*>(p)->getValue();
  }
  else if (id == "initialpf") {
      std::cout << "Setting initialpf!" << std::endl;
      _initialpf = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "maxpf") {
      std::cout << "Setting maxpf!" << std::endl;
      _maxpf = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "temp") {
      std::cout << "Setting temp!" << std::endl;
      _temp = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "maxpressure") {
      std::cout << "Setting maxpressure!" << std::endl;
      _maxpressure = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "growthrate") {
      std::cout << "Setting growthrate!" << std::endl;
      _growthrate = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "various_radius") {
      std::cout << "Setting various!" << std::endl;
      _various_radius = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "GhostSphere") {
        std::cout << "Setting output GhostSphere!" <<std::endl;
        _ghost = static_cast<ParameterWithBool*> (p)->getValue();
        std::cout<<"Setting output GhostSphere: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
    }
  else if (id == "spheresP1") {
      std::cout << "Setting output spheresP1!" <<std::endl;
      _spheresP1 = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output spheresP1: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "spheresP2") {
      std::cout << "Setting output spheresP2!" <<std::endl;
      _spheresP2 = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output spheresP2: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "vtk") {
      std::cout << "Setting output vtk!" <<std::endl;
      _vtk = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output vtk: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "MG") {
      std::cout << "Setting output MG!" <<std::endl;
      _mg = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output MG: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "GaussianDIstribution") {
      std::cout << "Setting distribution !" <<std::endl;
      _gaussianDIstribution = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting  distribution: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  std::cout << "Parameter value is set!" << endl;
}

bool RandomSpherePackingGenerator::validateParameters() {
  bool isValid = true;

  if (_eventspercycle < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "_eventspercycle has to be greater 0!"<< std::endl;
      isValid = false;
  }
  if (_N < 1.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "_N has to be greater 3!" << std::endl;
      isValid = false;
  }

  if (_initialpf < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "initialpf has to be greater 0!" << std::endl;
      isValid = false;
  }
  if (_maxpf < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "maxpf has to be greater 0!"  << std::endl;
      isValid = false;
  }
  if (_temp < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "temp has to be greater 0!" << std::endl;
      isValid = false;
  }
  if (_maxpressure < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "maxpressure has to be greater 0!" << std::endl;
      isValid = false;
  }
  if (_growthrate < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "growthrate has to be greater 0!" << std::endl;
      isValid = false;
  }
  if (_various_radius < 0.0||_various_radius>1.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "various has to be greater 0 and smaller than 1!" << std::endl;
      isValid = false;
  }
  return isValid;
}

vector<ParameterCollection*> RandomSpherePackingGenerator::getParameters() {
  vector<ParameterCollection*> parameters;
  ParameterCollection* tab = new ParameterCollection("RandomSpherePackingCollection", "RandomSpherePackingCollection",
      "RandomSpherePackingCollection", Parameter::BUTTON);
  parameters.push_back(tab);
  tab->addParameter(
      new ParameterWithIntValue("eventspercycle",
          "magnitude of eventspercycle", "events per sphere per cycle ",
          Parameter::LINE_EDIT,  false, _eventspercycle));

  tab->addParameter(
      new ParameterWithIntValue("N",
          "magnitude of N", "N spheres ",
          Parameter::LINE_EDIT,  false, _N));

  tab->addParameter(
      new ParameterWithDoubleValue("initialpf",
          "magnitude of initialpf", "initial packing fraction", Parameter::LINE_EDIT,
          false, _initialpf));

  tab->addParameter(
      new ParameterWithDoubleValue("maxpf",
          "magnitude of maxpf", "max pressure", Parameter::LINE_EDIT,
          false, _maxpf));

  tab->addParameter(
      new ParameterWithDoubleValue("temp",
          "magnitude of temp", "initial temper  use 0 for zero velocities", Parameter::LINE_EDIT,
          false, _temp));

  tab->addParameter(
      new ParameterWithDoubleValue("maxpressure",
          "magnitude of maxpressure", "max pressure", Parameter::LINE_EDIT,
          false, _maxpressure));

  tab->addParameter(
      new ParameterWithDoubleValue("growthrate",
          "magnitude of growthrate", "initial growth rate", Parameter::LINE_EDIT,
          false, _growthrate));

  tab->addParameter(
      new ParameterWithDoubleValue("various_radius",
          "magnitude of various_radius", "the range of spheres ",
          Parameter::LINE_EDIT,  false, _various_radius));
  tab->addParameter(new ParameterWithBool("GhostSphere", "GhostSphere",
        "Output the GhostShpere" , Parameter::CHECKBOX, false, false));
  tab->addParameter(new ParameterWithBool("GaussianDIstribution", "GaussianDIstribution",
          "GaussianDIstribution" , Parameter::CHECKBOX, false, false));
  ParameterCollection* output  = new ParameterCollection("Output", "Output",
        "Output", Parameter::BUTTON);
    output->addParameter(new ParameterWithBool("spheresP1", "spheresP1",
        "Output the spheresP1" , Parameter::CHECKBOX, false, false));
    output->addParameter(new ParameterWithBool("spheresP2", "spheresP2",
        "Output the spheresP2" , Parameter::CHECKBOX, false, false));
    output->addParameter(new ParameterWithBool("vtk", "vtk",
        "Output the vtk" , Parameter::CHECKBOX, false, false));
    output->addParameter(new ParameterWithBool("MG", "MG",
            "Output the MG_let file" , Parameter::CHECKBOX, false, false));
    parameters.push_back(output);
  return parameters;
}

void RandomSpherePackingGenerator::generatePreview() {

  if(validateParameters()){
      std::vector<double> distribution;
      if(_gaussianDIstribution){
      algorithms::NormalDistribution Norm(_N);
      Norm.generate();
      Norm.bubblesort();
      distribution=Norm._distribution;
      }
      else{
          srand((unsigned)time(0));
          double various;
          int number=_N;
          while(number>0){
              number-=1;
              various=_various_radius+(rand()/(double)RAND_MAX)*(1-_various_radius);
              distribution.push_back(various);
          }
      }
      generateConfiguration();
      _spherePacking=algorithms::ls2::RandomPacking("Configuration");
      _spherePacking.setNumberOfSpheres(_N);
      _spherePacking.setVariousOfSpheres(_various_radius);
      _spherePacking.setDistribution(distribution);
      clock_t start,end;
      start=clock();
      _spherePacking.generate();
      // todo should only be generated, when necessary - could use autopointer with if
      // where the spheres are only built when necessary
      algorithms::GhostSphere ghostSpheres(_spherePacking);
      end=clock();
      double time=(double)(end-start)/CLOCKS_PER_SEC;
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                        << "time to generate the spheres is "<< time<<" s" << std::endl;
      double numObjects=_spherePacking._spheres.size();
      double numObjectsGhost=ghostSpheres._spheres.size();
      double x,y,z,r;
      int id=numObjects;
      double rmax=0;
      double rmin=1;
      for (int i = 0; i < numObjects; i++) {
          x=_spherePacking._spheres[i].getPositionX();
          y=_spherePacking._spheres[i].getPositionY();
          z=_spherePacking._spheres[i].getPositionZ();
          r=_spherePacking._spheres[i].getRadius();
          if (r>=rmax) rmax=r;
          if (r<=rmin) rmin=r;
          ScenarioGeneratorApplication::getInstance()->addObject(
              new RandomSpherePackingObject(x, y, z, r,id));
//          id++;
      }
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                        << "The radius of largest sphere is " <<rmax<< std::endl;
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                              << "The radius of smallest sphere is " <<rmin<< std::endl;

      if(_ghost){
        //todo not nice (privacy)
        ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                << "sphere packing - size before: " <<_spherePacking._spheres.size() << std::endl;
        ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                << "ghost packing - size        : " <<ghostSpheres._spheres.size() << std::endl;
        _spherePacking._spheres = ghostSpheres._spheres;
        ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                << "sphere packing - size after : " <<_spherePacking._spheres.size() << std::endl;
        id=numObjectsGhost;
        for (int i = numObjects; i < numObjectsGhost; i++) {
          x=ghostSpheres._spheres[i].getPositionX();
          y=ghostSpheres._spheres[i].getPositionY();
          z=ghostSpheres._spheres[i].getPositionZ();
          r=ghostSpheres._spheres[i].getRadius();
          ScenarioGeneratorApplication::getInstance()->addObject(
              new RandomSpherePackingObject(x, y, z, r,id));
          //          id++;
        }
      }
  }
}
void RandomSpherePackingGenerator::generateConfiguration() {
  std::ofstream output("Configuration");
  output << "int eventspercycle = "<< _eventspercycle << std::endl;
  output << "int N = "<< _N << std::endl;
  output << "double initialpf = "<< _initialpf << std::endl;
  output << "double maxpf = "<< _maxpf << std::endl;
  output << "double temp = "<< _temp << std::endl;
  output << "double growthrate = "<< _growthrate << std::endl;
  output << "double maxpressure = "<< _maxpressure << std::endl;
  output << "double various_radius = "<< _various_radius << std::endl;
  output << "char* readfile = "<<"new" << std::endl;
  output << "char* writefile = "<< "write.txt" << std::endl;
  output << "char* datafile = "<< "stats.txt" << std::endl;
  output.close();
}

void RandomSpherePackingGenerator::generateOutput(const std::string& directory){
  if(directory!=""){
      xml::threeD::SpherePrinter output;
      if(_spheresP1){
          string spheresP1 = directory + "/spheresP1.xml";
          output.printP1Spherepack(_spherePacking,"1/3","1/27",spheresP1);
      }
      if(_spheresP2){
          string spheresP2 = directory + "/spheresP2.xml";
          output.printP2Spherepack(_spherePacking,spheresP2);
      }
      if(_mg){
          string MG = directory + "/MG-Let.txt";
          output.printMGSpherepack(_spherePacking,MG);
      }
      if(_vtk){
          string spherevtk = directory + "/sphere_poly.vtp";
          string domain = directory + "/domain.vtp";
          vtk:: Visualization vtk(&_spherePacking);
          vtk.generateSphere(spherevtk,domain);
      }
  }
}
void RandomSpherePackingGenerator::createSampleObject() const {
  ScenarioGeneratorApplication::getInstance()->addObject(
      new RandomSpherePackingObject(0,0,0,0.2,1));
}
