/*
 * ChannelObject.h
 *
 *  Created on: Dec 13, 2011
 *      Author: tanlin
 */

#ifndef CHANNELOBJECT_H_
#define CHANNELOBJECT_H_

#include "Objects/Object.h"
#include <iostream>
#include <vector>
#include <iostream>
#include "algorithms/geometries/Channel.h"
#include "tarch/la/Vector.h"


class ChannelObject: public Object, public algorithms::geometries::Channel {
public:
        ChannelObject(
            double x,
            double y,
            double angle,
            double length,
            double width,
            unsigned long id);

        ChannelObject(
            const algorithms::geometries::Channel& channel,
            unsigned long id);

        virtual ~ChannelObject();

        virtual vtkSmartPointer<vtkActor> draw(int);

        vtkSmartPointer<vtkActor> drawChannel(bool color);

        virtual vtkSmartPointer<vtkActor> drawVectors();

        virtual vtkSmartPointer<vtkActor> draw(string valueName);

        virtual std::vector<std::string> getDrawableValues() const;

        float* convFloatToRGB(float ratio);

        /**
         * Return Id of this channel
         */
        inline const unsigned long & getId() const {
          return _id;
        }

private:
        /**
         * ID of the graphical object Channel
         */
        unsigned long _id;
};
#endif /* CHANNELOBJECT_H_ */
