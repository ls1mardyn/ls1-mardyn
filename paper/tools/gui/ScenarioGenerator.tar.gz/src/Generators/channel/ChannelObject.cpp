/*
 * ChannelObject.cpp
 *
 *  Created on: Dec 13, 2011
 *      Author: tanlin, Michael Lieb
 */

#include "ChannelObject.h"
#include <vtkQuad.h>
#include <vtkUnstructuredGrid.h>
#include <vtkDataSetMapper.h>
#include <cmath>

ChannelObject::ChannelObject(double x, double y, double angle, double length,double width, unsigned long id) :
algorithms::geometries::Channel(length,width,x,y,angle),_id(id) {
}


ChannelObject::ChannelObject(
    const algorithms::geometries::Channel& channel,
    const unsigned long id):
    algorithms::geometries::Channel(channel),
    _id(id){

}

ChannelObject::~ChannelObject() {
  // TODO Auto-generated destructor stub
}


vtkSmartPointer<vtkActor> ChannelObject::ChannelObject::draw(int numMols) {
  return drawChannel( true );
}

std::vector<std::string> ChannelObject::getDrawableValues()const{
  std::vector<std::string> v;
  v.push_back("Channel");
  v.push_back("Channel ID");
  return v;
}

vtkSmartPointer<vtkActor> ChannelObject::draw(string valueName) {
      return drawChannel( true);
  }

vtkSmartPointer<vtkActor> ChannelObject::drawVectors() {
        std::cout <<"ERROR call of unsupported function! DummyObject::drawVectors(); No vectors to draw";
        exit(-1);
        return NULL;
}

vtkSmartPointer<vtkActor> ChannelObject::drawChannel(
    bool color) {
  double initialx=getCenterPositionX()-getLength()/2;
  double initialy=getCenterPositionY()-getWidth()/2;

  tarch::la::Vector<2,double> firstpoint;
  firstpoint(0)=initialx;
  firstpoint(1)=initialy;
  rotatePoint(firstpoint,_sinOrientation,_cosOrientation,getCenterPositionX(),getCenterPositionY());
  tarch::la::Vector<2,double> secondpoint;
  secondpoint(0)=initialx+getLength();
  secondpoint(1)=initialy;
  rotatePoint(secondpoint,_sinOrientation,_cosOrientation,getCenterPositionX(),getCenterPositionY());
  tarch::la::Vector<2,double> thirdpoint;
  thirdpoint(0)=initialx+getLength();
  thirdpoint(1)=initialy+getWidth();
  rotatePoint(thirdpoint,_sinOrientation,_cosOrientation,getCenterPositionX(),getCenterPositionY());
  tarch::la::Vector<2,double> fourthpoint;
  fourthpoint(0)=initialx;
  fourthpoint(1)=initialy+getWidth();
  rotatePoint(fourthpoint,_sinOrientation,_cosOrientation,getCenterPositionX(),getCenterPositionY());
  vtkSmartPointer<vtkPoints> points =
      vtkSmartPointer<vtkPoints>::New();
  points->SetNumberOfPoints(4);
  points->InsertPoint(0,firstpoint(0),firstpoint(1),0);
  points->InsertPoint(1,secondpoint(0),secondpoint(1),0);
  points->InsertPoint(2,thirdpoint(0),thirdpoint(1),0);
  points->InsertPoint(3,fourthpoint(0),fourthpoint(1),0);

  vtkSmartPointer<vtkQuad> Quad =
      vtkSmartPointer<vtkQuad>::New();
  Quad->GetPointIds()->SetId(0,0);
  Quad->GetPointIds()->SetId(1,1);
  Quad->GetPointIds()->SetId(2,2);
  Quad->GetPointIds()->SetId(3,3);

  vtkSmartPointer<vtkUnstructuredGrid> polyData =
      vtkSmartPointer<vtkUnstructuredGrid>::New();
  polyData->SetPoints(points);
  polyData->Allocate(1,1);
  polyData->InsertNextCell(Quad->GetCellType(),Quad->GetPointIds());

  vtkSmartPointer<vtkDataSetMapper> mapper =
      vtkSmartPointer<vtkDataSetMapper>::New();
  mapper->SetInput(polyData);
  vtkSmartPointer<vtkActor> actor =
      vtkSmartPointer<vtkActor>::New();
  actor->SetMapper(mapper);
  actor->GetProperty()->SetColor(1, 0, 0);
  return actor;
}

float* ChannelObject::convFloatToRGB(float ratio) {
  float* rgb = new float[3];
  //rgb.resize(3);
  if (ratio <= 0.25) {
      rgb[2] = 1;
      rgb[1] = 2 * ratio;
      rgb[0] = ratio;
  } else if (ratio <= 0.5) {
      rgb[2] = -2 * ratio + 1.5;
      rgb[1] = 2 * ratio;
      rgb[0] = ratio;
  } else if (ratio <= 0.75) {
      rgb[2] = 1 - ratio;
      rgb[1] = -2 * ratio + 2;
      rgb[0] = 2 * ratio - 0.5;
  } else if (ratio <= 1) {
      rgb[2] = 1 - ratio;
      rgb[1] = -2 * ratio + 2;
      rgb[0] = 1;
  }

  return rgb;
}

