/*
 * ChannelGenerator.cpp
 *
 *  Created on: Dec 13, 2011
 *      Author: tanlin, Michael Lieb
 */

#include "ChannelGenerator.h"

#include "Parameters/ParameterWithIntValue.h"
#include "Parameters/ParameterWithDoubleValue.h"
#include "Parameters/ParameterWithBool.h"
#include "QObjects/ScenarioGenerator.h"
#include "ChannelObject.h"
#include <ctime>
#include <iostream>
#include "xml/twoD/ChannelPrinter.h"
#include "algorithms/channels/FractureNetworkGenerator.h"
#include "Convertor.h"
#include "algorithms/CalculationBasics.h"

extern "C" {

  Generator* create_generator() {
    return new ChannelGenerator();
  }

  void destruct_generator(Generator* generator) {
    delete generator;
  }
}


ChannelGenerator::ChannelGenerator() : Generator("ChannelGenerator"){
  _numObjects = 4;
  _length=0.5;
  _width=0.02;
  _orientation_maximal=algorithms::CalculationBasics::toRadiant(45);
  _orientation_minimal=algorithms::CalculationBasics::toRadiant(45);
  setSubDomains(0);
}

ChannelGenerator::~ChannelGenerator() {
}


void ChannelGenerator::setParameter(Parameter* p) {
  std::cout << "SetParameter for param" << p->getNameId() << endl;
  std::string id = p->getNameId();

  if (id == "numObjects") {
    std::cout << "Setting numObjects!" << std::endl;
    _numObjects = static_cast<ParameterWithIntValue*>(p)->getValue();
  }
  else if (id == "length") {
    std::cout << "Setting length!" << std::endl;
    _length = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "width") {
    std::cout << "Setting width!" << std::endl;
    _width = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "orientation_minimal") {
    _orientation_minimal =
        algorithms::CalculationBasics::toRadiant(static_cast<ParameterWithDoubleValue*> (p)->getValue());
    std::cout<<"Setting orientation_minimal: "<< algorithms::CalculationBasics::toDegree(_orientation_minimal) <<endl;
  }
  else if (id == "orientation_maximal") {
    _orientation_maximal =
        algorithms::CalculationBasics::toRadiant(static_cast<ParameterWithDoubleValue*> (p)->getValue());
    std::cout<<"Setting orientation_maximal: "<< algorithms::CalculationBasics::toDegree(_orientation_maximal) <<endl;
  }
  else if (id == "subdivPerDim") {
    setSubDomains(static_cast<ParameterWithIntValue*> (p)->getValue());
    std::cout<<"Setting _subDivPerDim: "<< _subDivPerDim <<endl;
  }
  std::cout << "Parameter value is set!" << endl;
  std::cout << "Debug: #Channels in array: " <<_channels.size() <<endl;
}


bool ChannelGenerator::validateParameters() {
  bool isValid = true;

  if (_numObjects <= 0) {
    ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                  << "Number of objects has to be greater 0!" << std::endl;
    isValid = false;
  }

  if (_length < 0.0) {
    ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                          << "Object length has to be greater 0!" << std::endl;
    isValid = false;
  }
  return isValid;
}

void ChannelGenerator::generateOutput(const std::string& directory) {
  if(directory!=""){
    xml::twoD::ChannelPrinter output;
    std::stringstream fileNameWithPath;
    fileNameWithPath <<directory << "/p1-channels-" <<_numObjects <<".txt";
    //      std::string filename = directory + "/p1-channels-" +(std::string)_numObjects +"-" +(std::string)_channels.size() +".xml";

    std::vector<algorithms::geometries::Channel*> ptrToChannels = Convertor::getChannelsPtr(_channels);
    //
    //      for(int i=0; i < _channels.size(); i++) {
    //        ptrToChannels[i] = &_channels[i];
    //      }

    std::cout <<"Plotter to be activated!!!\n";
//    output.rotateAndPrintP1Channels(ptrToChannels,"1/3","1/27",fileNameWithPath.str());
//    printP1Channels();
    //      std::stringstream rotatedOutputfileNameWithPath;
    //      rotatedOutputfileNameWithPath <<directory << "/p1-channels-" <<_numObjects <<"-rotated.txt";
    //      output.rotateAndPrintP1Channels(_channels,"1/3","1/27",rotatedOutputfileNameWithPath.str());
  }
}


vector<ParameterCollection*> ChannelGenerator::getParameters() {
  vector<ParameterCollection*> parameters;
  ParameterCollection* tab = new ParameterCollection("ChannelCollection", "ChannelCollection",
      "ChannelCollection", Parameter::BUTTON);
  parameters.push_back(tab);

  tab->addParameter(
      new ParameterWithIntValue("numObjects",
          "Number of Objects", "The number of objects which is created and displayed",
          Parameter::LINE_EDIT,  false, _numObjects));

  tab->addParameter(
      new ParameterWithDoubleValue("length",
          "Object length", "The length of objects", Parameter::LINE_EDIT,
          false, _length));
  tab->addParameter(
      new ParameterWithDoubleValue("width",
          "Object width", "The width of objects", Parameter::LINE_EDIT,
          false, _width));
  tab->addParameter(
      new ParameterWithDoubleValue("orientation_minimal",
          "Object orientation_minimal", "The orientation_minimal of objects", Parameter::LINE_EDIT,
          false, algorithms::CalculationBasics::toDegree(_orientation_minimal) ));
  tab->addParameter(
      new ParameterWithDoubleValue("orientation_maximal",
          "Object orientation_maximal", "The orientation_maximal of objects", Parameter::LINE_EDIT,
          false, algorithms::CalculationBasics::toDegree(_orientation_maximal) ));

  tab->addParameter(
      new ParameterWithIntValue("subdivPerDim",
          "Subdivisions per Dim", "Subdivision per Dimension. Defines the number of regular patches.",
          Parameter::LINE_EDIT,  false, _subDivPerDim));

  return parameters;
}


// Just generate some dummy molecules...
void ChannelGenerator::generatePreview() {
  double x,y;
  clock_t start,end;
  srand((unsigned)time(NULL));
  _channels.clear();
  _channels.reserve(_numObjects);

  algorithms::channels::FractureNetworkGenerator fractureNetwork(
      _length,
      _width,
      _orientation_minimal,
      _orientation_maximal,
      _domainSizePerDirection,
      _numObjects
  );

  start=clock();

  std::list<Object*> listOfObjects =
      Convertor::generateListOfObjectPtrs(
          fractureNetwork.generateFractureNetwork()
          );
  ScenarioGeneratorApplication::getInstance()->resetListOfObjects(listOfObjects);

  end=clock();

  double time=(double)(end-start)/CLOCKS_PER_SEC;
  ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                     << "time to generate the fracture network setup was "<< time<<" s" << std::endl;
}

void ChannelGenerator::createSampleObject() const {
  ScenarioGeneratorApplication::getInstance()->addObject(
      new ChannelObject(0,0,0,0.2, 0.02, 1));
}

void ChannelGenerator::setSubDomains(const int& subdivisionPerDirection) {
  _subDivPerDim = subdivisionPerDirection;
  _domainSizePerDirection = (_subDivPerDim != 0) ? sqrt(2.0)/static_cast<double>(_subDivPerDim + 1.0) + 1.0 : 1.0;
}

