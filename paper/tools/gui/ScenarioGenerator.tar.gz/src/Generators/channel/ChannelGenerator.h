/*
 * ChannelGenerator.h
 *
 *  Created on: Dec 13, 2011
 *      Author: tanlin
 */

#ifndef CHANNELGENERATOR_H_
#define CHANNELGENERATOR_H_

#include "Generators/Generator.h"
#include "ChannelObject.h"
#include <string>
#include <vector>

class Parameter;
class ChannelGenerator:public Generator {
public:
  ChannelGenerator();
  virtual ~ChannelGenerator();
  /**
   * Sets a new parameter and adds it to the list
   */
  virtual void setParameter(Parameter* p);

  /**
   * Generates DrawableMolecules and saves them in the list
   */
  virtual void generatePreview();
  /*
     * load generator without instantiate it
     */
  void createSampleObject() const;
  /**
   * Validates if parameters are ok
   */
  virtual bool validateParameters();

  void insertRectangleInPreview(
      double posX,
      double posY,
      double length,
      double width
      );

  /**
   * Creates the parameters and returns them
   */
  virtual vector<ParameterCollection*> getParameters();

  virtual void generateOutput(const std::string& directory);
  double getInitialOrientation();

  double getInitialx();
  double getInitialy();
private:
  void setSubDomains(const int& subdivisionPerDirection);
  double _length;
  double _width;
  double _orientation_minimal;
  double _orientation_maximal;
  double _domainSizePerDirection;
  unsigned int _numObjects;
  unsigned int _subDivPerDim;
  std::vector<ChannelObject> _channels;
};
#endif /* CHANNELGENERATOR_H_ */
