/*
 * Convertor.h
 *
 *  Created on: Mar 6, 2012
 *      Author: michael
 */

#ifndef CHANNEL_CONVERTOR_H_
#define CHANNEL_CONVERTOR_H_

#include "ChannelObject.h"
#include "algorithms/geometries/Channel.h"
#include <vector>
#include <list>

class Convertor {
public:
  Convertor();

  static std::vector<algorithms::geometries::Channel*> getChannelsPtr(
      std::vector<ChannelObject>& channels
  ) {
    std::vector<algorithms::geometries::Channel*> ptrToChannels;
    ptrToChannels.reserve(channels.size());

    for(int i=0; i < channels.size(); i++) {
      ptrToChannels[i] = &channels[i];
    }
    return ptrToChannels;
  }

  static std::list<Object*> generateListOfObjectPtrs(
      std::vector<algorithms::geometries::Channel>& channels
  ) {
    std::list<Object*> ptrToObjects;

    for(unsigned long i=0; i < channels.size(); i++) {
      ptrToObjects.push_back(
          new ChannelObject(
          channels[i].getCenterPositionX(), channels[i].getCenterPositionY(),
          channels[i].getOrientation(),
          channels[i].getLength(),
          channels[i].getWidth(), i)
      );
    }
    return ptrToObjects;
  }

  virtual
  ~Convertor();
};

#endif /* CONVERTOR_H_ */
