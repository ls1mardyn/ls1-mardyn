/*
 * Convertor.cpp
 *
 *  Created on: Mar 6, 2012
 *      Author: michael
 */

#include "Convertor.h"

Convertor::Convertor() {
  // TODO Auto-generated constructor stub

}

Convertor::~Convertor() {
  // TODO Auto-generated destructor stub
}

