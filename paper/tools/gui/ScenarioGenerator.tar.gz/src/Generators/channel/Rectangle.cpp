///*
// * Rectangle.cpp
// *
// *  Created on: Mar 11, 2012
// *      Author: michael
// */
//
//#include "Rectangle.h"
//
//Rectangle::Rectangle() {
//  // TODO Auto-generated constructor stub
//
//}
//
//Rectangle::~Rectangle() {
//  // TODO Auto-generated destructor stub
//}
