/*
 * RegularSpherePackingGenerator.h
 *
 *  Created on: Jul 10, 2011
 *      Author: tanlin
 */

#ifndef REGULARSPHEREPACKINGGENERATOR_H_
#define REGULARSPHEREPACKINGGENERATOR_H_
#include "Generators/Generator.h"
#include "algorithms/regularpacking/RegularPacking.h"
#include "algorithms/AbstractSpherePacking.h"
#include "vtk/Visualization.h"

class Parameter;
class RegularSpherePackingGenerator:public Generator {
public:
  RegularSpherePackingGenerator();
  virtual ~RegularSpherePackingGenerator();
  /**
   * Sets a new parameter and adds it to the list
   */
  virtual void setParameter(Parameter* p);

  /**
   * Generates DrawableMolecules and saves them in the list
   */
  virtual void generatePreview();
  /*
     * load generator without instantiate it
     */
  void createSampleObject() const;
  /**
   * Validates if parameters are ok
   */
  virtual bool validateParameters();

  /**
   * Creates the parameters and returns them
   */
  virtual vector<ParameterCollection*> getParameters();

  void generateOutput(const std::string& directory);
private:
  double _distance;
  double _radius;
  bool _spheresP1;
  bool _spheresP2;
  bool _vtk;
  bool _mg;
  algorithms::regularpacking::RegularPacking SpherePacking;
};

#endif /* REGULARSPHEREPACKINGGENERATOR_H_ */
