/*
 * RegularSpherePackingGenerator.cpp
 *
 *  Created on: Jul 10, 2011
 *      Author: tanlin
 */

#include "RegularSpherePackingGenerator.h"
#include "RegularSpherePackingObject.h"
#include "QObjects/ScenarioGenerator.h"
#include "Parameters/ParameterWithDoubleValue.h"
#include "Parameters/ParameterWithIntValue.h"
#include "Parameters/ParameterWithBool.h"
#include "time.h"
#include "xml/threeD/SpherePrinter.h"
extern "C" {

  Generator* create_generator() {
    return new RegularSpherePackingGenerator();
  }

  void destruct_generator(Generator* generator) {
    delete generator;
  }
}
RegularSpherePackingGenerator::RegularSpherePackingGenerator()  : Generator("RegularSpherePackingGenerator"){
  _distance = 0.0;
  _radius = 0.1;
  _spheresP1=false;
  _spheresP2=false;
  _vtk=false;
  _mg=false;
}

RegularSpherePackingGenerator::~RegularSpherePackingGenerator() {
  // TODO Auto-generated destructor stub
}


void RegularSpherePackingGenerator::setParameter(Parameter* p) {
  std::cout << "SetParameter for param" << p->getNameId() << endl;
  std::string id = p->getNameId();

  if (id == "distance") {
      std::cout << "Setting distance!" << std::endl;
      _distance = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "radius") {
      std::cout << "Setting radius!" << std::endl;
      _radius = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "spheresP1") {
      std::cout << "Setting output spheresP1!" <<std::endl;
      _spheresP1 = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output spheresP1: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "spheresP2") {
      std::cout << "Setting output spheresP2!" <<std::endl;
      _spheresP2 = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output spheresP2: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "vtk") {
      std::cout << "Setting output vtk!" <<std::endl;
      _vtk = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output vtk: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "MG") {
      std::cout << "Setting output MG!" <<std::endl;
      _mg = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output MG: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  std::cout << "Parameter value is set!" << endl;
}

bool RegularSpherePackingGenerator::validateParameters() {
  bool isValid = true;

  if (_distance < 0.0||_distance>=0.5) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                << "minimal distance has to be greater 0!maximal distance has to be smaller 0.5" << std::endl;
      isValid = false;
  }
  if (_radius < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                << "radius has to be greater 0!" << std::endl;
      isValid = false;
  }
  return isValid;
}

vector<ParameterCollection*> RegularSpherePackingGenerator::getParameters() {
  vector<ParameterCollection*> parameters;
  ParameterCollection* tab = new ParameterCollection("RegularSpherePackingCollection", "RegularSpherePackingCollection",
      "RegularSpherePackingCollection", Parameter::BUTTON);
  parameters.push_back(tab);

  tab->addParameter(
      new ParameterWithDoubleValue("distance",
          "magnitude of distance", "the distance between spheres and wall ",
          Parameter::LINE_EDIT,  false, _distance));

  tab->addParameter(
      new ParameterWithDoubleValue("radius",
          "magnitude of radius", "The radius of sphere", Parameter::LINE_EDIT,
          false, _radius));
  ParameterCollection* output  = new ParameterCollection("Output", "Output",
        "Output", Parameter::BUTTON);
    output->addParameter(new ParameterWithBool("spheresP1", "spheresP1",
        "Output the spheresP1" , Parameter::CHECKBOX, false, false));
    output->addParameter(new ParameterWithBool("spheresP2", "spheresP2",
        "Output the spheresP2" , Parameter::CHECKBOX, false, false));
    output->addParameter(new ParameterWithBool("vtk", "vtk",
        "Output the vtk" , Parameter::CHECKBOX, false, false));
    output->addParameter(new ParameterWithBool("MG", "MG",
            "Output the MG_let file" , Parameter::CHECKBOX, false, false));
    parameters.push_back(output);
  return parameters;
}

void RegularSpherePackingGenerator::generatePreview() {
  if(validateParameters()){
      clock_t start,end;
      start=clock();
      SpherePacking=algorithms::regularpacking::RegularPacking(1.0,_radius,_distance);
      end=clock();;
      double time=(double)(end-start)/CLOCKS_PER_SEC;
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                 << "time to generate the spheres are "<< time<<" s" << std::endl;
      int id=0;
      for (int i = 0; i < (int)SpherePacking._spheres.size(); i++) {
          ScenarioGeneratorApplication::getInstance()->addObject(
              new RegularSpherePackingObject(
                  SpherePacking._spheres[i].getPositionX(),
                  SpherePacking._spheres[i].getPositionY(),
                  SpherePacking._spheres[i].getPositionZ(),
                  _radius,id));
          id++;
      }
  }
}
void RegularSpherePackingGenerator::generateOutput(const std::string& directory){
  if(directory!=""){
      xml::threeD::SpherePrinter output;
      if(_spheresP1){
          string spheresP1 = directory + "/spheresP1.xml";
          output.printP1Spherepack(SpherePacking,"1/3","1/27",spheresP1);
      }
      if(_spheresP2){
          string spheresP2 = directory + "/spheresP2.xml";
          output.printP2Spherepack(SpherePacking,spheresP2);
      }
      if(_vtk){
          string spherevtk = directory + "/sphere_poly.vtp";
          string domain = directory + "/domain.vtp";
          vtk:: Visualization vtk(&SpherePacking);
          vtk.generateSphere(spherevtk,domain);
      }
      if(_mg){
          string MG = directory + "/MG-Let.txt";
          output.printMGSpherepack(SpherePacking,MG);
      }
  }
}
void RegularSpherePackingGenerator::createSampleObject() const {
  ScenarioGeneratorApplication::getInstance()->addObject(
      new RegularSpherePackingObject(0,0,0,0.2,1));
}
