/*
 * RegularSpherePackingObject.h
 *
 *  Created on: Jul 10, 2011
 *      Author: tanlin
 */

#ifndef REGULARSPHEREPACKINGOBJECT_H_
#define REGULARSPHEREPACKINGOBJECT_H_
#include "Objects/Object.h"
#include <iostream>

class RegularSpherePackingObject: public Object {
public:
	RegularSpherePackingObject(double x0, double x1, double x2, double radius, unsigned long id);
	virtual ~RegularSpherePackingObject();
	virtual vtkSmartPointer<vtkActor> draw(int);
	vtkSmartPointer<vtkActor> drawValue(Position& position, double value,
				double minValue, double maxValue,bool color);

	virtual vtkSmartPointer<vtkActor> drawVectors() {
                std::cout <<"ERROR call of unsupported function! DummyObject::drawVectors(); No vectors to draw";
                exit(-1);
                return NULL;
        }
	virtual vtkSmartPointer<vtkActor> draw(string valueName);
        virtual std::vector<std::string> getDrawableValues() const;

	float* convFloatToRGB(float ratio);
private:
	Position _position;
	double _radius;
	int _id;
};

#endif /* REGULARSPHEREPACKINGOBJECT_H_ */
