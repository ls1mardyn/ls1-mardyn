/*
 * RegularSpherePackingObject.cpp
 *
 *  Created on: Jul 10, 2011
 *      Author: tanlin
 */

#include "RegularSpherePackingObject.h"

RegularSpherePackingObject::RegularSpherePackingObject(double x0, double x1, double x2, double radius,unsigned long id) :
_position(x0, x1, x2), _radius(radius),_id(id) {

}

RegularSpherePackingObject::~RegularSpherePackingObject() {
  // TODO Auto-generated destructor stub
}


vtkSmartPointer<vtkActor> RegularSpherePackingObject::draw(int numMols) {
  return drawValue(_position, _id, 0, numMols, true);
}

std::vector<std::string> RegularSpherePackingObject::getDrawableValues()const{
  std::vector<std::string> v;
  v.push_back("Spheres");
  v.push_back("Sphere ID");
  return v;
}

vtkSmartPointer<vtkActor> RegularSpherePackingObject::draw(string valueName) {
  if (valueName == "Spheres"){
      return drawValue(_position, _id, 0, _numObjects, false);
  } else if (valueName == "Sphere ID"){
      return drawValue(_position, _id, 0, _numObjects, true);
  }
}


vtkSmartPointer<vtkActor> RegularSpherePackingObject::drawValue(Position& position, double value,
    double minValue, double maxValue,bool color) {

  vtkSmartPointer<vtkSphereSource> sphereSource = vtkSmartPointer<
      vtkSphereSource>::New();
  sphereSource->SetCenter(position.x, position.y, position.z);
  sphereSource->SetRadius(_radius);

  vtkSmartPointer<vtkPolyDataMapper> mapper = vtkSmartPointer<
      vtkPolyDataMapper>::New();

  mapper->SetInput(sphereSource->GetOutput());

  vtkSmartPointer<vtkActor> actor = vtkSmartPointer<vtkActor>::New();

  actor->SetMapper(mapper);

  // project the value from its original range to the interval [0;1]
  float* ptr;
  if (color){
      ptr = convFloatToRGB((value - minValue)*1.0 / (maxValue - minValue));
  }
  else {
      ptr = new float[3];
      ptr[0] = ptr[1] =  0;
      ptr[2] =255;
  }
  actor->GetProperty()->SetColor(ptr[0],  ptr[1],  ptr[2]);
  return actor;
}

float* RegularSpherePackingObject::convFloatToRGB(float ratio) {
  float* rgb = new float[3];
  //rgb.resize(3);
  if (ratio <= 0.25) {
      rgb[2] = 1;
      rgb[1] = 2 * ratio;
      rgb[0] = ratio;
  } else if (ratio <= 0.5) {
      rgb[2] = -2 * ratio + 1.5;
      rgb[1] = 2 * ratio;
      rgb[0] = ratio;
  } else if (ratio <= 0.75) {
      rgb[2] = 1 - ratio;
      rgb[1] = -2 * ratio + 2;
      rgb[0] = 2 * ratio - 0.5;
  } else if (ratio <= 1) {
      rgb[2] = 1 - ratio;
      rgb[1] = -2 * ratio + 2;
      rgb[0] = 1;
  }

  return rgb;
}
