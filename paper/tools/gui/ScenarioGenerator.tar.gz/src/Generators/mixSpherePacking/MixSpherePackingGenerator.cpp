/*
 * MixSpherePackingGenerator.cpp
 *
 *  Created on: Jul 10, 2011
 *      Author: tanlin
 */

#include "MixSpherePackingGenerator.h"
#include "MixSpherePackingObject.h"
#include "QObjects/ScenarioGenerator.h"
#include "Parameters/ParameterWithDoubleValue.h"
#include "Parameters/ParameterWithIntValue.h"
#include "Parameters/ParameterWithBool.h"
#include "time.h"
#include <string>
extern "C" {

  Generator* create_generator() {
    return new MixSpherePackingGenerator();
  }

  void destruct_generator(Generator* generator) {
    delete generator;
  }
}
MixSpherePackingGenerator::MixSpherePackingGenerator()  : Generator("MixSpherePackingGenerator"){
  _numLayers=3;
  _distance = 0.0;
  _xlength = 1.0;
  _ylength = 1.0;
  _zlength = 1.0;
  _radius = new double[_numLayers];
  _percent  = new double[_numLayers];
  _density  = new double[_numLayers];
  _radius[0] = 0.12;
  _percent[0]  = 0.5;
  _density[0]  = 1;
  _radius[1]  = 0.08;
  _percent[1]  = 0.3;
  _density[1]  = 1;
  _radius[2]  = 0.05;
  _percent[2]  = 0.2;
  _density[2]  = 1;
}

MixSpherePackingGenerator::~MixSpherePackingGenerator() {
  // TODO Auto-generated destructor stub
}


void MixSpherePackingGenerator::setParameter(Parameter* p) {
  std::cout << "SetParameter for param" << p->getNameId() << endl;
  std::string id = p->getNameId();
  char t[256];
  std::string s;
  if (id == "distance") {
      std::cout << "Setting distance!" << std::endl;
      _distance = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "numLayers") {
      std::cout << "Setting Layers !" << std::endl;
      _numLayers = static_cast<ParameterWithIntValue*>(p)->getValue();
  }
  else if (id == "xlength") {
      std::cout << "Setting coordinate x!" << std::endl;
      _xlength = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "ylength") {
      std::cout << "Setting coordinate y!" << std::endl;
      _ylength = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "zlength") {
      std::cout << "Setting coordinate z!" << std::endl;
      _zlength = static_cast<ParameterWithDoubleValue*>(p)->getValue();
  }
  else if (id == "spheresP1") {
      std::cout << "Setting output spheresP1!" <<std::endl;
      _spheresP1 = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output spheresP1: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "spheresP2") {
      std::cout << "Setting output spheresP2!" <<std::endl;
      _spheresP2 = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output spheresP2: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else if (id == "vtk") {
      std::cout << "Setting output vtk!" <<std::endl;
      _vtk = static_cast<ParameterWithBool*> (p)->getValue();
      std::cout<<"Setting output vtk: "<< static_cast<ParameterWithBool*>(p)->getStringValue()<<endl;
  }
  else{
      for (int i = 0; i < _numLayers; i++) {
          std::sprintf(t,"%d",i);
          s=t;
          if (id == "radius "+s) {
              std::cout << "Setting radius!" << std::endl;
              _radius[i] = static_cast<ParameterWithDoubleValue*>(p)->getValue();
          }
          else if (id == "percent "+s) {
              std::cout << "Setting percent!" << std::endl;
              _percent[i] = static_cast<ParameterWithDoubleValue*>(p)->getValue();
          }
          else if (id == "density "+s) {
              std::cout << "Setting radius!" << std::endl;
              _density[i] = static_cast<ParameterWithDoubleValue*>(p)->getValue();
          }
      }
  }
  std::cout << "Parameter value is set!" << endl;
}

bool MixSpherePackingGenerator::validateParameters() {
  bool isValid = true;
  if (_distance < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                << "minimal distance has to be greater 0!" << std::endl;
      isValid = false;
  }
  if (_xlength < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                << "xlength has to greater than 0" << std::endl;
      isValid = false;
  }
  if (_ylength < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                << "ylength has to greater than 0" << std::endl;
      isValid = false;
  }
  if (_zlength < 0.0) {
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                << "zlength has to greater than 0" << std::endl;
      isValid = false;
  }
  char t[256];
  std::string s;
  for (int i = 0; i < _numLayers; i++) {
      std::sprintf(t,"%d",i);
      s=t;
      if (_radius[i] < 0.0) {
          ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                            << "radius has to be greater 0!" << std::endl;
          isValid = false;
      }
      if (_percent[i] < 0.0) {
          ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                                << "percent has to be greater 0!" << std::endl;
          isValid = false;
      }
      if (_density[i] < 0.0) {
          ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                            << "density has to be greater 0!" << std::endl;
          isValid = false;
      }
  }
  return isValid;
}

vector<ParameterCollection*> MixSpherePackingGenerator::getParameters() {
  vector<ParameterCollection*> parameters;
  ParameterCollection* tab = new ParameterCollection("MixSpherePackingCollection", "MixSpherePackingCollection",
      "MixSpherePackingCollection", Parameter::BUTTON);
  parameters.push_back(tab);
  tab->addParameter(
      new ParameterWithIntValue("numLayers",
          "Number of Layers", "The number of Layers which is created and displayed",
          Parameter::SPINBOX,  true, _numLayers));
  ParameterCollection* collection  = new ParameterCollection("Layers", "Layers",
      "Layers", Parameter::BUTTON);
  _radius = new double[_numLayers];
  _percent  = new double[_numLayers];
  _density  = new double[_numLayers];
  char t[256];
  std::string s;
  for (int i = 0; i < _numLayers; i++) {
      _radius[i]=0.1;
      _percent[i]=(double)(1.0/_numLayers);
      _density[i]=1;
      std::sprintf(t,"%d",i);
      s=t;
      collection->addParameter(
          new ParameterWithDoubleValue("radius "+s,
              "magnitude of radius "+s, "The radius of sphere", Parameter::LINE_EDIT,
              false, _radius[i]));
      collection->addParameter(
          new ParameterWithDoubleValue("percent "+s,
              "magnitude of percent "+s, "The percent of Layer", Parameter::LINE_EDIT,
              false, _percent[i]));
      collection->addParameter(
          new ParameterWithDoubleValue("density "+s,
              "magnitude of density "+s, "The density of Layer", Parameter::LINE_EDIT,
              false, _density[i]));
  }
  tab->addParameter(collection);

  ParameterCollection* output  = new ParameterCollection("Output", "Output",
      "Output", Parameter::BUTTON);
  output->addParameter(new ParameterWithBool("spheresP1", "spheresP1",
      "Output the spheresP1" , Parameter::CHECKBOX, false, false));
  output->addParameter(new ParameterWithBool("spheresP2", "spheresP2",
      "Output the spheresP2" , Parameter::CHECKBOX, false, false));
  output->addParameter(new ParameterWithBool("vtk", "vtk",
      "Output the vtk" , Parameter::CHECKBOX, false, false));
  parameters.push_back(output);

  ParameterCollection* box  = new ParameterCollection("Box", "Box",
      "Box", Parameter::BUTTON);
  box->addParameter(
      new ParameterWithDoubleValue("distance",
          "magnitude of distance", "the distance between spheres and wall ",
          Parameter::LINE_EDIT,  false, _distance));
  box->addParameter(
      new ParameterWithDoubleValue("xlength",
          "magnitude of xlength", "the coordinate x ",
          Parameter::LINE_EDIT,  false, _xlength));
  box->addParameter(
      new ParameterWithDoubleValue("ylength",
          "magnitude of ylength", "the coordinate y ",
          Parameter::LINE_EDIT,  false, _ylength));
  box->addParameter(
      new ParameterWithDoubleValue("zlength",
          "magnitude of zlength", "the coordinate z ",
          Parameter::LINE_EDIT,  false, _zlength));
  parameters.push_back(box);

  return parameters;
}

void MixSpherePackingGenerator::generatePreview() {
  if(validateParameters()){
      std::vector<SphereLayer>::iterator it;
      BoundingBox box;
      box.distance=_distance;
      box.xlength=_xlength;
      box.ylength=_ylength;
      box.zlength=_zlength;
      std::vector<SphereLayer> configuration (_numLayers);
      for (int i = 0; i < _numLayers; i++) {
          configuration[i].radius=_radius[i];
          configuration[i].percent=_percent[i];
          configuration[i].density=_density[i];
      }
      clock_t start,end;
      start=clock();
      SpherePacking=algorithms::regularpacking::RegularPacking(box,configuration);
      end=clock();;
      double time=(double)(end-start)/CLOCKS_PER_SEC;
      ScenarioGeneratorApplication::getInstance()->getTextMessageStream()
                                        << "time to generate the spheres are "<< time<<" s" << std::endl;
      it=configuration.begin();
      int id=SpherePacking._spheres.size()*0.2;
      int number=it->number;
      for (int i = 0; i < (int)SpherePacking._spheres.size(); i++) {
          if(i==number){
              id+=number;
              it++;
              number+=it->number;
          }
          ScenarioGeneratorApplication::getInstance()->addObject(
              new MixSpherePackingObject(
                  SpherePacking._spheres[i].getPositionX(),
                  SpherePacking._spheres[i].getPositionY(),
                  SpherePacking._spheres[i].getPositionZ(),
                  0.9*SpherePacking._spheres[i].getRadius(),id));
      }
  }
}
void MixSpherePackingGenerator::generateOutput(const std::string& directory){
  if(directory!=""){
      xml::threeD::SpherePrinter output;
      if(_spheresP1){
          string spheresP1 = directory + "/spheresP1.xml";
          output.printP1Spherepack(SpherePacking,"1/3","1/27",spheresP1);
      }
      if(_spheresP2){
          string spheresP2 = directory + "/spheresP2.xml";
          output.printP2Spherepack(SpherePacking,spheresP2);
      }
      if(_vtk){
          string spherevtk = directory + "/sphere_poly.vtp";
          string domain = directory + "/domain.vtp";
          vtk:: Visualization vtk(&SpherePacking);
          vtk.generateSphere(spherevtk,domain);
      }
  }
}
void MixSpherePackingGenerator::createSampleObject() const {
  ScenarioGeneratorApplication::getInstance()->addObject(
      new MixSpherePackingObject(0,0,0,0.2,1));
}
