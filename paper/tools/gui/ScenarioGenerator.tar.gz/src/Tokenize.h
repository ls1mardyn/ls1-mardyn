/*
 * Tokenize.h
 *
 * @Date: 08.07.2011
 * @Author: eckhardw
 */

#ifndef TOKENIZE_H_
#define TOKENIZE_H_

#include <string>

/**
 * The functions firstSubString() and remainder() split a given string into two
 * parts, based on a seperating character.
 *
 * E.g. the first part of the string "WordA.WordB" with "." as seperator could
 * be split up by calls firstSubString(".", "WordA.WordB") and remainder(".", "WordA.WordB");
 *
 * @return the first part of the string, i.e. the substring up to the position
 * where the seperator occurs.
 */
std::string firstSubString(const std::string& seperator, const std::string& theString);


/**
 * @return the remaining part of the string, i.e. the substring starting from the
 * position+1 where the seperator occurs.
 */
std::string remainingSubString(const std::string& seperator, const std::string& theString);

#endif /* TOKENIZE_H_ */
