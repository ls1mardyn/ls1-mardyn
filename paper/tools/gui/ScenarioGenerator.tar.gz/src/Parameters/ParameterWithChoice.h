/*
 * ParameterWithChoice.h
 *
 *  Created on: May 4, 2011
 *      Author: kovacevt
 */

#ifndef PARAMETERWITHCHOICE_H_
#define PARAMETERWITHCHOICE_H_

#include "Parameters/ParameterWithValue.h"
#include <vector>

class ParameterWithChoice: public Parameter {

private:
	bool triggersRebuild;
	vector<std::string> choices;
	std::string theChoice;

public:
	/**
	 * Constructor
	 * @param id NameId
	 * @param n name
	 * @param d description
	 * @param b if it triggers GUI Rebuild
	 * @param theC the choices
	 */
	ParameterWithChoice(const std::string id, const std::string n, const std::string d, WidgetType wt, const bool b, const vector<std::string> c, const std::string theC);

	/**
	 *  Destructor
	 */
	virtual ~ParameterWithChoice();

	// getters
	vector<std::string> getChoices() const {return choices;}

	std::string getStringValue() const {return theChoice;}

	// setters
	void setStringValue(const std::string& ch){theChoice = ch;}

	virtual void print() const;
};

#endif /* PARAMETERWITHCHOICE_H_ */
