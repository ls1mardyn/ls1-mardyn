/*
 * ParameterWithValue.h
 *
 *  Created on: Aug 14, 2012
 *      Author: eckhardw
 */

#ifndef PARAMETERWITHLONGINTVALUE_H_
#define PARAMETERWITHLONGINTVALUE_H_

#include "Parameters/ParameterWithValue.h"

class ParameterWithLongIntValue: public ParameterWithValue {
private:
	long int value;

public:
	/**
	 * Constructor
	 * @param id nameId
	 * @param n name
	 * @param d description
	 * @param b if it triggers gui rebuild
	 * @param v value
	 */
	ParameterWithLongIntValue(const std::string Id, const std::string name, const std::string description, WidgetType wt, const bool b, const long int v);

	virtual ~ParameterWithLongIntValue();

	//getters
	long int getValue() const {return value;}

	std::string getStringValue() const;

	//setters
	void setValue(const long int v){value = v;}

	void setStringValue(const std::string& value);

	void print() const;
};

#endif /* PARAMETERWITHVALUE_H_ */
