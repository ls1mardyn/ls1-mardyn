/*
 * ParameterWithDoubleValue.h
 *
 *  Created on: May 4, 2011
 *      Author: kovacevt
 */

#ifndef PARAMETERWITHDOUBLEVALUE_H_
#define PARAMETERWITHDOUBLEVALUE_H_

#include "Parameters/ParameterWithValue.h"


class ParameterWithDoubleValue: public ParameterWithValue {

private:
	double value;

public:
	/**
	 * Constructor
	 * @param id nameID
	 * @param n Name
	 * @param b if it triggers gui rebuild
	 * @param v value
	 */
	ParameterWithDoubleValue(const std::string Id, const std::string name, const std::string description, WidgetType wt, const bool b, const double v);

	virtual ~ParameterWithDoubleValue();

	// getters
	double getValue() const {return value;}

	std::string getStringValue() const;

	// setters
	void setValue(const double v){value = v;}

	void setStringValue(const std::string& text);

	void print() const;

};

#endif /* PARAMETERWITHDOUBLEVALUE_H_ */
