/*
 * ParameterWithBool.cpp
 *
 *  Created on: Jun 25, 2011
 *      Author: kovacevt
 */

#include "ParameterWithBool.h"
#include <iostream>

ParameterWithBool::ParameterWithBool(const std::string nameId, const std::string name, const std::string desc, WidgetType wt, bool rebuild, bool v):
Parameter(nameId,name,desc,wt, Parameter::BOOL) {
	triggersRebuild = rebuild;
	value = v;
}

ParameterWithBool::~ParameterWithBool() {
	// TODO Auto-generated destructor stub
}

string ParameterWithBool::getStringValue() const {
	if (value == true) {
		return "true";
	}
	else return "false";
}

void ParameterWithBool::setStringValue(const std::string& value) {
	if (value == "true") {
		this->value = true;
	} else {
		this->value = false;
	}
}

void ParameterWithBool::print() const {
	std::cout<<"ParameterWithBool with value: "<<getStringValue()<<endl;
}
