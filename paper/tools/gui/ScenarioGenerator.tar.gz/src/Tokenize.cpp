/*
 * Tokenize.cpp
 *
 * @Date: 12.09.2011
 * @Author: eckhardw
 */

#include "Tokenize.h"

std::string firstSubString(const std::string& seperator, const std::string& theString) {
	size_t position = theString.find(seperator);
	if (position != std::string::npos) {
		return theString.substr(0, position);
	} else {
		return theString;
	}
}


std::string remainingSubString(const std::string& seperator, const std::string& theString) {
	size_t position = theString.find(seperator);
	if (position != std::string::npos) {
		return theString.substr(position+1);
	} else {
		return theString;
	}
}
